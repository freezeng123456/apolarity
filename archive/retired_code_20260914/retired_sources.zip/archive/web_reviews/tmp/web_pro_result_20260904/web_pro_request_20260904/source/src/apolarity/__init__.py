"""Apolarity: exact monomial derivatives through rank-optimal Taylor jets."""

from .waring import WaringInfo, alpha_factorial_from_counts, monomial_waring_directions
from .polarization import PolarizationInfo, polarization_directions
from .taylor_jet import tp_directional_via_jet, tp_directional_all_via_jet
from .operators import single_monomial_partial
from .benchmark_multiindex import (
    DirectionSchedule,
    exponent_pattern,
    format_one_based,
    parse_one_based_pattern,
    rank_optimal_schedule,
    theoretical_waring_rank,
)
from .benchmark_derivatives import DerivativeMeta, monomial_partial, rank_optimal_partial_raw
from .benchmark_residuals import (
    GKDV1D_TERMS,
    KDV2D_TERMS,
    POLYHARMONIC_2D,
    gkdv1d_gradient_enhanced_loss,
    kdv2d_residual,
    polyharmonic_2d_operator,
)

__all__ = [
    # Current two-method benchmark API.
    "DirectionSchedule",
    "DerivativeMeta",
    "parse_one_based_pattern",
    "format_one_based",
    "exponent_pattern",
    "theoretical_waring_rank",
    "rank_optimal_schedule",
    "monomial_partial",
    "rank_optimal_partial_raw",
    "KDV2D_TERMS",
    "GKDV1D_TERMS",
    "POLYHARMONIC_2D",
    "kdv2d_residual",
    "gkdv1d_gradient_enhanced_loss",
    "polyharmonic_2d_operator",
    # Legacy core utilities retained for compatibility; benchmark runners do
    # not expose them as additional comparison methods.
    "WaringInfo",
    "alpha_factorial_from_counts",
    "monomial_waring_directions",
    "PolarizationInfo",
    "polarization_directions",
    "tp_directional_via_jet",
    "tp_directional_all_via_jet",
    "single_monomial_partial",
]
