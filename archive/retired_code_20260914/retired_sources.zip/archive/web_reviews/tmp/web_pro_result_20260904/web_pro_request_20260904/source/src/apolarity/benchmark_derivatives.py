"""Two-method derivative API used by the reproducible benchmark suite."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Literal

import torch
import torch.nn as nn
from torch import Tensor

from .benchmark_multiindex import DirectionSchedule, rank_optimal_schedule
from .operators import direct_monomial_autodiff
from .taylor_jet import tp_directional_via_jet

Method = Literal["nested_ad", "rank_optimal"]


@dataclass(frozen=True)
class DerivativeMeta:
    method: Method
    order: int
    direction_count: int | None
    theoretical_rank: int | None
    direction_dtype: str | None
    requires_complex: bool


def _rank_partial_raw(
    model: nn.Module,
    x: Tensor,
    alpha: tuple[int, ...],
) -> tuple[Tensor, DirectionSchedule]:
    if x.ndim != 2:
        raise ValueError(f"x must have shape (batch, d); got {tuple(x.shape)}")
    if x.dtype not in (torch.float32, torch.float64):
        raise ValueError(f"benchmark real inputs must be float32/float64; got {x.dtype}")
    schedule = rank_optimal_schedule(
        alpha, x.shape[-1], device=x.device, real_dtype=x.dtype
    )
    eval_x = x.to(schedule.directions.dtype) if schedule.requires_complex else x
    B, d = eval_x.shape
    V = schedule.directions
    Z = V.unsqueeze(0).expand(B, V.shape[0], d).contiguous()
    tp = tp_directional_via_jet(model, eval_x, Z, len(alpha))
    value = (tp * schedule.weights.view(1, -1, 1)).sum(dim=1)
    return value, schedule


def monomial_partial(
    model: nn.Module,
    x: Tensor,
    alpha: Iterable[int],
    *,
    method: Method,
    create_graph: bool = True,
    return_complex: bool = False,
) -> tuple[Tensor, DerivativeMeta]:
    """Evaluate one mixed partial with exactly one of the two mainline methods."""
    alpha_t = tuple(int(i) for i in alpha)
    if not alpha_t:
        raise ValueError("alpha must have positive order")
    if method == "nested_ad":
        value = direct_monomial_autodiff(model, x, alpha_t, create_graph=create_graph)
        return value, DerivativeMeta(
            method=method,
            order=len(alpha_t),
            direction_count=None,
            theoretical_rank=None,
            direction_dtype=None,
            requires_complex=False,
        )
    if method == "rank_optimal":
        raw, schedule = _rank_partial_raw(model, x, alpha_t)
        value = raw if return_complex or not raw.is_complex() else raw.real
        return value, DerivativeMeta(
            method=method,
            order=len(alpha_t),
            direction_count=schedule.theoretical_rank,
            theoretical_rank=schedule.theoretical_rank,
            direction_dtype=str(schedule.directions.dtype).replace("torch.", ""),
            requires_complex=schedule.requires_complex,
        )
    raise ValueError(f"method must be 'nested_ad' or 'rank_optimal'; got {method!r}")


def rank_optimal_partial_raw(
    model: nn.Module, x: Tensor, alpha: Iterable[int]
) -> tuple[Tensor, DerivativeMeta]:
    alpha_t = tuple(int(i) for i in alpha)
    raw, schedule = _rank_partial_raw(model, x, alpha_t)
    return raw, DerivativeMeta(
        method="rank_optimal",
        order=len(alpha_t),
        direction_count=schedule.theoretical_rank,
        theoretical_rank=schedule.theoretical_rank,
        direction_dtype=str(schedule.directions.dtype).replace("torch.", ""),
        requires_complex=schedule.requires_complex,
    )


__all__ = ["Method", "DerivativeMeta", "monomial_partial", "rank_optimal_partial_raw"]
