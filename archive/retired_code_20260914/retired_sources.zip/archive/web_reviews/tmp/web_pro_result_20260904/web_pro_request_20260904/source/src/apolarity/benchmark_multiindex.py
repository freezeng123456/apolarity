"""Multi-index metadata and rank-optimal direction schedules for benchmarks.

The benchmark API uses expanded, zero-based multi-indices.  For example,
``(0, 0, 1, 1, 2, 2)`` denotes :math:`u_{112233}` in one-based notation.
"""
from __future__ import annotations

import cmath
import itertools
import math
from collections import Counter
from dataclasses import dataclass
from typing import Iterable

import torch
from torch import Tensor


@dataclass(frozen=True)
class DirectionSchedule:
    alpha: tuple[int, ...]
    order: int
    active_indices: tuple[int, ...]
    active_exponents: tuple[int, ...]
    base_index: int
    theoretical_rank: int
    alpha_factorial: int
    requires_complex: bool
    directions: Tensor
    weights: Tensor


def parse_one_based_pattern(pattern: str) -> tuple[int, ...]:
    """Convert strings such as ``"11223344"`` to a zero-based expanded index."""
    text = pattern.strip().replace("u_", "").replace("_", "")
    if not text or not text.isdigit() or "0" in text:
        raise ValueError(f"pattern must contain one-based decimal coordinate labels: {pattern!r}")
    # Benchmarks in this project use coordinates 1..9; keeping this parser
    # deliberately simple makes the filename/config convention unambiguous.
    return tuple(int(ch) - 1 for ch in text)


def format_one_based(alpha: Iterable[int]) -> str:
    alpha_t = tuple(int(i) for i in alpha)
    return "u_" + "".join(str(i + 1) for i in alpha_t)


def exponent_pattern(alpha: Iterable[int]) -> tuple[int, ...]:
    counts = Counter(int(i) for i in alpha)
    return tuple(sorted(counts.values(), reverse=True))


def theoretical_waring_rank(alpha: Iterable[int]) -> int:
    """Classical complex Waring rank of one monomial."""
    alpha_t = tuple(int(i) for i in alpha)
    if not alpha_t:
        raise ValueError("alpha must have positive order")
    exps = sorted(Counter(alpha_t).values())
    return math.prod(e + 1 for e in exps[1:]) if len(exps) > 1 else 1


def rank_optimal_schedule(
    alpha: Iterable[int],
    d: int,
    *,
    device: torch.device | None = None,
    real_dtype: torch.dtype = torch.float32,
    root_angle_sign: float = 1.0,
) -> DirectionSchedule:
    """Build the roots-of-unity Waring schedule, using real arithmetic when possible.

    The returned weights satisfy

    ``partial^alpha u = sum_r weight[r] * T_p(x; direction[r])``

    with ``T_p = D^p/p!``.  Pure derivatives and square-free patterns use real
    directions.  Complex64/complex128 is used only when roots of unity other
    than ±1 are genuinely required by this construction.
    """
    if real_dtype not in (torch.float32, torch.float64):
        raise ValueError(f"real_dtype must be float32 or float64; got {real_dtype}")
    alpha_t = tuple(int(i) for i in alpha)
    if not alpha_t:
        raise ValueError("alpha must have positive order")
    if any(i < 0 or i >= d for i in alpha_t):
        raise ValueError(f"alpha indices {alpha_t} out of range for d={d}")

    counts = Counter(alpha_t)
    active = sorted(counts.items(), key=lambda kv: (kv[1], kv[0]))
    base_index = active[0][0]
    other = active[1:]
    rank = math.prod(exp + 1 for _, exp in other) if other else 1
    alpha_factorial = math.prod(math.factorial(exp) for exp in counts.values())
    requires_complex = any(exp > 1 for _, exp in other)

    if requires_complex:
        dtype = torch.complex64 if real_dtype == torch.float32 else torch.complex128
    else:
        dtype = real_dtype

    root_lists: list[list[complex | float]] = []
    for _idx, exp in other:
        m = exp + 1
        if m == 2 and not requires_complex:
            root_lists.append([1.0, -1.0])
        else:
            root_lists.append(
                [cmath.exp(root_angle_sign * 2j * math.pi * k / m) for k in range(m)]
            )

    products = itertools.product(*root_lists) if root_lists else [()]
    directions: list[list[complex | float]] = []
    weights: list[complex | float] = []
    scale = alpha_factorial / float(rank)
    for roots in products:
        v: list[complex | float] = [0.0] * d
        v[base_index] = 1.0
        weight: complex | float = scale
        for (idx, _exp), root in zip(other, roots):
            v[idx] = root
            weight = weight * root
        if not requires_complex:
            v = [float(complex(z).real) for z in v]
            weight = float(complex(weight).real)
        directions.append(v)
        weights.append(weight)

    return DirectionSchedule(
        alpha=alpha_t,
        order=len(alpha_t),
        active_indices=tuple(idx for idx, _ in active),
        active_exponents=tuple(exp for _, exp in active),
        base_index=base_index,
        theoretical_rank=rank,
        alpha_factorial=alpha_factorial,
        requires_complex=requires_complex,
        directions=torch.tensor(directions, device=device, dtype=dtype),
        weights=torch.tensor(weights, device=device, dtype=dtype),
    )


__all__ = [
    "DirectionSchedule",
    "parse_one_based_pattern",
    "format_one_based",
    "exponent_pattern",
    "theoretical_waring_rank",
    "rank_optimal_schedule",
]
