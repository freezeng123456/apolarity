# Apolarity numerical benchmark package

This snapshot contains a self-contained numerical experiment harness for comparing exactly two derivative backends:

- `nested_ad`: direct/nested coordinate automatic differentiation;
- `rank_optimal`: Apolarity's rank-optimal directional Taylor-jet representation of each monomial mixed partial.

No randomized estimator is a main method. The supplied STDE code is retained only under the sibling `reference/` tree as an **isolated definition/protocol reference**. The implementation in `source/` does not import STDE and no STDE result is reported as an Apolarity result.

## 1. What is implemented

### Fixed mixed partials

The required one-based patterns are converted to zero-based expanded multi-indices and evaluated both directly and through the Waring/Taylor-jet representation.

| case | zero-based multi-index | order | exponent pattern | theoretical rank/directions |
|---|---|---:|---|---:|
| `u_112233` | `(0,0,1,1,2,2)` | 6 | `(2,2,2)` | 9 |
| `u_111222333` | `(0,0,0,1,1,1,2,2,2)` | 9 | `(3,3,3)` | 16 |
| `u_11223344` | `(0,0,1,1,2,2,3,3)` | 8 | `(2,2,2,2)` | 27 |
| `u_123456` | `(0,1,2,3,4,5)` | 6 | `(1,1,1,1,1,1)` | 32 |

For a sorted active exponent vector `a_0 <= ... <= a_n`, the complex monomial Waring rank used by the construction is `prod_{j=1}^n (a_j+1)`. The square-free case only needs roots `+/-1`, so `u_123456` is deliberately evaluated with real `float32` directions rather than being needlessly promoted to `complex64`.

Every fixed-partial row records the multi-index, order, exponent pattern, theoretical/evaluated direction count, direction dtype, analytic error, imaginary leakage, parameter-gradient error versus `nested_ad`, timing and memory metadata.

### 2D nonlinear KdV residual

The implementation follows the supplied upstream `stde/equations.py` definition whose source currently selects `case=4`:

```text
R = u_ty + u_xxxy + 3 (u_xy u_x + u_y u_xx) - u_xx + 2 u_yy.
```

The mixed terms `u_ty`, `u_xy` and `u_xxxy` are retained. Coordinates are `(x,y,t)`.

### g-KdV / highord1d

The implementation follows the supplied upstream `highord1d_res` with `case=4, eq=2`, including the complete gradient-enhanced objective rather than only the base PDE residual:

```text
f   = u_t  + u u_x + 0.0025 u_xxx
f_x = u_tx + u_x^2 + u u_xx + 0.0025 u_xxxx
f_t = u_tt + u_t u_x + u u_tx + 0.0025 u_txxx
loss = mean(f^2) + 1e-3 * (mean(f_x^2) + mean(f_t^2)).
```

Coordinates are `(x,t)`. Results include component-wise validation for `f`, `f_x`, and `f_t`.

### 2D polyharmonic

The explicit operators are

```text
Delta^2 u = u_xxxx + 2 u_xxyy + u_yyyy
Delta^3 u = u_xxxxxx + 3 u_xxxxyy + 3 u_xxyyyy + u_yyyyyy.
```

Both are evaluated by `nested_ad` and by a sum of rank-optimal monomial Taylor-jet evaluations. Analytic sinusoidal fixtures verify the complete operator, not just individual monomials.

## 2. Two independent implementations

### PyTorch integration

Main package:

```text
src/apolarity/
  benchmark_multiindex.py
  benchmark_derivatives.py
  benchmark_models.py
  benchmark_residuals.py
  waring.py
  taylor_jet.py
  ...
experiments/torch_benchmarks/
  run.py
  bench_utils.py
```

The benchmark-facing API exposes only `nested_ad` and `rank_optimal`. Legacy package modules are retained for compatibility but are not additional benchmark methods.

### Standalone JAX benchmark

```text
experiments/jax_benchmarks/
  pyproject.toml
  run.py
  src/jax_apolarity_bench/
  tests/
  configs/
```

This package independently implements the rank schedule, nested derivative, JAX `jet` Taylor coefficient evaluation, benchmark models, PDE residuals, measurements and result serialization. It does not depend on the Torch implementation and does not import STDE.

## 3. Dtype and fairness policy

The primary real baseline is `float32`.

`rank_optimal` uses `complex64` directions only for monomials whose root-of-unity schedule actually needs non-real roots. The real model parameters remain the same real `float32` parameters; outputs used in residuals/losses are projected to their real part after the exact complex directional combination. The raw imaginary leakage is measured on analytic checks.

This is not presented as equal arithmetic cost: complex64 contains two float32 components and can have different kernel efficiency. Fairness here means that the two methods evaluate the **same mathematical derivative/residual**, on the same points, with the same real network parameters, batch size and loss, while the required direction dtype is reported explicitly. Timing tables should therefore be read together with `dtype_direction` and direction counts.

There is no direction chunking in the primary protocol. No hidden `bs=128` is introduced.

## 4. Primary protocol

`configs/main.yaml` is the intended experiment protocol:

- seed: `20260904`;
- real dtype: `float32`;
- batch size: `100` (matching the supplied STDE configuration basis, not 128);
- MLP width: `128`;
- `depth=4` uses the supplied STDE model semantics: four `Linear` layers total, hence three hidden `tanh` layers and one scalar output layer;
- PDE domain sampler follows the supplied STDE convention: normalized Gaussian spatial direction, radius `Uniform[0,R]`, time `Uniform[0,T]`;
- warm-ups: `5`;
- measured repeats: `10`;
- no direction chunking.

The benchmark scripts freeze the used YAML next to every result and emit provenance JSON containing library versions, devices/backend and a source-tree hash.

### Timing synchronization

PyTorch CUDA measurements synchronize before/after every timed call. `torch.cuda.max_memory_allocated` is used for CUDA peak allocation. On CPU the recorded value is the process `ru_maxrss` high-water mark and is explicitly labeled as an absolute process value, not a per-call allocation delta.

JAX records `compile_plus_first_call_ms` separately. Warm-ups and steady-state repeats call `block_until_ready()` on all result leaves. Device memory is read from `device.memory_stats()` when the backend exposes it; otherwise the same absolute `ru_maxrss` fallback is labeled in the result.

## 5. CPU smoke protocol

`configs/cpu_smoke.yaml` is deliberately **non-publication**. It keeps the equations and derivative schedules unchanged, but reduces batch/repetition sizes and uses parameterized analytic `sinh`/`sin` timing fixtures. The reason is practical: on a CPU, repeatedly JIT-compiling ninth-order nested derivatives and high-order MLP parameter backpropagation can dominate the smoke run and provides little additional correctness evidence.

Correctness is still checked for:

- all four required mixed partial values;
- all four required mixed-partial parameter gradients;
- KdV residual and its parameter gradient;
- full g-KdV gradient-enhanced objective and its parameter gradient;
- fourth- and sixth-order polyharmonic values and parameter gradients;
- both `nested_ad` and `rank_optimal`.

Torch additionally validates the PDE parameter gradients on a small real `tanh` MLP. JAX uses a parameterized entire analytic fixture for the high-order parameter-gradient correctness test so that the CPU unit suite remains finite; the primary JAX benchmark still times the configured MLP.

## 6. Installation

From `source/`:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[all]'
```

The standalone JAX package can also be installed independently:

```bash
python -m pip install -e experiments/jax_benchmarks
```

Install the JAX build appropriate to your CUDA runtime when running on a GPU.

## 7. Tests

The active self-contained test suite is the default:

```bash
PYTHONPATH=src pytest -q
```

Standalone JAX tests:

```bash
cd experiments/jax_benchmarks
PYTHONPATH=src pytest -q
```

The original uploaded `tests/` directory is preserved as `tests/` for auditability, but it is not the default `pytest` target because the uploaded snapshot omitted several historical `experiments/archived/...` and `scripts/...` files that those legacy tests import during collection. Those missing files were not fabricated. See `TEST_REPORT.md`.

## 8. Running benchmarks

### CPU smoke

```bash
python scripts/run_cpu_smoke.py
```

For individual rows/cases, which is also useful on constrained CPU hosts:

```bash
PYTHONPATH=src python experiments/torch_benchmarks/run.py \
  --config configs/cpu_smoke.yaml --benchmark poly6 --method both \
  --mode both --device cpu --out results/cpu_poly6_torch

cd experiments/jax_benchmarks
JAX_PLATFORMS=cpu JAX_BENCH_FORCE_EXIT=1 PYTHONPATH=src python run.py \
  --config configs/cpu_smoke.yaml --benchmark poly6 --method rank_optimal \
  --mode parameter_grad --out ../../results/cpu_poly6_jax
```

`JAX_BENCH_FORCE_EXIT=1` is a process-lifecycle option used by the matrix smoke driver after all results/provenance have been flushed. It avoids a JAX interpreter-teardown stall observed in the evaluation container; it does not skip synchronization, validation, or result writing.

### Primary Torch CUDA/T4 run

```bash
CUDA_VISIBLE_DEVICES=0 PYTHONPATH=src python experiments/torch_benchmarks/run.py \
  --config configs/main.yaml --benchmark all --method both --mode both \
  --device cuda --out results/t4/torch_main
```

If CUDA is requested but unavailable, the Torch runner fails rather than silently falling back.

### Primary JAX CUDA/T4 run

A GPU-required invocation is:

```bash
cd experiments/jax_benchmarks
CUDA_VISIBLE_DEVICES=0 XLA_PYTHON_CLIENT_PREALLOCATE=false \
JAX_BENCH_FORCE_EXIT=1 PYTHONPATH=src python run.py \
  --config configs/main.yaml --benchmark all --method both --mode both \
  --require-gpu --out ../../results/t4/jax_main
```

`--require-gpu` fails if no JAX GPU device is visible. With `device: auto` and no GPU, JAX result rows explicitly record the requested device, actual backend, `gpu_visible`, and a CPU fallback reason; such a run is not labeled as a GPU result.

For the cleanest JAX benchmarking, run expensive cases in fresh processes so unrelated JIT compilation caches do not contaminate later cases. The generic matrix driver does exactly that:

```bash
CUDA_VISIBLE_DEVICES=0 XLA_PYTHON_CLIENT_PREALLOCATE=false \
python scripts/run_jax_matrix.py --config experiments/jax_benchmarks/configs/main.yaml \
  --out-dir results/t4/jax_main_matrix --require-gpu
```


## 9. Aggregation and plots

Aggregate any result JSON files:

```bash
python scripts/aggregate_results.py \
  results/cpu_smoke/torch.json results/cpu_smoke/jax_rank_fixed_value.json \
  --out results/combined
```

Create a timing plot:

```bash
python scripts/plot_results.py results/combined.json \
  --backend torch --mode value --out results/torch_value.png
```

Do not combine `cpu_smoke_nonpublication` rows with primary GPU rows in a publication table. Result fields include `protocol_kind` and `timing_fixture` precisely to prevent that mistake.

## 10. Upstream reference isolation and provenance

The final bundle retains the supplied reference tree at `../reference/`. The benchmark definitions were audited against these exact uploaded files:

- `reference/stde_upstream/stde/equations.py`, SHA256 `697f2f8a11523e7dbe1efd9b82e7b2ce45bc63b391406895e6821cf9948a9a3f`;
- `reference/stde_upstream/stde/config.py`, SHA256 `f12e20bf57ea44604248d65fd54964834e4bc5b2edcc68bfaf7ad9c2f1711157`;
- `reference/stde_upstream/stde/model.py`, SHA256 `70552f790cd970d8bcc8b6d3c9332d72dd7dc2ad0bb169613c10d61661746a00`.

No code under `source/src/apolarity`, `source/experiments/torch_benchmarks`, or `source/experiments/jax_benchmarks/src` imports `stde`. The supplied adapter and STDE code are reference material only.

See `PROVENANCE.md`, `CHANGELOG.md`, and `TEST_REPORT.md` for the audit trail of this reconstructed experiment package.
