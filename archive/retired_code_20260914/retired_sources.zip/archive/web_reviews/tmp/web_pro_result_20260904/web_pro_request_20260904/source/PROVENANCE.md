# Provenance

## Input snapshot

This reconstruction was performed directly from the uploaded archive `apolarity_web_pro_request_20260904(2).zip`. The Apolarity source snapshot is treated as the implementation baseline. The bundled STDE material is treated only as an isolated upstream reference for benchmark definitions and protocol choices.

## Upstream STDE files actually consulted

| file | SHA256 | use |
|---|---|---|
| `../reference/stde_upstream/stde/equations.py` | `697f2f8a11523e7dbe1efd9b82e7b2ce45bc63b391406895e6821cf9948a9a3f` | KdV2d `case=4`; highord1d `case=4, eq=2` formulas |
| `../reference/stde_upstream/stde/config.py` | `f12e20bf57ea44604248d65fd54964834e4bc5b2edcc68bfaf7ad9c2f1711157` | batch/domain/model configuration defaults |
| `../reference/stde_upstream/stde/model.py` | `70552f790cd970d8bcc8b6d3c9332d72dd7dc2ad0bb169613c10d61661746a00` | `depth` semantics and MLP construction |

The supplied `reference/stde_adapter/` was audited but is not imported by the new benchmark implementations.

## Mainline method boundary

Only these method labels are emitted by the new benchmark runners:

- `nested_ad`
- `rank_optimal`

Randomized STDE is not a main method, and deterministic STDE output is not substituted for either method.

## Primary deterministic protocol

See `configs/main.yaml`. Important frozen choices are seed `20260904`, float32 real baseline, batch size 100, width 128, four total linear layers under the supplied STDE model semantics, five warm-ups, ten measured repeats, and no direction chunking.

## Dtype provenance

The rank-optimal schedule is generated from the Apolarity monomial Waring construction. Repeated exponent patterns can require roots of unity and therefore complex64 direction/tangent values. The square-free `u_123456` schedule is exactly real and remains float32. Every result row records `dtype_real`, `dtype_direction`, `requires_complex`, and direction counts.

## Runtime measurement provenance

Torch CUDA: explicit synchronization around timed calls and `torch.cuda.max_memory_allocated`. Torch CPU: absolute process `ru_maxrss` high-water mark.

JAX: compile+first-call is separated from steady-state timing, every timed result is blocked until ready, and device memory statistics are used when exposed by the backend; otherwise absolute process `ru_maxrss` is reported. JAX rows record requested/actual backend and whether a GPU was visible.

## Evaluation container used for the included smoke results

The observed environment during reconstruction was:

- Python 3.13.x (exact version is emitted into result provenance);
- PyTorch `2.10.0+cpu`;
- JAX `0.9.0.1`;
- NumPy `2.3.5`;
- PyYAML `6.0.3`;
- Matplotlib `3.10.8`;
- psutil `7.2.2`;
- no CUDA device visible to PyTorch or JAX.

Therefore no T4/CUDA timings are claimed in this bundle. Commands for GPU-required execution are in `README.md`.

## Generated per-run provenance

Run:

```bash
python scripts/write_provenance.py
```

Each benchmark runner also writes `*_provenance.json` and a frozen YAML config next to its result files. These capture the runtime library/device information and a source-tree hash at execution time.
