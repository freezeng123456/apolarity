from __future__ import annotations

from pathlib import Path
import yaml

ROOT=Path(__file__).resolve().parents[1]

def test_main_and_jax_configs_match_exactly():
    for name in ("main.yaml","cpu_smoke.yaml"):
        a=yaml.safe_load((ROOT/"configs"/name).read_text())
        b=yaml.safe_load((ROOT/"experiments/jax_benchmarks/configs"/name).read_text())
        assert a==b

def test_mainline_does_not_import_stde_reference():
    paths=list((ROOT/"src/apolarity").glob("*.py"))+list((ROOT/"experiments/torch_benchmarks").glob("*.py"))+list((ROOT/"experiments/jax_benchmarks/src").rglob("*.py"))
    for p in paths:
        text=p.read_text().lower()
        assert "import stde" not in text
        assert "from stde" not in text
