"""Exact PDE residual definitions used by the two-method benchmark.

The equations below are transcribed from the supplied upstream STDE
``stde/equations.py``.  STDE itself is not imported at runtime.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import torch
import torch.nn as nn
from torch import Tensor

from .benchmark_derivatives import Method, monomial_partial


KDV2D_TERMS: dict[str, tuple[int, ...]] = {
    "u_x": (0,),
    "u_y": (1,),
    "u_xx": (0, 0),
    "u_xy": (0, 1),
    "u_yy": (1, 1),
    "u_ty": (1, 2),
    "u_xxxy": (0, 0, 0, 1),
}

GKDV1D_TERMS: dict[str, tuple[int, ...]] = {
    "u_x": (0,),
    "u_t": (1,),
    "u_xx": (0, 0),
    "u_tx": (1, 0),
    "u_tt": (1, 1),
    "u_xxx": (0, 0, 0),
    "u_xxxx": (0, 0, 0, 0),
    "u_txxx": (1, 0, 0, 0),
}

POLYHARMONIC_2D: dict[int, tuple[tuple[float, tuple[int, ...]], ...]] = {
    4: (
        (1.0, (0, 0, 0, 0)),
        (2.0, (0, 0, 1, 1)),
        (1.0, (1, 1, 1, 1)),
    ),
    6: (
        (1.0, (0, 0, 0, 0, 0, 0)),
        (3.0, (0, 0, 0, 0, 1, 1)),
        (3.0, (0, 0, 1, 1, 1, 1)),
        (1.0, (1, 1, 1, 1, 1, 1)),
    ),
}


@dataclass
class ResidualEvaluation:
    value: Tensor
    components: dict[str, Tensor]
    direction_evaluations: int | None
    max_derivative_order: int


def _partials(model: nn.Module, x: Tensor, terms: dict[str, tuple[int, ...]], method: Method):
    out: dict[str, Tensor] = {}
    total = 0
    for name, alpha in terms.items():
        value, meta = monomial_partial(model, x, alpha, method=method, create_graph=True)
        out[name] = value
        if meta.direction_count is not None:
            total += meta.direction_count
    return out, total if method == "rank_optimal" else None


def kdv2d_residual(model: nn.Module, xyt: Tensor, *, method: Method) -> ResidualEvaluation:
    """2-D nonlinear KdV residual from upstream ``KdV2d_res``.

    ``r = u_ty + u_xxxy + 3(u_xy u_x + u_y u_xx) - u_xx + 2 u_yy``.
    Coordinates are ``(x,y,t)``.
    """
    if xyt.shape[-1] != 3:
        raise ValueError("KdV2D expects coordinates (x,y,t)")
    d, total = _partials(model, xyt, KDV2D_TERMS, method)
    r = (
        d["u_ty"]
        + d["u_xxxy"]
        + 3.0 * (d["u_xy"] * d["u_x"] + d["u_y"] * d["u_xx"])
        - d["u_xx"]
        + 2.0 * d["u_yy"]
    )
    return ResidualEvaluation(r, d, total, 4)


def gkdv1d_gradient_enhanced_loss(
    model: nn.Module,
    xt: Tensor,
    *,
    method: Method,
    lam1: float = 1e-3,
    dispersion: float = 0.0025,
) -> ResidualEvaluation:
    """Upstream ``highord1d`` case=4, eq=2 complete gPINN objective.

    The returned ``value`` is the scalar
    ``mean(f^2) + lam1*(mean(f_x^2)+mean(f_t^2))``.  Components include the
    three per-point residuals ``f``, ``f_x`` and ``f_t``.
    """
    if xt.shape[-1] != 2:
        raise ValueError("gKdV1D expects coordinates (x,t)")
    d, total = _partials(model, xt, GKDV1D_TERMS, method)
    u = model(xt)
    f = d["u_t"] + u * d["u_x"] + dispersion * d["u_xxx"]
    fx = d["u_tx"] + d["u_x"] ** 2 + u * d["u_xx"] + dispersion * d["u_xxxx"]
    ft = d["u_tt"] + d["u_t"] * d["u_x"] + u * d["u_tx"] + dispersion * d["u_txxx"]
    loss = f.square().mean() + lam1 * (fx.square().mean() + ft.square().mean())
    return ResidualEvaluation(loss, {**d, "f": f, "f_x": fx, "f_t": ft}, total, 4)


def polyharmonic_2d_operator(
    model: nn.Module, xy: Tensor, *, order: int, method: Method
) -> ResidualEvaluation:
    """Evaluate ``Delta^(order/2) u`` for order 4 or 6 in 2D."""
    if xy.shape[-1] != 2:
        raise ValueError("polyharmonic_2d expects coordinates (x,y)")
    if order not in POLYHARMONIC_2D:
        raise ValueError("order must be 4 or 6")
    components: dict[str, Tensor] = {}
    total = 0
    value: Tensor | None = None
    for coefficient, alpha in POLYHARMONIC_2D[order]:
        partial, meta = monomial_partial(model, xy, alpha, method=method, create_graph=True)
        key = "d_" + "".join(str(i + 1) for i in alpha)
        components[key] = partial
        term = coefficient * partial
        value = term if value is None else value + term
        if meta.direction_count is not None:
            total += meta.direction_count
    assert value is not None
    return ResidualEvaluation(value, components, total if method == "rank_optimal" else None, order)


def polyharmonic_manufactured_solution(xy: Tensor) -> Tensor:
    return torch.sin(torch.pi * xy[:, 0:1]) * torch.sin(torch.pi * xy[:, 1:2])


def polyharmonic_manufactured_source(xy: Tensor, order: int) -> Tensor:
    m = order // 2
    return (-2.0 * torch.pi**2) ** m * polyharmonic_manufactured_solution(xy)


__all__ = [
    "KDV2D_TERMS",
    "GKDV1D_TERMS",
    "POLYHARMONIC_2D",
    "ResidualEvaluation",
    "kdv2d_residual",
    "gkdv1d_gradient_enhanced_loss",
    "polyharmonic_2d_operator",
    "polyharmonic_manufactured_solution",
    "polyharmonic_manufactured_source",
]
