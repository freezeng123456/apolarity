#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAX_DIR = ROOT / "experiments/jax_benchmarks"


def write_csv(rows, path: Path) -> None:
    keys = sorted({k for r in rows for k in r if k != "times_ms"})
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for row in rows:
            flat = {k: row.get(k) for k in keys}
            for k, value in list(flat.items()):
                if isinstance(value, (dict, list, tuple)):
                    flat[k] = json.dumps(value, separators=(",", ":"), default=str)
            w.writerow(flat)


def main() -> None:
    ap = argparse.ArgumentParser(description="Run the JAX benchmark matrix in fresh processes and aggregate results.")
    ap.add_argument("--config", default=str(JAX_DIR / "configs/main.yaml"))
    ap.add_argument("--out-dir", default=str(ROOT / "results/jax_matrix"))
    ap.add_argument("--require-gpu", action="store_true")
    ap.add_argument("--worker-timeout", type=int, default=1800)
    args = ap.parse_args()

    config = Path(args.config).resolve()
    out_dir = Path(args.out_dir).resolve()
    parts = out_dir / "parts"
    parts.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []

    env = os.environ.copy()
    env["PYTHONPATH"] = str(JAX_DIR / "src")
    env["JAX_BENCH_FORCE_EXIT"] = "1"

    for benchmark in ("fixed", "kdv2d", "gkdv1d", "poly4", "poly6"):
        for method in ("nested_ad", "rank_optimal"):
            for mode in ("value", "parameter_grad"):
                stem = parts / f"{benchmark}_{method}_{mode}"
                cmd = [
                    sys.executable, str(JAX_DIR / "run.py"),
                    "--config", str(config),
                    "--benchmark", benchmark,
                    "--method", method,
                    "--mode", mode,
                    "--out", str(stem),
                ]
                if args.require_gpu:
                    cmd.append("--require-gpu")
                print("+", " ".join(cmd), flush=True)
                completed = subprocess.run(
                    cmd, cwd=JAX_DIR, env=env, text=True,
                    capture_output=True, timeout=args.worker_timeout,
                )
                if completed.returncode != 0:
                    sys.stderr.write(completed.stdout[-4000:])
                    sys.stderr.write(completed.stderr[-4000:])
                    raise SystemExit(f"JAX worker failed with exit code {completed.returncode}: {' '.join(cmd)}")
                rows.extend(json.loads(stem.with_suffix(".json").read_text(encoding="utf-8")))

    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "jax_matrix.json").write_text(json.dumps(rows, indent=2, default=str), encoding="utf-8")
    write_csv(rows, out_dir / "jax_matrix.csv")
    print(json.dumps({"rows": len(rows), "ok": sum(r.get("status") == "ok" for r in rows), "out_dir": str(out_dir)}, indent=2))


if __name__ == "__main__":
    main()
