# TEST REPORT — 2026-09-04 reconstruction

This report distinguishes the uploaded legacy snapshot from the new self-contained benchmark suite. A command is only marked passed when numerical assertions or result-status checks passed; successful script startup alone is not counted.

## Environment

Observed reconstruction environment:

```text
Python 3.13.5
PyTorch 2.10.0+cpu
JAX 0.9.0.1
NumPy 2.3.5
PyYAML 6.0.3
Matplotlib 3.10.8
psutil 7.2.2
Torch CUDA available: false
JAX actual backend: cpu (TFRT_CPU_0)
```

No CUDA/T4 device was visible, so no GPU performance result is claimed.

## 1. Uploaded legacy test snapshot — expected collection failure retained

Command:

```bash
cd source
PYTHONPATH=src pytest -q tests
```

Observed result:

```text
exit code: 2
13 errors during collection
13 errors in 2.00s
```

The errors are structural omissions in the uploaded snapshot, including missing historical files such as:

- `scripts/run_fixed_weight_formal.py`
- `scripts/run_cahn2d_after_poly.py`
- `experiments/archived/other_families/core_method/benchmark_single_monomial.py`
- `experiments/archived/scripts/run_poly_dim_suite.py`
- `experiments/archived/scripts/run_poly_shared_weights.py`
- `experiments/archived/scripts/run_poly_weight_grid.py`
- `experiments/archived/scripts/run_specialized_baseline_pilot.py`

and imports expecting historical experiment paths/modules that are not present in the ZIP (for example `osc_common`). These files were **not fabricated**. The original tests remain under `tests/` for auditability, while `pyproject.toml` points default pytest discovery at `tests_active/`.

## 2. Existing Apolarity core tests that are self-contained — PASS

Command:

```bash
cd source
PYTHONPATH=src pytest -q \
  tests/test_waring_directions.py \
  tests/test_paper_patterns.py \
  tests/test_backend_equivalence.py \
  tests/test_jax_backend.py
```

Observed result:

```text
29 passed, 6 warnings in 13.11s
```

The six warnings are PyTorch warnings about complex-valued `nn.Module` support being under active development; there were no assertion failures.

## 3. New active self-contained numerical tests — PASS

Command:

```bash
cd source
PYTHONPATH=src pytest -q
```

Observed completed pytest summary:

```text
.......... [100%]
10 passed in 30.95s
```

Coverage includes:

- exact theoretical direction counts `9,16,27,32`;
- real float32 square-free `u_123456` schedule;
- all four required fixed-partial values;
- all four fixed-partial parameter gradients versus nested AD;
- KdV2D residual value and parameter-gradient comparison;
- complete g-KdV `case=4, eq=2` gradient-enhanced objective and gradient comparison;
- 2D fourth/sixth-order polyharmonic values and parameter-gradient comparison;
- Torch and standalone JAX implementations;
- config consistency and the absence of `stde` imports from the new mainline implementations.

A later diagnostic rerun in this evaluation container showed JAX process teardown/JIT variability after several tests; the earlier run above reached pytest's final 100% summary with all assertions passed. This runtime issue is why the JAX matrix benchmark uses fresh worker processes and optionally `JAX_BENCH_FORCE_EXIT=1` only after results have been synchronized and written.

## 4. Syntax/import compilation — PASS

Command:

```bash
cd source
python -m compileall -q \
  src experiments/torch_benchmarks \
  experiments/jax_benchmarks/src experiments/jax_benchmarks/run.py \
  scripts tests_active
```

Observed result:

```text
compileall_ok
```

## 5. Torch CPU smoke matrix — PASS, 32/32 rows

Command:

```bash
cd source
PYTHONPATH=src python experiments/torch_benchmarks/run.py \
  --config configs/cpu_smoke.yaml \
  --benchmark all --method both --mode both \
  --device cpu --out results/cpu_smoke/torch
```

Result files:

- `results/cpu_smoke/torch.json`
- `results/cpu_smoke/torch.csv`
- `results/cpu_smoke/torch_frozen_config.yaml`
- `results/cpu_smoke/torch_provenance.json`

Programmatic result check:

```text
rows = 32
status == ok = 32
benchmarks = fixed_mixed_partial, kdv2d, gkdv1d, poly4, poly6
methods = nested_ad, rank_optimal
modes = value, parameter_grad
maximum analytic relative L2 error = 1.123149331760942e-06
maximum parameter-gradient relative L2 error vs nested = 1.4162581010168651e-06
```

Rank-optimal fixed-partial checks from this run:

| case | directions | direction dtype | analytic rel-L2 | parameter-grad rel-L2 vs nested |
|---|---:|---|---:|---:|
| `u_112233` | 9 | complex64 | `1.1780798e-07` | `5.0476444e-07` |
| `u_111222333` | 16 | complex64 | `2.7495341e-07` | `8.0280932e-07` |
| `u_11223344` | 27 | complex64 | `4.7682764e-07` | `3.0333109e-07` |
| `u_123456` | 32 | float32 | `1.1231493e-06` | `1.4162581e-06` |

This confirms that the square-free case stays real float32 and that the repeated-index schedules use complex64 only where required.

## 6. Standalone JAX fixed-partial smoke — PASS

Command:

```bash
cd source/experiments/jax_benchmarks
JAX_BENCH_FORCE_EXIT=1 JAX_PLATFORMS=cpu PYTHONPATH=src python run.py \
  --config configs/cpu_smoke.yaml \
  --benchmark fixed --method rank_optimal --mode value \
  --out ../../results/cpu_smoke/jax_rank_fixed_value
```

Observed result:

```text
exit code = 0
rows = 4
status == ok = 4
maximum analytic relative L2 error = 2.803833240250242e-06
u_112233      directions=9   dtype=complex64
u_111222333   directions=16  dtype=complex64
u_11223344    directions=27  dtype=complex64
u_123456      directions=32  dtype=float32
```

Result/provenance files are included under `results/cpu_smoke/jax_rank_fixed_value*`.

During implementation, individual standalone JAX KdV2D, g-KdV, poly4 and poly6 value/parameter-gradient cases were also executed successfully on CPU. In particular, the sixth-order polyharmonic case completed for both methods; the observed validation errors stayed at approximately `1e-6`--`3e-6` scale. The expensive JAX MLP high-order parameter-gradient JIT was deliberately replaced by the parameterized analytic validation fixture only in the non-publication CPU smoke configuration; the primary config continues to time the MLP.

## 7. Full CPU smoke matrix orchestrator — partial in this container, limitation recorded

Attempted command:

```bash
cd source
python scripts/run_cpu_smoke.py
```

The driver successfully regenerated the full 32-row Torch matrix and completed the first JAX fresh-process workers, but the outer evaluation command exceeded the tool execution window while launching the subsequent fixed rank-optimal worker. This is **not recorded as a benchmark pass**.

The same fixed rank-optimal JAX worker was then executed independently and completed with exit code 0 (see section 6; an earlier isolated measurement completed in 14.35 s). Thus the recorded limitation concerns matrix orchestration/JAX process lifecycle in this CPU container, not a discovered numerical mismatch. The driver preserves per-worker outputs and hard-fails on a nonzero worker status.

For constrained CPU systems, run JAX cases individually as shown in `README.md`; for actual performance measurement, use fresh processes on the target GPU.

## 8. Explicit no-silent-GPU-fallback checks — PASS

### Torch

Command intentionally requesting unavailable CUDA:

```bash
cd source
PYTHONPATH=src python experiments/torch_benchmarks/run.py \
  --config configs/cpu_smoke.yaml --benchmark poly4 \
  --method nested_ad --mode value --device cuda \
  --out /tmp/torch_should_not_exist
```

Observed result: exit code 1 with

```text
RuntimeError: CUDA was requested but torch.cuda.is_available() is false
```

### JAX

Command intentionally requiring an unavailable GPU:

```bash
cd source/experiments/jax_benchmarks
JAX_PLATFORMS=cpu PYTHONPATH=src python run.py \
  --config configs/cpu_smoke.yaml --benchmark poly4 \
  --method nested_ad --mode value --require-gpu \
  --out /tmp/should_not_exist
```

Observed result: exit code 1 with

```text
RuntimeError: --require-gpu was set but no JAX GPU device is visible
```

Therefore a requested CUDA/GPU run cannot be silently mislabeled as CPU. `device: auto` rows additionally carry requested/actual backend and fallback metadata.

## 9. GPU tests not run

Not run because no GPU was visible in the evaluation container:

- T4/CUDA Torch primary benchmark;
- T4/CUDA JAX primary benchmark;
- CUDA peak-memory verification using actual device allocation counters.

Exact GPU-required commands are provided in `README.md`. These are intentionally not marked passed or inferred from CPU execution.

## 10. Final pre-package consistency check — PASS

The final tree was checked programmatically for configuration parity, mainline/reference isolation, and included result integrity:

```text
FINAL_SANITY_OK {
  'torch_rows': 32,
  'jax_rows': 4,
  'stde_import_violations': []
}
```

The check asserts that root/JAX copies of both YAML configs are equal, that the new mainline source contains no `import stde` / `from stde`, that all 32 included Torch smoke rows are `status=ok`, and that all four included JAX fixed-partial rows are `status=ok` with ranks `9,16,27,32` and real float32 directions for `u_123456`.
