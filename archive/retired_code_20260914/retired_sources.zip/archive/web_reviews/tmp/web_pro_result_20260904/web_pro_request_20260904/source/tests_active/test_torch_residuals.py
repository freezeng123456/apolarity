from __future__ import annotations

import copy
import torch

from apolarity.benchmark_models import make_tanh_mlp
from apolarity.benchmark_residuals import kdv2d_residual, gkdv1d_gradient_enhanced_loss, polyharmonic_2d_operator


def flat_grad(model):
    return torch.cat([p.grad.reshape(-1) for p in model.parameters() if p.grad is not None])


def compare_gradients(kind: str):
    dim = 3 if kind == "kdv2d" else 2
    a = make_tanh_mlp(dim, 4, 2, seed=13, dtype=torch.float32, device=torch.device("cpu"))
    b = copy.deepcopy(a)
    x = torch.tensor([[0.12, -0.17, 0.23]], dtype=torch.float32) if dim == 3 else torch.tensor([[0.12, 0.23]], dtype=torch.float32)
    if kind == "kdv2d":
        va = kdv2d_residual(a, x, method="nested_ad"); vb = kdv2d_residual(b, x, method="rank_optimal"); la=va.value.square().mean(); lb=vb.value.square().mean(); assert vb.direction_evaluations == 12
    elif kind == "gkdv1d":
        va = gkdv1d_gradient_enhanced_loss(a, x, method="nested_ad"); vb = gkdv1d_gradient_enhanced_loss(b, x, method="rank_optimal"); la=va.value; lb=vb.value; assert vb.direction_evaluations == 12
        for key in ("f", "f_x", "f_t"): torch.testing.assert_close(vb.components[key], va.components[key], rtol=2e-4, atol=2e-6)
    else:
        order = 4 if kind == "poly4" else 6
        va = polyharmonic_2d_operator(a, x, order=order, method="nested_ad"); vb=polyharmonic_2d_operator(b, x, order=order, method="rank_optimal"); la=va.value.square().mean(); lb=vb.value.square().mean(); assert vb.direction_evaluations == (5 if order==4 else 12)
    torch.testing.assert_close(vb.value, va.value, rtol=5e-4, atol=5e-6)
    la.backward(); lb.backward(); torch.testing.assert_close(flat_grad(b), flat_grad(a), rtol=2e-3, atol=2e-6)


def test_kdv2d_value_and_parameter_gradient(): compare_gradients("kdv2d")
def test_gkdv_case4_eq2_full_gradient_enhanced_value_and_parameter_gradient(): compare_gradients("gkdv1d")
def test_polyharmonic_fourth_value_and_parameter_gradient(): compare_gradients("poly4")
def test_polyharmonic_sixth_value_and_parameter_gradient(): compare_gradients("poly6")
