"""JAX realization of the rank-optimal directional representation.

The public entry point :func:`jax_single_monomial_partial` accepts a scalar
function of one input point.  Model parameters may be closed over by that
function, so ordinary ``jax.grad`` can differentiate a loss containing the
returned partial derivatives with respect to those parameters.

JAX's experimental ``jet`` primitive returns directional derivatives rather
than factorial-normalized Taylor coefficients.  This module therefore divides
the order-``p`` output by ``p!`` before applying the Waring weights used by the
paper.
"""
from __future__ import annotations

import cmath
import itertools
import math
from collections import Counter
from dataclasses import dataclass
from typing import Callable, Iterable

import jax
import jax.numpy as jnp
import numpy as np
from jax.experimental import jet


Array = jax.Array


@dataclass(frozen=True)
class JaxWaringInfo:
    """Metadata for a JAX monomial Waring direction set."""

    order: int
    active_indices: tuple[int, ...]
    active_exponents: tuple[int, ...]
    base_index: int
    rank: int
    alpha_factorial: int


def _alpha_tuple(alpha: Iterable[int]) -> tuple[int, ...]:
    out = tuple(int(i) for i in alpha)
    if not out:
        raise ValueError("alpha must have positive order")
    return out


def _jet_dtype(dtype) -> jnp.dtype:
    dtype = jnp.dtype(dtype)
    if jnp.issubdtype(dtype, jnp.floating) or jnp.issubdtype(
        dtype, jnp.complexfloating
    ):
        return dtype
    raise ValueError(f"x must have a real or complex floating dtype; got {dtype}")


def jax_monomial_waring_directions(
    alpha: Iterable[int],
    d: int,
    *,
    dtype=jnp.complex128,
    root_angle_sign: float = 1.0,
) -> tuple[Array, Array, JaxWaringInfo]:
    """Construct the complex rank-optimal directions for ``partial^alpha``.

    ``alpha`` uses the expanded, zero-based convention: ``(0, 0, 1)`` denotes
    two derivatives in coordinate zero and one derivative in coordinate one.
    The returned arrays ``directions`` and ``weights`` satisfy

    ``partial^alpha u(x) = sum_r weights[r] * T_p(x; directions[r])``.
    """
    complex_dtype = jnp.dtype(dtype)
    if not jnp.issubdtype(complex_dtype, jnp.complexfloating):
        raise ValueError(
            "jax_monomial_waring_directions requires a complex dtype; "
            f"got {complex_dtype}"
        )

    alpha_t = _alpha_tuple(alpha)
    if any(i < 0 or i >= d for i in alpha_t):
        raise ValueError(f"alpha indices {alpha_t} out of range for d={d}")

    counts = Counter(alpha_t)
    active = sorted(counts.items(), key=lambda item: (item[1], item[0]))
    base_index = active[0][0]
    other = active[1:]
    alpha_factorial = math.prod(math.factorial(exp) for exp in counts.values())
    rank = math.prod(exp + 1 for _, exp in other)

    root_lists = [
        [
            cmath.exp(root_angle_sign * 2j * math.pi * k / (exp + 1))
            for k in range(exp + 1)
        ]
        for _, exp in other
    ]
    root_products = itertools.product(*root_lists) if root_lists else [()]

    directions: list[list[complex]] = []
    weights: list[complex] = []
    scale = alpha_factorial / float(rank)
    for roots in root_products:
        direction = [0j] * d
        direction[base_index] = 1.0 + 0j
        weight = complex(scale)
        for (index, _), root in zip(other, roots):
            direction[index] = root
            weight *= root
        directions.append(direction)
        weights.append(weight)

    info = JaxWaringInfo(
        order=len(alpha_t),
        active_indices=tuple(index for index, _ in active),
        active_exponents=tuple(exp for _, exp in active),
        base_index=base_index,
        rank=rank,
        alpha_factorial=alpha_factorial,
    )
    return (
        jnp.asarray(np.asarray(directions), dtype=complex_dtype),
        jnp.asarray(np.asarray(weights), dtype=complex_dtype),
        info,
    )


def jax_directional_taylor_coefficient(
    fun: Callable[[Array], Array],
    x: Array,
    direction: Array,
    order: int,
) -> Array:
    """Evaluate ``T_order(x; direction)`` with ``jax.experimental.jet``."""
    if order < 1:
        raise ValueError(f"order must be positive; got {order}")
    x = jnp.asarray(x)
    direction = jnp.asarray(direction)
    if x.ndim != 1 or direction.shape != x.shape:
        raise ValueError(
            "x and direction must be one-dimensional arrays with the same shape; "
            f"got {x.shape} and {direction.shape}"
        )

    dtype = _jet_dtype(jnp.result_type(x.dtype, direction.dtype))
    point = x.astype(dtype)
    tangent = direction.astype(dtype)
    zero = jnp.zeros_like(tangent)
    series = (tangent,) + tuple(zero for _ in range(order - 1))
    _, output_series = jet.jet(fun, (point,), (series,))
    coefficient = output_series[order - 1] / math.factorial(order)
    if coefficient.ndim != 0:
        raise ValueError(
            "fun must return one scalar for one input point; "
            f"got output shape {coefficient.shape}"
        )
    return coefficient


def jax_single_monomial_partial(
    fun: Callable[[Array], Array],
    x: Array,
    alpha: Iterable[int],
) -> Array:
    """Evaluate one partial derivative by rank-optimal JAX Taylor jets.

    Args:
        fun: A function mapping one input point of shape ``(d,)`` to a scalar.
            The function must admit the complex evaluations used by the Waring
            directions.  Model parameters may be captured by ``fun``.
        x: One point with shape ``(d,)`` or a batch with shape ``(batch, d)``.
        alpha: Expanded zero-based multi-index.

    Returns:
        A complex scalar for one point or a complex vector for a batch.  For a
        real-valued holomorphic extension, the imaginary part is round-off.
    """
    alpha_t = _alpha_tuple(alpha)
    x = jnp.asarray(x)
    if x.ndim not in (1, 2):
        raise ValueError(f"x must have shape (d,) or (batch, d); got {x.shape}")
    d = x.shape[-1]
    if any(i < 0 or i >= d for i in alpha_t):
        raise ValueError(f"alpha indices {alpha_t} out of range for d={d}")

    input_dtype = _jet_dtype(x.dtype)
    complex_dtype = (
        jnp.complex128
        if input_dtype in (jnp.dtype(jnp.float64), jnp.dtype(jnp.complex128))
        else jnp.complex64
    )
    directions, weights, info = jax_monomial_waring_directions(
        alpha_t, d, dtype=complex_dtype
    )
    counts = Counter(alpha_t)
    active = sorted(counts.items(), key=lambda item: (item[1], item[0]))
    needs_complex_directions = any(exp > 1 for _, exp in active[1:])
    if not jnp.issubdtype(x.dtype, jnp.complexfloating) and not needs_complex_directions:
        directions = jnp.real(directions).astype(input_dtype)
        weights = jnp.real(weights).astype(input_dtype)
    order = len(alpha_t)

    if info.rank == 1:
        def at_point(point):
            return weights[0] * jax_directional_taylor_coefficient(
                fun, point, directions[0], order
            )
    else:
        def at_point(point):
            coefficients = jax.vmap(
                lambda direction: jax_directional_taylor_coefficient(
                    fun, point, direction, order
                )
            )(directions)
            return jnp.sum(weights * coefficients)

    return at_point(x) if x.ndim == 1 else jax.vmap(at_point)(x)


__all__ = [
    "JaxWaringInfo",
    "jax_directional_taylor_coefficient",
    "jax_monomial_waring_directions",
    "jax_single_monomial_partial",
]
