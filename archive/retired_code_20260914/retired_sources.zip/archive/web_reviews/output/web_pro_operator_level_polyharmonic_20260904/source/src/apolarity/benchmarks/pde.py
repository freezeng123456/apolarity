"""Method-independent PDE operators used by the benchmark runners.

Each function receives a ``value`` callback and a ``partial`` callback.  The
callbacks are supplied by the nested-AD or rank-optimal backend, so both
methods evaluate exactly the same mathematical residual.  No STDE code is
imported here.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import comb, cos, factorial, pi, sin
from typing import Callable, Iterable, Literal


Partial = Callable[[tuple[int, ...]], object]
DirectionalTaylor = Callable[[tuple[float, float], int], object]


@dataclass(frozen=True)
class PolyharmonicDirectionFormula:
    """Operator-level Waring formula for a two-dimensional Laplacian power.

    The coefficient conventions are

    ``(z_x^2 + z_y^2)^m = sum_r polynomial_weights[r]``
    `` * (directions[r] dot z)^(2m)``

    and

    ``Delta^m u = sum_r taylor_weights[r] * T_(2m)(u; directions[r])``,

    where ``T_p(u; v) = D_v^p u / p!``.  Directions are deliberately scaled
    by two, which makes the Taylor weights ``(m!)^2 / (m+1)``.
    """

    order: int
    power: int
    rank: int
    directions: tuple[tuple[float, float], ...]
    polynomial_weights: tuple[float, ...]
    taylor_weights: tuple[float, ...]
    requires_complex: bool = False


def polyharmonic_2d_direction_formula(order: int) -> PolyharmonicDirectionFormula:
    r"""Return a rank-attaining formula for ``Delta^(order/2)`` in 2D.

    For ``m = order/2`` and ``R=m+1``, set

    ``theta_r = r*pi/R`` and ``v_r = 2(cos(theta_r), sin(theta_r))``.
    Discrete circular orthogonality gives

    ``(z_x^2+z_y^2)^m = 1/(R*binom(2m,m)) * sum_r (v_r dot z)^(2m)``.

    The complex linear change ``X=z_x+i*z_y``, ``Y=z_x-i*z_y`` turns the
    form into ``X^m Y^m``.  The classical binary-monomial rank formula then
    gives complex Waring rank ``m+1``.  Thus the returned real formula attains
    the complex lower bound: rank 3 for the quartic and rank 4 for the sextic.
    """
    if order not in (4, 6):
        raise ValueError("the benchmark supports polyharmonic orders 4 and 6")
    power = order // 2
    rank = power + 1
    polynomial_weight = 1.0 / (rank * comb(order, power))
    taylor_weight = float(factorial(power) ** 2) / rank
    directions = tuple(
        (
            2.0 * cos(index * pi / rank),
            2.0 * sin(index * pi / rank),
        )
        for index in range(rank)
    )
    return PolyharmonicDirectionFormula(
        order=order,
        power=power,
        rank=rank,
        directions=directions,
        polynomial_weights=(polynomial_weight,) * rank,
        taylor_weights=(taylor_weight,) * rank,
    )


def polyharmonic_2d_identity_coefficients(order: int) -> tuple[float, ...]:
    """Expand the directional formula into coefficients of ``z_x^(p-k)z_y^k``."""
    formula = polyharmonic_2d_direction_formula(order)
    coefficients: list[float] = []
    for y_power in range(order + 1):
        coefficient = 0.0
        for direction, weight in zip(
            formula.directions, formula.polynomial_weights
        ):
            vx, vy = direction
            coefficient += (
                weight
                * comb(order, y_power)
                * vx ** (order - y_power)
                * vy**y_power
            )
        coefficients.append(coefficient)
    return tuple(coefficients)


def polyharmonic_2d_identity_max_abs_error(order: int) -> float:
    """Return the coefficientwise error in the operator-level identity."""
    power = order // 2
    actual = polyharmonic_2d_identity_coefficients(order)
    expected = tuple(
        float(comb(power, y_power // 2)) if y_power % 2 == 0 else 0.0
        for y_power in range(order + 1)
    )
    return max(abs(a - b) for a, b in zip(actual, expected))


def _compositions(total: int, parts: int) -> Iterable[tuple[int, ...]]:
    if parts == 1:
        yield (total,)
        return
    for first in range(total + 1):
        for tail in _compositions(total - first, parts - 1):
            yield (first, *tail)


def laplacian_power_terms(
    dimension: int, power: int
) -> list[tuple[float, tuple[int, ...]]]:
    """Expand ``(sum_i partial_i^2)^power`` into monomial terms.

    The returned coefficient is the multinomial coefficient and the expanded
    multi-index contains coordinate ``i`` exactly ``2*k_i`` times.  Terms are
    ordered lexicographically by the exponent composition, which makes JSON
    manifests deterministic.
    """
    if dimension < 1 or power < 1:
        raise ValueError("dimension and power must be positive")
    terms: list[tuple[float, tuple[int, ...]]] = []
    for counts in _compositions(power, dimension):
        coefficient = factorial(power)
        for count in counts:
            coefficient /= factorial(count)
        alpha: list[int] = []
        for coordinate, count in enumerate(counts):
            alpha.extend([coordinate] * (2 * count))
        terms.append((float(coefficient), tuple(alpha)))
    return terms


def kdv2d_residual(partial: Partial, value: Callable[[], object]) -> object:
    """Return the two-dimensional nonlinear KdV residual from STDE.

    Coordinates are ordered ``(x, y, t)`` and the residual is

    ``u_ty + u_xxxy + 3 (u_xy u_x + u_y u_xx) - u_xx + 2 u_yy``.
    """
    u_x = partial((0,))
    u_y = partial((1,))
    u_xx = partial((0, 0))
    u_xy = partial((0, 1))
    u_yy = partial((1, 1))
    u_ty = partial((2, 1))
    u_xxxy = partial((0, 0, 0, 1))
    return u_ty + u_xxxy + 3.0 * (u_xy * u_x + u_y * u_xx) - u_xx + 2.0 * u_yy


def gkdv_residual(
    partial: Partial, value: Callable[[], object]
) -> tuple[object, object, object]:
    """Return ``(f, f_x, f_t)`` for the STDE g-KdV gradient-enhanced case.

    Coordinates are ordered ``(x, t)``.  The dispersive coefficient is the
    official ``0.0025`` value; the returned components are assembled before
    squaring in :func:`gkdv_loss`.
    """
    u = value()
    u_x = partial((0,))
    u_t = partial((1,))
    u_xx = partial((0, 0))
    u_tx = partial((1, 0))
    u_tt = partial((1, 1))
    u_xxx = partial((0, 0, 0))
    u_xxxx = partial((0, 0, 0, 0))
    u_txxx = partial((1, 0, 0, 0))
    f = u_t + u * u_x + 0.0025 * u_xxx
    f_x = u_tx + u_x * u_x + u * u_xx + 0.0025 * u_xxxx
    f_t = u_tt + u_t * u_x + u * u_tx + 0.0025 * u_txxx
    return f, f_x, f_t


def _mean_square(value: object) -> object:
    real = getattr(value, "real", value)
    return (real * real).mean()


def gkdv_loss(
    partial: Partial,
    value: Callable[[], object],
    *,
    gradient_weight: float = 1.0e-3,
) -> object:
    """Return the complete ``eq=2`` gPINN loss used for benchmarking."""
    f, f_x, f_t = gkdv_residual(partial, value)
    return _mean_square(f) + float(gradient_weight) * (
        _mean_square(f_x) + _mean_square(f_t)
    )


def polyharmonic_residual(
    partial: Partial | None = None,
    *,
    dimension: int = 2,
    order: int = 4,
    method: Literal["nested_ad", "rank_optimal"] = "nested_ad",
    directional_taylor: DirectionalTaylor | None = None,
) -> object:
    """Evaluate a Laplacian power with the method-appropriate construction.

    ``nested_ad`` retains the expanded coordinate formula as the reference
    baseline.  ``rank_optimal`` never evaluates those monomials separately;
    it applies the single operator-level Waring formula through a callback for
    ``T_p(u; v)``.  The latter path is intentionally restricted to the two
    two-dimensional operators covered by the benchmark.
    """
    if order < 2 or order % 2:
        raise ValueError("polyharmonic order must be a positive even integer")
    if method == "nested_ad":
        if partial is None:
            raise ValueError("nested_ad requires a partial(alpha) callback")
        power = order // 2
        result = None
        for coefficient, alpha in laplacian_power_terms(dimension, power):
            term = float(coefficient) * partial(alpha)
            result = term if result is None else result + term
        return result
    if method == "rank_optimal":
        if dimension != 2:
            raise ValueError("the operator-level rank-optimal path requires dimension=2")
        if directional_taylor is None:
            raise ValueError(
                "rank_optimal requires a directional_taylor(direction, order) callback"
            )
        formula = polyharmonic_2d_direction_formula(order)
        result = None
        for weight, direction in zip(
            formula.taylor_weights, formula.directions
        ):
            term = float(weight) * directional_taylor(direction, order)
            result = term if result is None else result + term
        return result
    raise ValueError(
        f"unknown method {method!r}; expected 'nested_ad' or 'rank_optimal'"
    )


__all__ = [
    "DirectionalTaylor",
    "PolyharmonicDirectionFormula",
    "gkdv_loss",
    "gkdv_residual",
    "kdv2d_residual",
    "laplacian_power_terms",
    "polyharmonic_2d_direction_formula",
    "polyharmonic_2d_identity_coefficients",
    "polyharmonic_2d_identity_max_abs_error",
    "polyharmonic_residual",
]
