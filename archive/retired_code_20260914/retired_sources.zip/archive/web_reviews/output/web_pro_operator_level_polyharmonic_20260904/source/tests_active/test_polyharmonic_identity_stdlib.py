"""Dependency-light checks for the operator-level polyharmonic formulas.

This file can be run directly with only the package's NumPy dependency:

    PYTHONPATH=src python tests_active/test_polyharmonic_identity_stdlib.py
"""

from __future__ import annotations

from math import comb, factorial, isclose, sqrt

from apolarity.benchmarks.pde import (
    polyharmonic_2d_direction_formula,
    polyharmonic_2d_identity_coefficients,
    polyharmonic_2d_identity_max_abs_error,
    polyharmonic_residual,
)


def test_quartic_and_sextic_operator_identities() -> None:
    expected = {
        4: (
            3,
            1.0 / 18.0,
            4.0 / 3.0,
            ((2.0, 0.0), (1.0, sqrt(3.0)), (-1.0, sqrt(3.0))),
        ),
        6: (
            4,
            1.0 / 80.0,
            9.0,
            (
                (2.0, 0.0),
                (sqrt(2.0), sqrt(2.0)),
                (0.0, 2.0),
                (-sqrt(2.0), sqrt(2.0)),
            ),
        ),
    }
    for order, (
        rank,
        polynomial_weight,
        taylor_weight,
        expected_directions,
    ) in expected.items():
        formula = polyharmonic_2d_direction_formula(order)
        assert formula.rank == rank
        assert formula.requires_complex is False
        assert len(formula.directions) == rank
        assert all(
            isclose(a, b, rel_tol=0.0, abs_tol=1.0e-14)
            for actual, target in zip(formula.directions, expected_directions)
            for a, b in zip(actual, target)
        )
        assert all(
            isclose(weight, polynomial_weight, rel_tol=0.0, abs_tol=1.0e-15)
            for weight in formula.polynomial_weights
        )
        assert all(
            isclose(weight, taylor_weight, rel_tol=0.0, abs_tol=1.0e-14)
            for weight in formula.taylor_weights
        )
        assert polyharmonic_2d_identity_max_abs_error(order) < 2.0e-13

        power = order // 2
        target = tuple(
            float(comb(power, k // 2)) if k % 2 == 0 else 0.0
            for k in range(order + 1)
        )
        actual = polyharmonic_2d_identity_coefficients(order)
        assert all(
            isclose(a, b, rel_tol=0.0, abs_tol=2.0e-13)
            for a, b in zip(actual, target)
        )


def test_backend_independent_operator_callback_uses_rank_many_terms() -> None:
    qx, qy = 0.37, -0.52
    for order, expected_rank in ((4, 3), (6, 4)):
        calls: list[tuple[float, float]] = []

        def taylor(direction: tuple[float, float], degree: int) -> float:
            assert degree == order
            calls.append(direction)
            vx, vy = direction
            return (vx * qx + vy * qy) ** degree / factorial(degree)

        directional = polyharmonic_residual(
            method="rank_optimal",
            dimension=2,
            order=order,
            directional_taylor=taylor,
        )
        expected_value = (qx * qx + qy * qy) ** (order // 2)
        assert len(calls) == expected_rank
        assert isclose(
            float(directional), expected_value, rel_tol=1.0e-12, abs_tol=1.0e-14
        )


if __name__ == "__main__":
    test_quartic_and_sextic_operator_identities()
    test_backend_independent_operator_callback_uses_rank_many_terms()
    print("polyharmonic operator identities: PASS (Delta^2 R=3, Delta^3 R=4)")
