"""Apolarity: Waring directions and Taylor-mode derivative evaluation.

The package API is Torch-based.  The Pro-generated JAX benchmark is kept in
``experiments/jax_benchmarks`` so that it can be installed and tested without
importing this package or the STDE reference implementation.
"""

from .benchmarks import (
    BENCHMARK_METHODS,
    MIXED_TARGETS,
    BenchmarkTarget,
    PolyharmonicDirectionFormula,
    expanded_multi_index,
    monomial_rank,
    polyharmonic_2d_direction_formula,
    polyharmonic_2d_identity_coefficients,
    polyharmonic_2d_identity_max_abs_error,
)

__all__ = [
    "BENCHMARK_METHODS",
    "MIXED_TARGETS",
    "BenchmarkTarget",
    "PolyharmonicDirectionFormula",
    "expanded_multi_index",
    "monomial_rank",
    "polyharmonic_2d_direction_formula",
    "polyharmonic_2d_identity_coefficients",
    "polyharmonic_2d_identity_max_abs_error",
]

try:  # Torch is the default dependency; pure formula checks remain importable without it.
    from .waring import WaringInfo, alpha_factorial_from_counts, monomial_waring_directions
    from .polarization import PolarizationInfo, polarization_directions
    from .taylor_jet import tp_directional_via_jet, tp_directional_all_via_jet
    from .operators import single_monomial_partial
    from .benchmark_multiindex import (
        DirectionSchedule,
        exponent_pattern,
        format_one_based,
        parse_one_based_pattern,
        rank_optimal_schedule,
        theoretical_waring_rank,
    )
    from .benchmark_derivatives import (
        DerivativeMeta,
        monomial_partial,
        rank_optimal_partial_raw,
    )
    from .benchmark_residuals import (
        GKDV1D_TERMS,
        KDV2D_TERMS,
        POLYHARMONIC_2D,
        POLYHARMONIC_2D_EXPANDED_TERMS,
        POLYHARMONIC_2D_RANKS,
        gkdv1d_gradient_enhanced_loss,
        kdv2d_residual,
        polyharmonic_2d_operator,
    )
except ModuleNotFoundError as exc:  # pragma: no cover - dependency-light audit path
    if exc.name != "torch":
        raise
else:
    __all__ += [
        # Torch two-method benchmark API.
        "DirectionSchedule",
        "DerivativeMeta",
        "parse_one_based_pattern",
        "format_one_based",
        "exponent_pattern",
        "theoretical_waring_rank",
        "rank_optimal_schedule",
        "monomial_partial",
        "rank_optimal_partial_raw",
        "KDV2D_TERMS",
        "GKDV1D_TERMS",
        "POLYHARMONIC_2D",
        "POLYHARMONIC_2D_EXPANDED_TERMS",
        "POLYHARMONIC_2D_RANKS",
        "kdv2d_residual",
        "gkdv1d_gradient_enhanced_loss",
        "polyharmonic_2d_operator",
        "WaringInfo",
        "alpha_factorial_from_counts",
        "monomial_waring_directions",
        "PolarizationInfo",
        "polarization_directions",
        "tp_directional_via_jet",
        "tp_directional_all_via_jet",
        "single_monomial_partial",
    ]
