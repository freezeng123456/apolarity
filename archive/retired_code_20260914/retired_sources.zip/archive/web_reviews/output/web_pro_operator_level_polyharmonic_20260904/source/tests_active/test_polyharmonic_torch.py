from __future__ import annotations

import copy

import pytest

torch = pytest.importorskip("torch")
import torch.nn as nn

import apolarity.benchmark_residuals as residuals_module
from apolarity.benchmark_residuals import polyharmonic_2d_operator


class Sin(nn.Module):
    def forward(self, value):
        return torch.sin(value)


def _sin_fixture():
    model = nn.Sequential(nn.Linear(2, 1, bias=True), Sin()).to(torch.float64)
    with torch.no_grad():
        model[0].weight.copy_(torch.tensor([[0.41, -0.27]], dtype=torch.float64))
        model[0].bias.fill_(0.13)
    points = torch.tensor(
        [[0.10, -0.20], [0.25, 0.15], [-0.31, 0.08]], dtype=torch.float64
    )
    return model, points


@pytest.mark.parametrize("order,rank", [(4, 3), (6, 4)])
def test_operator_jet_matches_nested_and_analytic(order: int, rank: int) -> None:
    model, points = _sin_fixture()
    nested = polyharmonic_2d_operator(
        model, points, order=order, method="nested_ad", create_graph=True
    )
    directional = polyharmonic_2d_operator(
        model, points, order=order, method="rank_optimal", create_graph=True
    )
    coefficient_norm = model[0].weight.square().sum()
    expected = (-coefficient_norm) ** (order // 2) * model(points)

    torch.testing.assert_close(nested.value, expected, rtol=2.0e-11, atol=2.0e-12)
    torch.testing.assert_close(
        directional.value, expected, rtol=2.0e-11, atol=2.0e-12
    )
    assert directional.direction_evaluations == rank
    assert directional.operator_formula is not None
    assert directional.operator_formula.rank == rank
    assert len(directional.components) == rank
    assert nested.direction_evaluations is None


def _parameter_vector(model: nn.Module, loss) -> torch.Tensor:
    model.zero_grad(set_to_none=True)
    loss.backward()
    return torch.cat(
        [
            parameter.grad.reshape(-1)
            for parameter in model.parameters()
            if parameter.grad is not None
        ]
    )


@pytest.mark.parametrize("order", [4, 6])
def test_operator_parameter_gradients_match_nested(order: int) -> None:
    torch.manual_seed(19)
    nested_model = nn.Sequential(
        nn.Linear(2, 5), nn.Tanh(), nn.Linear(5, 1)
    ).to(torch.float64)
    directional_model = copy.deepcopy(nested_model)
    points = torch.tensor(
        [[0.08, -0.11], [-0.21, 0.17]], dtype=torch.float64
    )

    nested_value = polyharmonic_2d_operator(
        nested_model, points, order=order, method="nested_ad", create_graph=True
    ).value
    directional_value = polyharmonic_2d_operator(
        directional_model,
        points,
        order=order,
        method="rank_optimal",
        create_graph=True,
    ).value
    nested_grad = _parameter_vector(nested_model, nested_value.square().mean())
    directional_grad = _parameter_vector(
        directional_model, directional_value.square().mean()
    )

    torch.testing.assert_close(
        directional_value, nested_value, rtol=3.0e-9, atol=3.0e-11
    )
    torch.testing.assert_close(
        directional_grad, nested_grad, rtol=2.0e-8, atol=3.0e-10
    )


@pytest.mark.parametrize("order,rank,weight", [(4, 3, 4.0 / 3.0), (6, 4, 9.0)])
def test_rank_path_is_one_batched_jet_and_never_calls_monomials(
    monkeypatch, order: int, rank: int, weight: float
) -> None:
    calls = []

    def reject_monomial(*args, **kwargs):
        raise AssertionError("rank_optimal must not call monomial_partial")

    def capture_jet(model, points, directions, degree):
        calls.append((tuple(directions.shape), degree))
        return torch.ones(
            points.shape[0], directions.shape[1], 1, dtype=points.dtype
        )

    monkeypatch.setattr(residuals_module, "monomial_partial", reject_monomial)
    monkeypatch.setattr(residuals_module, "tp_directional_via_jet", capture_jet)
    points = torch.zeros(2, 2, dtype=torch.float64)
    result = residuals_module.polyharmonic_2d_operator(
        object(), points, order=order, method="rank_optimal"
    )

    assert calls == [((2, rank, 2), order)]
    torch.testing.assert_close(
        result.value, torch.full((2, 1), rank * weight, dtype=torch.float64)
    )
