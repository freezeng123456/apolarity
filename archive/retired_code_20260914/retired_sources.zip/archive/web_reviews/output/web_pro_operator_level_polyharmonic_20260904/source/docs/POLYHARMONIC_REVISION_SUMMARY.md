# Polyharmonic operator-level revision summary

## Outcome

The PyTorch and standalone JAX paths now evaluate the rank-optimal
two-dimensional polyharmonic terms as single homogeneous operators. The
coordinate expansions

\[
  \Delta^2u=u_{xxxx}+2u_{xxyy}+u_{yyyy},
  \qquad
  \Delta^3u=u_{xxxxxx}+3u_{xxxxyy}+3u_{xxyyyy}+u_{yyyyyy}
\]

remain only as independent `nested_ad` references. They are not used to
construct the rank-optimal directional schedule.

The corrected identities are

\[
  \Delta^2u=\frac1{18}\sum_{v\in V_4}D_v^4u
            =\frac43\sum_{v\in V_4}T_4[u](x;v),
\]

with
\(V_4=\{(2,0),(1,\sqrt3),(-1,\sqrt3)\}\), and

\[
  \Delta^3u=\frac1{80}\sum_{v\in V_6}D_v^6u
            =9\sum_{v\in V_6}T_6[u](x;v),
\]

with
\(V_6=\{(2,0),(\sqrt2,\sqrt2),(0,2),(-\sqrt2,\sqrt2)\}\).
The middle-catalecticant lower bound after
\(a=z_x+i z_y,\ b=z_x-i z_y\) proves complex Waring ranks
\(R_{\mathbb C}=3\) and \(R_{\mathbb C}=4\). The complete derivation is in
`polyharmonic_operator_waring.md`.

## API and metadata changes

### PyTorch/main package

- `apolarity.benchmarks.pde.PolyharmonicDirectionFormula` records the
  order, Laplacian power, rank, directions, polynomial weights, and
  Taylor-coefficient weights.
- `polyharmonic_2d_direction_formula(order)` constructs the operator
  schedule; `polyharmonic_2d_identity_coefficients(order)` and
  `polyharmonic_2d_identity_max_abs_error(order)` validate it
  coefficient by coefficient.
- `benchmark_residuals.polyharmonic_2d_operator` uses one batched
  directional Taylor-jet call for `rank_optimal` and returns
  `ResidualEvaluation.operator_formula`. The nested baseline still uses the
  expanded coordinate expression.
- `POLYHARMONIC_2D_EXPANDED_TERMS` names that reference expansion.
  `POLYHARMONIC_2D` remains an alias for callers that inspected the old
  constant; it is not a rank-optimal schedule.
- Polyharmonic result rows add `operator_form`, `operator_strategy`, `operator_waring_rank`,
  `theoretical_direction_count`, `operator_directions`,
  `operator_polynomial_weights`, `operator_taylor_weights`,
  `operator_identity_max_abs_error`, and `requires_complex=false`.

### Standalone JAX package

- `HomogeneousOperatorSchedule` and `OperatorIdentityValidation`
  carry the schedule and validation data.
- New public helpers are `polyharmonic_2d_complex_waring_rank(order)`,
  `polyharmonic_2d_schedule(order, real_dtype=...)`, and
  `validate_polyharmonic_2d_identity(order)`.
- `POLYHARMONIC_2D_EXPANDED_TERMS` is used only by `nested_ad`;
  the rank-optimal branch batches the three or four directions directly.
- Result rows record the operator representation, complex Waring rank,
  explicit directions/form weights/Taylor weights, represented and expected
  polynomial coefficients, identity error, direction dtype, and
  `requires_complex=false`.

### Configuration

The primary and CPU-smoke configurations use:

~~~yaml
polyharmonic:
  operator_assembly: single_homogeneous_waring
  operator_direction_counts:
    4: 3
    6: 4
~~~

The CPU-smoke protocol remains non-publication. The main protocol retains
float32, the original network/batch settings, both mainline methods, and no
direction chunking.

The root package now declares NumPy explicitly because its public benchmark
metadata/fixture module imports NumPy during package initialization.

## Verification in this revision

| check | status | detail |
|---|---|---|
| Dependency-light operator identity suite | passed | 2 tests; verifies ranks, both polynomial identities, weights, and exactly 3/4 callback evaluations |
| Python byte compilation | passed | `compileall` over package, runners, and focused tests |
| YAML parsing/invariants | passed | all four current PyTorch/JAX configs parse and record assembly `single_homogeneous_waring` with counts `{4: 3, 6: 4}` |
| Standalone JAX tests | passed | 7 tests |
| JAX CPU polyharmonic smoke | passed | 8/8 rows: both operators, both methods, value and parameter-gradient modes |
| JAX CPU all-family value smoke | passed | 16/16 rows, including fixed partials, KdV, g-KdV, and both polyharmonic operators |
| Root PyTorch-focused pytest suite | passed | 8 tests total with PyTorch 2.2.2+cpu in an isolated CPU dependency directory (2 dependency-light identity tests and 6 Torch cases); covers analytic values, 3/4 directions, nested-AD agreement, and parameter gradients |
| PyTorch CPU polyharmonic smoke | passed | 8/8 rows: both operators, both methods, value and parameter-gradient modes |
| PyTorch CPU all-family value smoke | passed | 16/16 rows, including fixed partials, KdV, g-KdV, and both polyharmonic operators |
| Primary GPU benchmark | not rerun | required before publishing replacement timing, memory, or speedup values |

For the JAX CPU polyharmonic smoke, the coefficientwise float64 identity errors
were \(6.91\times10^{-16}\) for \(\Delta^2\) and
\(3.33\times10^{-16}\) for \(\Delta^3\). The float32 rank-path analytic
relative errors were \(9.78\times10^{-7}\) and \(1.83\times10^{-6}\);
the corresponding parameter-gradient discrepancies versus nested AD were
\(1.82\times10^{-6}\) and \(3.15\times10^{-6}\). These are correctness/smoke
results, not publication timing measurements.

For the PyTorch CPU polyharmonic smoke, the operator-identity errors were
\(7.22\times10^{-16}\) and \(3.33\times10^{-16}\). The float32
rank-path analytic relative errors were zero and \(1.25\times10^{-7}\), and
the parameter-gradient discrepancies versus nested AD were
\(3.47\times10^{-7}\) and \(4.01\times10^{-7}\). PyTorch was supplied from
an isolated CPU-only dependency directory because it was not installed in the
base packaging interpreter. These are likewise correctness/smoke results, not
publication timings.

## Rerun versus stale results

- **Rerun:** dependency-light identities, configuration checks, byte
  compilation, the focused PyTorch and JAX tests, and both CPU polyharmonic
  smoke matrices described above.
- **Not rerun:** all primary GPU performance measurements.
- **Stale:** every preserved T4 polyharmonic performance record based on five
  or twelve monomial-schedule directions, plus the legacy versions of figures
  or numerical claims computed from those records. The figures shipped with
  this revision were rebuilt to omit the polyharmonic records explicitly.
- **Preserved historical context:** fixed-partial, KdV, and g-KdV T4 rows have
  unchanged mathematical definitions, but they were not rerun from this source
  revision. The `context/poly_d2_o4` and `context/poly_d2_o6`
  `jsc_v2` training bundles are also untouched historical provenance and
  do not validate this operator-level microbenchmark.

No old polyharmonic timing has been relabelled as a measurement of the new
three- or four-direction implementation.
