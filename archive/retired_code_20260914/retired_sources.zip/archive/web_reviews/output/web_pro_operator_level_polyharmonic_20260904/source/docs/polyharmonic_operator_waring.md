# Operator-level Waring formulas for the two-dimensional polyharmonic benchmarks

## Convention

Let \(z=(z_x,z_y)\), \(v=(v_x,v_y)\), and

\[
  D_v=v_x\partial_x+v_y\partial_y,
  \qquad
  T_p[u](x;v)=[t^p]u(x+t v)=\frac{1}{p!}D_v^p u(x).
\]

The implementation weights reported below multiply the Taylor coefficients
\(T_p\). The corresponding polynomial weights multiply
\((v\mathbin{\cdot}z)^p\), or equivalently the directional derivatives
\(D_v^p u\).

## Ranks and explicit schedules

The implementation uses directions scaled to avoid fractions. For the
biharmonic operator, take

\[
  v_0=(2,0),\qquad
  v_1=(1,\sqrt3),\qquad
  v_2=(-1,\sqrt3).
\]

Direct expansion gives

\[
  \sum_{j=0}^{2}(v_j\mathbin{\cdot}z)^4
  =18(z_x^2+z_y^2)^2.
\]

Consequently,

\[
  \Delta^2u
  =\frac1{18}\sum_{j=0}^{2}D_{v_j}^{4}u
  =\frac43\sum_{j=0}^{2}T_4[u](x;v_j).
\]

Thus the polynomial/directional-derivative weight is \(1/18\), the Taylor
coefficient weight is \(4!/18=4/3\), and the schedule has exactly three
directions.

For the sixth-order operator, take

\[
  w_0=(2,0),\qquad
  w_1=(\sqrt2,\sqrt2),\qquad
  w_2=(0,2),\qquad
  w_3=(-\sqrt2,\sqrt2).
\]

Again, expansion gives

\[
  \sum_{j=0}^{3}(w_j\mathbin{\cdot}z)^6
  =80(z_x^2+z_y^2)^3,
\]

and hence

\[
  \Delta^3u
  =\frac1{80}\sum_{j=0}^{3}D_{w_j}^{6}u
  =9\sum_{j=0}^{3}T_6[u](x;w_j).
\]

Here the polynomial/directional-derivative weight is \(1/80\), the Taylor
coefficient weight is \(6!/80=9\), and the schedule has exactly four
directions. All displayed directions and weights are real, so the
polyharmonic operator schedules do not require complex-valued model
evaluation even though their ranks are ranks over \(\mathbb C\).

| operator | binary form | complex Waring rank | directions | weight on \(D_v^p\) | weight on \(T_p\) |
|---|---|---:|---:|---:|---:|
| \(\Delta^2\) | \((z_x^2+z_y^2)^2\) | 3 | 3 | \(1/18\) | \(4/3\) |
| \(\Delta^3\) | \((z_x^2+z_y^2)^3\) | 4 | 4 | \(1/80\) | \(9\) |

## Why the ranks are minimal

Over \(\mathbb C\), make the invertible linear change of variables
\(a=z_x+i z_y\), \(b=z_x-i z_y\). Then

\[
  (z_x^2+z_y^2)^m=a^m b^m.
\]

The middle catalecticant of the binary form \(a^m b^m\), viewed as a map
from degree-\(m\) differential operators to degree-\(m\) forms, has image

\[
  \operatorname{span}\{a^m,a^{m-1}b,\ldots,b^m\}
\]

and therefore rank \(m+1\). The middle catalecticant of a single
\(2m\)-th power has rank at most one, so a sum of \(R\) powers has
catalecticant rank at most \(R\). This proves the lower bound \(R\ge m+1\).
The explicit schedules above attain that bound for \(m=2\) and \(m=3\),
proving complex Waring ranks three and four, respectively.

Equivalently, for these two cases the implementation directions
\(q_j=2(\cos\theta_j,\sin\theta_j)\) are equally spaced unoriented lines and
obey the finite circular-design identity

\[
  \sum_{j=0}^{m}(q_j\mathbin{\cdot}z)^{2m}
  =(m+1)\binom{2m}{m}(z_x^2+z_y^2)^m,
  \qquad \theta_j=\frac{j\pi}{m+1}.
\]

Therefore the general polynomial weight in this scaling is
\(1/((m+1)\binom{2m}{m})\), and its Taylor-coefficient weight is
\((2m)!/((m+1)\binom{2m}{m})=(m!)^2/(m+1)\). Unit-normalizing the directions
gives the equivalent weights \(8/9,64/3\) for order four and \(4/5,576\) for
order six; those are not the scaling stored by the implementation.

## Implementation and validation contract

- `rank_optimal` requests one homogeneous operator schedule, not one
  monomial schedule for each term in a binomial expansion.
- The reported `evaluated_direction_count` is three for `poly4` and four
  for `poly6`. The configuration records the same invariant under
  `polyharmonic.operator_direction_counts`.
- `nested_ad` remains the independent coordinate-autodifferentiation baseline
  for the same \(\Delta^2u\) or \(\Delta^3u\) value.
- Operator validation expands the displayed polynomial identities and compares
  both values and parameter gradients against `nested_ad` and analytic
  manufactured solutions.
- Fixed mixed partials, KdV, and g-KdV retain their existing monomial or
  termwise schedules. The operator-level construction here applies only to
  the two polyharmonic cases.

## Measurement status

The preserved Tesla T4 bundle dated 2026-09-04 predates this correction. Its
polyharmonic records used separate monomial schedules and reported five and
twelve direction evaluations. All such records, and any plots or manuscript
claims derived from them, are **stale** and are not evidence for the revised
three- and four-direction implementation. They remain in `context/` only for
provenance. No replacement T4 performance numbers are asserted by this
mathematical note. Current-code correctness tests and any newly generated CPU
smoke output are validation artifacts, not replacements for a primary T4
timing rerun.
