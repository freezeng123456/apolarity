"""Shared benchmark operators for the two-method derivative comparison.

The benchmark namespace deliberately contains only the two methods that are
compared in the paper: ``nested_ad`` and ``rank_optimal``.  The STDE source
used to reproduce reference settings is kept under ``reference/`` and is not
imported by this package.
"""

from .common import (
    BENCHMARK_METHODS,
    MIXED_TARGETS,
    BenchmarkTarget,
    expanded_multi_index,
    monomial_rank,
)
from .pde import (
    PolyharmonicDirectionFormula,
    gkdv_residual,
    gkdv_loss,
    kdv2d_residual,
    laplacian_power_terms,
    polyharmonic_2d_direction_formula,
    polyharmonic_2d_identity_coefficients,
    polyharmonic_2d_identity_max_abs_error,
    polyharmonic_residual,
)

__all__ = [
    "BENCHMARK_METHODS",
    "MIXED_TARGETS",
    "BenchmarkTarget",
    "PolyharmonicDirectionFormula",
    "expanded_multi_index",
    "monomial_rank",
    "gkdv_residual",
    "gkdv_loss",
    "kdv2d_residual",
    "laplacian_power_terms",
    "polyharmonic_2d_direction_formula",
    "polyharmonic_2d_identity_coefficients",
    "polyharmonic_2d_identity_max_abs_error",
    "polyharmonic_residual",
]
