# Polyharmonic rows are stale

This directory is an immutable historical T4 result bundle produced before the
operator-level polyharmonic revision.  Its raw `torch.json` and `torch.csv`
files are preserved for provenance, but every `poly4` and `poly6` record uses
the obsolete termwise rank-optimal assembly (reported direction counts 5 and
12).  Those records must not be cited as measurements of the current
implementation.

The current implementation evaluates the complete symbols
`(z_x^2 + z_y^2)^2` and `(z_x^2 + z_y^2)^3` with ranks 3 and 4,
respectively.  No replacement T4 timing or memory run was performed in this
revision.  The fixed-partial, KdV2D, and g-KdV definitions were unchanged, so
their historical records remain usable with their original provenance.

The paper figures were rebuilt to omit the stale polyharmonic records.  See
`../../docs/polyharmonic_operator_waring.md` and `run_card.json` for the
current formula and the original run provenance.
