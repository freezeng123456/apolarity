#!/usr/bin/env python3
"""Rebuild the T4 figures without the stale polyharmonic measurements.

The stored T4 run predates the operator-level Delta^2/Delta^3 schedules and
therefore contains obsolete rank-optimal rows for those two cases.  This
script deliberately plots only the unchanged fixed-partial, KdV2D, and g-KdV
rows.  It never rewrites the raw historical result bundle.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
SOURCE_ROOT = HERE.parents[2]
DEFAULT_INPUT = (
    SOURCE_ROOT / "context" / "t4_primary_graphfree_20260904" / "torch.json"
)

CASES = (
    ("fixed_mixed_partial", "u_112233", r"$u_{112233}$"),
    ("fixed_mixed_partial", "u_111222333", r"$u_{111222333}$"),
    ("fixed_mixed_partial", "u_11223344", r"$u_{11223344}$"),
    ("fixed_mixed_partial", "u_123456", r"$u_{123456}$"),
    ("kdv2d", "kdv2d", "KdV2D"),
    ("gkdv1d", "gkdv1d", "g-KdV"),
)

STALE_NOTE = (
    r"$\Delta^2$ and $\Delta^3$ omitted: operator-level rank-3/rank-4 "
    "schedules have not been rerun on the T4."
)


def _index(rows: list[dict]) -> dict[tuple[str, str, str, str], dict]:
    indexed: dict[tuple[str, str, str, str], dict] = {}
    for row in rows:
        key = (
            str(row.get("benchmark")),
            str(row.get("case")),
            str(row.get("method")),
            str(row.get("mode")),
        )
        indexed[key] = row
    return indexed


def _row(indexed: dict, benchmark: str, case: str, method: str, mode: str) -> dict:
    key = (benchmark, case, method, mode)
    if key not in indexed:
        raise KeyError(f"historical result row is missing: {key}")
    row = indexed[key]
    if row.get("status") != "ok":
        raise ValueError(f"historical result row is not valid: {key}")
    return row


def _style_axis(ax) -> None:
    ax.grid(axis="y", which="both", alpha=0.28, linewidth=0.7)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def runtime_figure(indexed: dict, output: Path) -> None:
    labels = [item[2] for item in CASES]
    x = np.arange(len(CASES))
    width = 0.36
    fig, axes = plt.subplots(1, 2, figsize=(9.9, 4.35), sharey=True)
    for ax, mode, title in zip(
        axes,
        ("value", "parameter_grad"),
        ("Derivative value", "Parameter gradient"),
    ):
        nested = [
            _row(indexed, b, c, "nested_ad", mode)["median_ms"] for b, c, _ in CASES
        ]
        rank = [
            _row(indexed, b, c, "rank_optimal", mode)["median_ms"]
            for b, c, _ in CASES
        ]
        ax.bar(x - width / 2, nested, width, label="Nested AD", color="#4C78A8")
        ax.bar(x + width / 2, rank, width, label="Rank-optimal", color="#F58518")
        ax.set_title(title)
        ax.set_yscale("log")
        ax.set_xticks(x, labels, rotation=34, ha="right")
        _style_axis(ax)
    axes[0].set_ylabel("Median time (ms)")
    axes[0].legend(frameon=False, loc="upper left")
    fig.text(0.5, 0.012, STALE_NOTE, ha="center", va="bottom", fontsize=9)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    fig.savefig(output, bbox_inches="tight")
    plt.close(fig)


def speedup_figure(indexed: dict, output: Path) -> None:
    labels = [item[2] for item in CASES]
    y = np.arange(len(CASES))
    height = 0.36
    fig, ax = plt.subplots(figsize=(8.9, 4.35))
    for offset, mode, label, color in (
        (-height / 2, "value", "Value", "#4C78A8"),
        (height / 2, "parameter_grad", "Parameter gradient", "#F58518"),
    ):
        ratios = []
        for benchmark, case, _ in CASES:
            nested = _row(indexed, benchmark, case, "nested_ad", mode)["median_ms"]
            rank = _row(indexed, benchmark, case, "rank_optimal", mode)["median_ms"]
            ratios.append(nested / rank)
        ax.barh(y + offset, ratios, height, label=label, color=color)
    ax.axvline(1.0, color="#555555", linewidth=1.0, linestyle="--")
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlabel("Nested AD time / rank-optimal time")
    ax.set_title("Rank-optimal speedup on the T4: unchanged cases")
    ax.grid(axis="x", alpha=0.28, linewidth=0.7)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(frameon=False)
    fig.text(0.5, 0.012, STALE_NOTE, ha="center", va="bottom", fontsize=9)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    fig.savefig(output, bbox_inches="tight")
    plt.close(fig)


def memory_figure(indexed: dict, output: Path) -> None:
    labels = [item[2] for item in CASES]
    ratios = []
    for benchmark, case, _ in CASES:
        nested = _row(indexed, benchmark, case, "nested_ad", "value")[
            "peak_memory_bytes"
        ]
        rank = _row(indexed, benchmark, case, "rank_optimal", "value")[
            "peak_memory_bytes"
        ]
        ratios.append(nested / rank)
    x = np.arange(len(CASES))
    fig, ax = plt.subplots(figsize=(8.9, 4.35))
    bars = ax.bar(x, ratios, color="#4C78A8", width=0.64)
    ax.axhline(1.0, color="#555555", linewidth=1.0, linestyle="--")
    ax.set_xticks(x, labels, rotation=34, ha="right")
    ax.set_ylabel("Nested AD peak / rank-optimal peak")
    ax.set_title("CUDA peak allocation ratio (value mode): unchanged cases")
    for bar, ratio in zip(bars, ratios):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.035,
            f"{ratio:.2f}",
            ha="center",
            va="bottom",
            fontsize=9,
        )
    ax.set_ylim(0, max(1.15, max(ratios) * 1.22))
    _style_axis(ax)
    fig.text(0.5, 0.012, STALE_NOTE, ha="center", va="bottom", fontsize=9)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    fig.savefig(output, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-dir", type=Path, default=HERE)
    args = parser.parse_args()
    rows = json.loads(args.input.read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        raise TypeError("expected the historical result JSON to contain a row list")
    indexed = _index(rows)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    runtime_figure(indexed, args.output_dir / "fig_benchmark_t4_runtime.pdf")
    speedup_figure(indexed, args.output_dir / "fig_benchmark_t4_speedup.pdf")
    memory_figure(indexed, args.output_dir / "fig_benchmark_t4_memory.pdf")


if __name__ == "__main__":
    main()
