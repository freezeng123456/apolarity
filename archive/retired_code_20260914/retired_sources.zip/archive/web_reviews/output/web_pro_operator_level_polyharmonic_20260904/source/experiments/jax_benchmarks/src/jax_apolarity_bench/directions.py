from __future__ import annotations

import cmath
import itertools
import math
from collections import Counter
from dataclasses import dataclass
from typing import Iterable

import jax.numpy as jnp
import numpy as np


@dataclass(frozen=True)
class DirectionSchedule:
    alpha: tuple[int, ...]
    order: int
    active_indices: tuple[int, ...]
    active_exponents: tuple[int, ...]
    base_index: int
    theoretical_rank: int
    alpha_factorial: int
    requires_complex: bool
    directions: jnp.ndarray
    weights: jnp.ndarray


@dataclass(frozen=True)
class HomogeneousOperatorSchedule:
    """A Waring schedule for one complete homogeneous operator symbol.

    ``form_weights`` multiply powers of linear forms in the polynomial
    identity, while ``taylor_weights`` multiply normalized Taylor
    coefficients ``[t**order] f(x + t v)``.  Consequently,
    ``taylor_weights == order! * form_weights``.
    """

    operator_name: str
    order: int
    laplacian_power: int
    theoretical_rank: int
    requires_complex: bool
    directions: jnp.ndarray
    form_weights: jnp.ndarray
    taylor_weights: jnp.ndarray


@dataclass(frozen=True)
class OperatorIdentityValidation:
    order: int
    theoretical_rank: int
    expected_coefficients: tuple[float, ...]
    represented_coefficients: tuple[float, ...]
    max_abs_error: float


def parse_one_based_pattern(pattern: str) -> tuple[int, ...]:
    text = pattern.strip().replace("u_", "").replace("_", "")
    if not text or not text.isdigit() or "0" in text:
        raise ValueError(f"invalid one-based pattern {pattern!r}")
    return tuple(int(ch) - 1 for ch in text)


def exponent_pattern(alpha: Iterable[int]) -> tuple[int, ...]:
    return tuple(sorted(Counter(int(i) for i in alpha).values(), reverse=True))


def theoretical_waring_rank(alpha: Iterable[int]) -> int:
    alpha_t = tuple(int(i) for i in alpha)
    if not alpha_t:
        raise ValueError("alpha must have positive order")
    exps = sorted(Counter(alpha_t).values())
    return math.prod(e + 1 for e in exps[1:]) if len(exps) > 1 else 1


def rank_optimal_schedule(
    alpha: Iterable[int], d: int, *, real_dtype=jnp.float32
) -> DirectionSchedule:
    alpha_t = tuple(int(i) for i in alpha)
    if not alpha_t:
        raise ValueError("alpha must have positive order")
    if any(i < 0 or i >= d for i in alpha_t):
        raise ValueError(f"alpha indices {alpha_t} out of range for d={d}")
    real_dtype = jnp.dtype(real_dtype)
    if real_dtype not in (jnp.dtype(jnp.float32), jnp.dtype(jnp.float64)):
        raise ValueError(f"real_dtype must be float32/float64; got {real_dtype}")
    counts = Counter(alpha_t)
    active = sorted(counts.items(), key=lambda kv: (kv[1], kv[0]))
    base = active[0][0]
    other = active[1:]
    rank = math.prod(exp + 1 for _, exp in other) if other else 1
    alpha_factorial = math.prod(math.factorial(exp) for exp in counts.values())
    requires_complex = any(exp > 1 for _, exp in other)
    dtype = (
        jnp.complex64
        if (requires_complex and real_dtype == jnp.float32)
        else (jnp.complex128 if requires_complex else real_dtype)
    )
    root_lists = []
    for _, exp in other:
        m = exp + 1
        if m == 2 and not requires_complex:
            root_lists.append([1.0, -1.0])
        else:
            root_lists.append([cmath.exp(2j * math.pi * k / m) for k in range(m)])
    products = itertools.product(*root_lists) if root_lists else [()]
    directions, weights = [], []
    scale = alpha_factorial / float(rank)
    for roots in products:
        v = [0j if requires_complex else 0.0 for _ in range(d)]
        v[base] = 1.0
        w = complex(scale) if requires_complex else float(scale)
        for (idx, _), root in zip(other, roots):
            v[idx] = root
            w = w * root
        if not requires_complex:
            v = [float(complex(z).real) for z in v]
            w = float(complex(w).real)
        directions.append(v)
        weights.append(w)
    return DirectionSchedule(
        alpha=alpha_t,
        order=len(alpha_t),
        active_indices=tuple(i for i, _ in active),
        active_exponents=tuple(e for _, e in active),
        base_index=base,
        theoretical_rank=rank,
        alpha_factorial=alpha_factorial,
        requires_complex=requires_complex,
        directions=jnp.asarray(np.asarray(directions), dtype=dtype),
        weights=jnp.asarray(np.asarray(weights), dtype=dtype),
    )


def polyharmonic_2d_complex_waring_rank(order: int) -> int:
    """Return the complex Waring rank of ``(z_x**2 + z_y**2)**(order/2)``.

    With the invertible complex change of variables
    ``X = z_x + i z_y`` and ``Y = z_x - i z_y``, the symbol becomes
    ``X**m * Y**m`` for ``m = order/2``.  The binary-monomial rank formula
    gives rank ``m + 1``.  The real, equally spaced construction returned by
    :func:`polyharmonic_2d_schedule` attains that lower bound.
    """

    if order not in (4, 6):
        raise ValueError("polyharmonic order must be 4 or 6")
    return order // 2 + 1


def polyharmonic_2d_schedule(
    order: int, *, real_dtype=jnp.float32
) -> HomogeneousOperatorSchedule:
    r"""Build the rank-attaining schedule for the complete 2D operator.

    For ``order = 2m`` and ``r = m + 1``, let

    ``v_k = 2 (cos(k*pi/r), sin(k*pi/r)),  k = 0, ..., r-1``.

    Discrete Fourier cancellation of every nonconstant angular harmonic of
    degree ``2m`` yields

    ``(z_x^2 + z_y^2)^m = c_m sum_k (v_k . z)^(2m)``,

    where ``c_m = 1 / (r * binom(2m,m))``.  Taylor-jet coefficients are
    normalized by ``order!``, so their weights are ``(m!)^2/r``: ``4/3``
    for ``Delta^2`` and ``9`` for ``Delta^3``.  Equivalently, unit directions
    have form weights ``8/9`` and ``4/5``, respectively.
    """

    rank = polyharmonic_2d_complex_waring_rank(order)
    dtype = jnp.dtype(real_dtype)
    if dtype not in (jnp.dtype(jnp.float32), jnp.dtype(jnp.float64)):
        raise ValueError(f"real_dtype must be float32/float64; got {dtype}")
    m = order // 2
    angles = np.arange(rank, dtype=np.float64) * (math.pi / rank)
    directions = 2.0 * np.stack((np.cos(angles), np.sin(angles)), axis=1)
    form_weight = 1.0 / (rank * math.comb(order, m))
    taylor_weight = math.factorial(order) * form_weight
    return HomogeneousOperatorSchedule(
        operator_name=f"Delta^{m}",
        order=order,
        laplacian_power=m,
        theoretical_rank=rank,
        requires_complex=False,
        directions=jnp.asarray(directions, dtype=dtype),
        form_weights=jnp.full((rank,), form_weight, dtype=dtype),
        taylor_weights=jnp.full((rank,), taylor_weight, dtype=dtype),
    )


def validate_polyharmonic_2d_identity(order: int) -> OperatorIdentityValidation:
    """Verify the Waring identity coefficient-by-coefficient in float64.

    Coefficient index ``j`` denotes the coefficient of
    ``z_x**(order-j) * z_y**j``.  This validation is deliberately performed
    with NumPy float64, independently of the JAX execution dtype.
    """

    rank = polyharmonic_2d_complex_waring_rank(order)
    m = order // 2
    angles = np.arange(rank, dtype=np.float64) * (math.pi / rank)
    vx, vy = 2.0 * np.cos(angles), 2.0 * np.sin(angles)
    form_weight = 1.0 / (rank * math.comb(order, m))
    represented = tuple(
        float(
            form_weight
            * math.comb(order, j)
            * np.sum(vx ** (order - j) * vy**j)
        )
        for j in range(order + 1)
    )
    expected = tuple(
        float(math.comb(m, j // 2)) if j % 2 == 0 else 0.0
        for j in range(order + 1)
    )
    error = max(abs(a - b) for a, b in zip(represented, expected))
    return OperatorIdentityValidation(
        order=order,
        theoretical_rank=rank,
        expected_coefficients=expected,
        represented_coefficients=represented,
        max_abs_error=float(error),
    )
