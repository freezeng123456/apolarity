"""Exact PDE residual definitions used by the two-method benchmark.

The equations below are transcribed from the supplied upstream STDE
``stde/equations.py``.  STDE itself is not imported at runtime.
"""

from __future__ import annotations

from contextlib import nullcontext
from dataclasses import dataclass
from typing import Callable

import torch
import torch.nn as nn
from torch import Tensor

from .benchmark_derivatives import Method, monomial_partial
from .benchmarks.pde import (
    PolyharmonicDirectionFormula,
    polyharmonic_2d_direction_formula,
)
from .taylor_jet import tp_directional_via_jet


KDV2D_TERMS: dict[str, tuple[int, ...]] = {
    "u_x": (0,),
    "u_y": (1,),
    "u_xx": (0, 0),
    "u_xy": (0, 1),
    "u_yy": (1, 1),
    "u_ty": (1, 2),
    "u_xxxy": (0, 0, 0, 1),
}

GKDV1D_TERMS: dict[str, tuple[int, ...]] = {
    "u_x": (0,),
    "u_t": (1,),
    "u_xx": (0, 0),
    "u_tx": (1, 0),
    "u_tt": (1, 1),
    "u_xxx": (0, 0, 0),
    "u_xxxx": (0, 0, 0, 0),
    "u_txxx": (1, 0, 0, 0),
}

# Coordinate expansions are retained only for the nested-AD reference.  The
# rank-optimal path below applies the homogeneous operator as one Waring form.
POLYHARMONIC_2D_EXPANDED_TERMS: dict[
    int, tuple[tuple[float, tuple[int, ...]], ...]
] = {
    4: (
        (1.0, (0, 0, 0, 0)),
        (2.0, (0, 0, 1, 1)),
        (1.0, (1, 1, 1, 1)),
    ),
    6: (
        (1.0, (0, 0, 0, 0, 0, 0)),
        (3.0, (0, 0, 0, 0, 1, 1)),
        (3.0, (0, 0, 1, 1, 1, 1)),
        (1.0, (1, 1, 1, 1, 1, 1)),
    ),
}

# Backward-compatible name for callers that inspect the reference expansion.
# It is not a direction schedule and is never used term by term by rank_optimal.
POLYHARMONIC_2D = POLYHARMONIC_2D_EXPANDED_TERMS
POLYHARMONIC_2D_RANKS: dict[int, int] = {
    order: polyharmonic_2d_direction_formula(order).rank for order in (4, 6)
}


@dataclass
class ResidualEvaluation:
    value: Tensor
    components: dict[str, Tensor]
    direction_evaluations: int | None
    max_derivative_order: int
    operator_formula: PolyharmonicDirectionFormula | None = None


def _partials(
    model: nn.Module,
    x: Tensor,
    terms: dict[str, tuple[int, ...]],
    method: Method,
    *,
    create_graph: bool = True,
):
    out: dict[str, Tensor] = {}
    total = 0
    for name, alpha in terms.items():
        value, meta = monomial_partial(
            model, x, alpha, method=method, create_graph=create_graph
        )
        out[name] = value
        if meta.direction_count is not None:
            total += meta.direction_count
    return out, total if method == "rank_optimal" else None


def kdv2d_residual(
    model: nn.Module,
    xyt: Tensor,
    *,
    method: Method,
    create_graph: bool = True,
) -> ResidualEvaluation:
    """2-D nonlinear KdV residual from upstream ``KdV2d_res``.

    ``r = u_ty + u_xxxy + 3(u_xy u_x + u_y u_xx) - u_xx + 2 u_yy``.
    Coordinates are ``(x,y,t)``.
    """
    if xyt.shape[-1] != 3:
        raise ValueError("KdV2D expects coordinates (x,y,t)")
    d, total = _partials(model, xyt, KDV2D_TERMS, method, create_graph=create_graph)
    r = (
        d["u_ty"]
        + d["u_xxxy"]
        + 3.0 * (d["u_xy"] * d["u_x"] + d["u_y"] * d["u_xx"])
        - d["u_xx"]
        + 2.0 * d["u_yy"]
    )
    return ResidualEvaluation(r, d, total, 4)


def gkdv1d_gradient_enhanced_loss(
    model: nn.Module,
    xt: Tensor,
    *,
    method: Method,
    lam1: float = 1e-3,
    dispersion: float = 0.0025,
    create_graph: bool = True,
) -> ResidualEvaluation:
    """Upstream ``highord1d`` case=4, eq=2 complete gPINN objective.

    The returned ``value`` is the scalar
    ``mean(f^2) + lam1*(mean(f_x^2)+mean(f_t^2))``.  Components include the
    three per-point residuals ``f``, ``f_x`` and ``f_t``.
    """
    if xt.shape[-1] != 2:
        raise ValueError("gKdV1D expects coordinates (x,t)")
    d, total = _partials(model, xt, GKDV1D_TERMS, method, create_graph=create_graph)
    u = model(xt)
    f = d["u_t"] + u * d["u_x"] + dispersion * d["u_xxx"]
    fx = d["u_tx"] + d["u_x"] ** 2 + u * d["u_xx"] + dispersion * d["u_xxxx"]
    ft = d["u_tt"] + d["u_t"] * d["u_x"] + u * d["u_tx"] + dispersion * d["u_txxx"]
    loss = f.square().mean() + lam1 * (fx.square().mean() + ft.square().mean())
    return ResidualEvaluation(loss, {**d, "f": f, "f_x": fx, "f_t": ft}, total, 4)


def polyharmonic_2d_operator(
    model: nn.Module,
    xy: Tensor,
    *,
    order: int,
    method: Method,
    create_graph: bool = True,
) -> ResidualEvaluation:
    """Evaluate ``Delta^(order/2) u`` for order 4 or 6 in 2D.

    ``nested_ad`` uses the coordinate expansion as a reference.  In contrast,
    ``rank_optimal`` evaluates one operator-level homogeneous form with rank 3
    (order 4) or rank 4 (order 6), in a single batched Taylor-jet pass.
    """
    if xy.shape[-1] != 2:
        raise ValueError("polyharmonic_2d expects coordinates (x,y)")
    if order not in POLYHARMONIC_2D_EXPANDED_TERMS:
        raise ValueError("order must be 4 or 6")
    formula = polyharmonic_2d_direction_formula(order)

    if method == "nested_ad":
        components: dict[str, Tensor] = {}
        value: Tensor | None = None
        for coefficient, alpha in POLYHARMONIC_2D_EXPANDED_TERMS[order]:
            partial, _meta = monomial_partial(
                model, xy, alpha, method=method, create_graph=create_graph
            )
            key = "d_" + "".join(str(i + 1) for i in alpha)
            components[key] = partial
            term = coefficient * partial
            value = term if value is None else value + term
        assert value is not None
        return ResidualEvaluation(value, components, None, order, formula)

    if method == "rank_optimal":
        directions = torch.as_tensor(
            formula.directions, dtype=xy.dtype, device=xy.device
        )
        weights = torch.as_tensor(
            formula.taylor_weights, dtype=xy.dtype, device=xy.device
        )
        batch, dimension = xy.shape
        batched_directions = directions.unsqueeze(0).expand(
            batch, formula.rank, dimension
        ).contiguous()
        graph_context = nullcontext() if create_graph else torch.no_grad()
        with graph_context:
            coefficients = tp_directional_via_jet(
                model, xy, batched_directions, order
            )
        value = (coefficients * weights.view(1, -1, 1)).sum(dim=1)
        components = {
            f"T{order}_v{index}": coefficients[:, index, :]
            for index in range(formula.rank)
        }
        return ResidualEvaluation(value, components, formula.rank, order, formula)

    raise ValueError(
        f"method must be 'nested_ad' or 'rank_optimal'; got {method!r}"
    )


def polyharmonic_manufactured_solution(xy: Tensor) -> Tensor:
    return torch.sin(torch.pi * xy[:, 0:1]) * torch.sin(torch.pi * xy[:, 1:2])


def polyharmonic_manufactured_source(xy: Tensor, order: int) -> Tensor:
    m = order // 2
    return (-2.0 * torch.pi**2) ** m * polyharmonic_manufactured_solution(xy)


__all__ = [
    "KDV2D_TERMS",
    "GKDV1D_TERMS",
    "POLYHARMONIC_2D",
    "POLYHARMONIC_2D_EXPANDED_TERMS",
    "POLYHARMONIC_2D_RANKS",
    "ResidualEvaluation",
    "kdv2d_residual",
    "gkdv1d_gradient_enhanced_loss",
    "polyharmonic_2d_operator",
    "polyharmonic_manufactured_solution",
    "polyharmonic_manufactured_source",
]
