"""Small helpers shared by the JAX and Torch benchmark entry points."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from apolarity.benchmarks import (
    BenchmarkTarget,
    MIXED_TARGETS,
    expanded_multi_index,
    laplacian_power_terms,
    monomial_rank,
)


ROOT = Path(__file__).resolve().parents[2]
CONFIG_PATH = ROOT / "experiments" / "benchmarks" / "configs" / "main.json"


def load_config(path: str | Path = CONFIG_PATH) -> dict[str, Any]:
    config = json.loads(Path(path).read_text(encoding="utf-8"))
    if tuple(config.get("methods", ())) != ("nested_ad", "rank_optimal"):
        raise ValueError("the benchmark protocol must contain exactly nested_ad and rank_optimal")
    if config.get("dtype") != "float32":
        raise ValueError("the primary protocol is fixed to float32")
    return config


def target_by_name(name: str) -> BenchmarkTarget:
    for target in MIXED_TARGETS:
        if target.name == name:
            return target
    raise KeyError(f"unknown fixed mixed target {name!r}")


def family_dimension(family: str) -> int:
    if family == "fixed_mixed":
        return 0  # selected target determines the dimension
    if family == "kdv2d":
        return 3
    if family == "gkdv1d":
        return 2
    if family == "polyharmonic2d":
        return 2
    raise ValueError(f"unknown family {family!r}")


def family_terms(
    family: str,
    *,
    target: str | None = None,
    order: int | None = None,
) -> list[tuple[str, tuple[int, ...], float]]:
    """Return derivative terms needed by one residual, with coefficients.

    The nonlinear products are assembled in :mod:`apolarity.benchmarks.pde`;
    this table is used only for schedule metadata and deterministic diagnostics.
    """
    if family == "fixed_mixed":
        if target is None:
            raise ValueError("fixed_mixed requires target")
        t = target_by_name(target)
        return [(t.name, t.alpha, 1.0)]
    if family == "kdv2d":
        return [
            ("u_x", (0,), 1.0),
            ("u_y", (1,), 1.0),
            ("u_xx", (0, 0), 1.0),
            ("u_xy", (0, 1), 1.0),
            ("u_yy", (1, 1), 1.0),
            ("u_ty", (2, 1), 1.0),
            ("u_xxxy", (0, 0, 0, 1), 1.0),
        ]
    if family == "gkdv1d":
        return [
            ("u_x", (0,), 1.0),
            ("u_t", (1,), 1.0),
            ("u_xx", (0, 0), 1.0),
            ("u_tx", (1, 0), 1.0),
            ("u_tt", (1, 1), 1.0),
            ("u_xxx", (0, 0, 0), 1.0),
            ("u_xxxx", (0, 0, 0, 0), 1.0),
            ("u_txxx", (1, 0, 0, 0), 1.0),
        ]
    if family == "polyharmonic2d":
        if order is None:
            raise ValueError("polyharmonic2d requires order")
        return [
            (f"partial_{''.join(str(i) for i in alpha)}", alpha, coefficient)
            for coefficient, alpha in laplacian_power_terms(2, order // 2)
        ]
    raise ValueError(f"unknown family {family!r}")


def family_direction_count(
    family: str,
    *,
    target: str | None = None,
    order: int | None = None,
) -> int:
    """Count termwise rank-optimal directional evaluations."""
    return sum(monomial_rank(alpha) for _, alpha, _ in family_terms(family, target=target, order=order))


def real_scalar(value: Any) -> Any:
    """Return the real component without importing a backend-specific array API."""
    return getattr(value, "real", value)


def json_default(value: Any):
    if hasattr(value, "item"):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"cannot serialize {type(value).__name__}")


__all__ = [
    "CONFIG_PATH",
    "ROOT",
    "family_dimension",
    "family_direction_count",
    "family_terms",
    "json_default",
    "load_config",
    "real_scalar",
    "target_by_name",
]
