#!/usr/bin/env python3
"""Run the standalone JAX version of the two-method benchmark."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time
from typing import Any

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
BENCH = ROOT / "experiments" / "benchmarks"
SRC = ROOT / "src"
for path in (SRC, BENCH):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import jax
import jax.numpy as jnp

from apolarity.benchmarks import (
    BENCHMARK_METHODS,
    gkdv_loss,
    gkdv_residual,
    kdv2d_residual,
    polyharmonic_residual,
)
from apolarity.benchmarks.common import (
    seeded_fixture,
)
from apolarity.benchmarks.jax_backend import derivative, model_batch, to_jax
from bench_utils import family_direction_count, family_terms, json_default, load_config, target_by_name


def _sync(value: Any) -> None:
    for leaf in jax.tree_util.tree_leaves(value):
        if hasattr(leaf, "block_until_ready"):
            leaf.block_until_ready()


def _real(value):
    return jnp.real(value)


def _loss_from_output(value):
    real = _real(value)
    return jnp.mean(real * real)


def _git_commit() -> str | None:
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=ROOT,
            check=False,
            capture_output=True,
            text=True,
        ).stdout.strip() or None
    except OSError:
        return None


def _case_output(
    params,
    points,
    family: str,
    *,
    method: str,
    target: str | None = None,
    order: int | None = None,
    gradient_weight: float = 1.0e-3,
    return_loss: bool = False,
):
    cache: dict[tuple[int, ...], Any] = {}

    def partial(alpha: tuple[int, ...]):
        alpha = tuple(alpha)
        if alpha not in cache:
            cache[alpha] = derivative(params, points, alpha, method=method)
        return cache[alpha]

    def value():
        return model_batch(params, points)

    if family == "fixed_mixed":
        if target is None:
            raise ValueError("fixed_mixed requires target")
        output = partial(target_by_name(target).alpha)
    elif family == "kdv2d":
        output = kdv2d_residual(partial, value)
    elif family == "gkdv1d":
        if return_loss:
            output = gkdv_loss(partial, value, gradient_weight=gradient_weight)
        else:
            f, f_x, f_t = gkdv_residual(partial, value)
            output = jnp.concatenate([_real(f).reshape(-1), _real(f_x).reshape(-1), _real(f_t).reshape(-1)])
    elif family == "polyharmonic2d":
        if order is None:
            raise ValueError("polyharmonic2d requires order")
        output = polyharmonic_residual(partial, dimension=2, order=order)
    else:
        raise ValueError(f"unknown family {family!r}")
    return output


def _case_fn(
    params,
    points,
    family: str,
    *,
    method: str,
    target: str | None,
    order: int | None,
    gradient_weight: float,
    mode: str,
):
    output = _case_output(
        params,
        points,
        family,
        method=method,
        target=target,
        order=order,
        gradient_weight=gradient_weight,
        return_loss=(family == "gkdv1d"),
    )
    if family == "gkdv1d":
        # The eq=2 gPINN scalar already includes the residual and gradient
        # terms; it is the objective in both value and backward modes.
        return output
    return output if mode == "value" else _loss_from_output(output)


def cases_for(config: dict[str, Any], family: str):
    if family == "fixed_mixed":
        return [(name, None) for name in config["families"][family]["targets"]]
    if family == "polyharmonic2d":
        return [(None, int(order)) for order in config["families"][family]["orders"]]
    return [(None, None)]


def _run_timed(
    config: dict[str, Any],
    family: str,
    method: str,
    mode: str,
    *,
    target: str | None = None,
    order: int | None = None,
) -> dict[str, Any]:
    family_config = config["families"][family]
    batch = int(family_config.get("batch_size", config["batch_size"]))
    if family == "fixed_mixed":
        dimension = target_by_name(target or "").dimension
    elif family == "kdv2d":
        dimension = 3
    else:
        dimension = 2
    params_np, points_np = seeded_fixture(
        int(config["seed"]),
        dimension,
        int(config["network"]["width"]),
        int(config["network"]["depth"]),
        batch,
        dtype=np.float32,
    )
    params, points = to_jax(params_np, points_np, dtype=jnp.float32)
    gradient_weight = float(config["families"].get("gkdv1d", {}).get("gradient_weight", 1.0e-3))
    fn = lambda prm: _case_fn(
        prm,
        points,
        family,
        method=method,
        target=target,
        order=order,
        gradient_weight=gradient_weight,
        mode=mode,
    )
    if mode == "backward":
        compiled = jax.jit(jax.grad(fn))
    else:
        compiled = jax.jit(fn)
    started = time.perf_counter()
    first = compiled(params)
    _sync(first)
    first_ms = (time.perf_counter() - started) * 1000.0
    for _ in range(int(config["warmups"])):
        _sync(compiled(params))
    samples: list[float] = []
    last = None
    for _ in range(int(config["repeats"])):
        started = time.perf_counter()
        last = compiled(params)
        _sync(last)
        samples.append((time.perf_counter() - started) * 1000.0)
    output_fn = jax.jit(
        lambda prm: _case_output(
            prm,
            points,
            family,
            method=method,
            target=target,
            order=order,
            gradient_weight=gradient_weight,
            return_loss=(family == "gkdv1d"),
        )
    )
    output = output_fn(params)
    _sync(output)
    snapshot = np.asarray(output)
    memory = jax.devices()[0].memory_stats() or {}
    terms = family_terms(family, target=target, order=order)
    return {
        "status": "ok",
        "protocol_id": config["protocol_id"],
        "family": family,
        "target": target,
        "order": len(target_by_name(target).alpha) if target else order,
        "method": method,
        "mode": mode,
        "dtype": config["dtype"],
        "network_depth": config["network"]["depth"],
        "network_width": config["network"]["width"],
        "batch_size": batch,
        "direction_count": family_direction_count(family, target=target, order=order),
        "term_count": len(terms),
        "compile_plus_first_call_ms": first_ms,
        "steady_median_ms": statistics.median(samples),
        "steady_samples_ms": samples,
        "output_l2": float(np.linalg.norm(snapshot.ravel())),
        "output_max_abs": float(np.max(np.abs(snapshot))),
        "peak_bytes_in_use": memory.get("peak_bytes_in_use"),
        "device": str(jax.devices()[0]),
        "jax_version": jax.__version__,
        "jaxlib_version": getattr(jax.lib, "__version__", None),
        "source_commit": _git_commit(),
        "direction_chunking": False,
        "complex_dtype": config["runtime"]["complex_dtype"],
        "gradient_weight": gradient_weight if family == "gkdv1d" else None,
        "case": config["families"].get(family, {}).get("case"),
        "equation": config["families"].get(family, {}).get("equation"),
        "_snapshot": snapshot.tolist(),
    }


def _run_safe(*args, **kwargs):
    try:
        return _run_timed(*args, **kwargs)
    except Exception as exc:
        return {
            "status": "error",
            "family": args[1] if len(args) > 1 else kwargs.get("family"),
            "method": args[2] if len(args) > 2 else kwargs.get("method"),
            "mode": args[3] if len(args) > 3 else kwargs.get("mode"),
            "error": repr(exc),
        }


def _relative_l2(actual: Any, reference: Any) -> float:
    a = np.asarray(actual)
    r = np.asarray(reference)
    return float(np.linalg.norm(a.ravel() - r.ravel()) / max(np.linalg.norm(r.ravel()), 1e-30))


def run(config: dict[str, Any], families: list[str], modes: list[str]):
    rows: list[dict[str, Any]] = []
    for family in families:
        for target, order in cases_for(config, family):
            for mode in modes:
                reference = None
                for method in BENCHMARK_METHODS:
                    row = _run_safe(
                        config,
                        family,
                        method,
                        mode,
                        target=target,
                        order=order,
                    )
                    snapshot = row.pop("_snapshot", None)
                    if method == "nested_ad" and row.get("status") == "ok" and mode == "value":
                        reference = snapshot
                    if method == "rank_optimal" and row.get("status") == "ok" and mode == "value" and reference is not None:
                        row["relative_l2_to_nested"] = _relative_l2(snapshot, reference)
                        row["max_abs_to_nested"] = float(
                            np.max(np.abs(np.asarray(snapshot) - np.asarray(reference)))
                        )
                    rows.append(row)
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "experiments/benchmarks/configs/main.json")
    parser.add_argument(
        "--family",
        choices=["all", "fixed_mixed", "kdv2d", "gkdv1d", "polyharmonic2d"],
        default="all",
    )
    parser.add_argument("--mode", choices=["value", "backward", "both"], default="both")
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    config = load_config(args.config)
    families = (
        ["fixed_mixed", "kdv2d", "gkdv1d", "polyharmonic2d"]
        if args.family == "all"
        else [args.family]
    )
    modes = ["value", "backward"] if args.mode == "both" else [args.mode]
    rows = run(config, families, modes)
    payload = {
        "protocol_id": config["protocol_id"],
        "runner": "jax",
        "host": platform.node(),
        "python": sys.version,
        "environment": {
            "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
            "backend": jax.default_backend(),
        },
        "rows": rows,
    }
    text = json.dumps(payload, indent=2, default=json_default)
    if args.output is None:
        print(text)
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
        print(f"wrote {args.output}")
    return 0 if all(row.get("status") == "ok" for row in rows) else 2


if __name__ == "__main__":
    raise SystemExit(main())
