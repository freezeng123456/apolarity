# Changelog

## Unreleased — two-method benchmark protocol

- Added backend-independent metadata for the fixed mixed-partial stress tests.
- Added shared KdV, g-KdV, and polyharmonic residual assembly so the nested
  and rank-optimal paths evaluate identical operators.
- Added standalone JAX and integrated Torch benchmark runners with frozen JSON
  configurations, value/backward timing, memory fields, and failure status.
- Added a CPU smoke driver, aggregation/plotting utilities, provenance writer,
  and metadata/PDE unit tests.
- Added an isolated copy of the public STDE source under
  `reference/stde_upstream`; it is not a benchmark method or runtime dependency.
