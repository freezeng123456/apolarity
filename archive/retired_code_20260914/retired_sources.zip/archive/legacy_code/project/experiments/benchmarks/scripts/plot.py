#!/usr/bin/env python3
"""Plot steady timings from an aggregated benchmark CSV.

The plotting dependency is optional and intentionally kept out of the core
library.  The script makes no claims about statistical significance; it only
visualizes rows produced by the frozen runner.
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise SystemExit("plotting requires matplotlib") from exc
    with args.csv_path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    rows = [row for row in rows if row.get("status") == "ok"]
    if not rows:
        raise SystemExit("CSV contains no successful rows")
    labels = []
    values = []
    colors = []
    for row in rows:
        label = "/".join(
            value for value in (row.get("family"), row.get("target") or row.get("order"), row.get("mode"))
            if value not in (None, "")
        )
        labels.append(label)
        values.append(float(row["steady_median_ms"]))
        colors.append("#2f6fbb" if row.get("method") == "nested_ad" else "#d95f02")
    fig, ax = plt.subplots(figsize=(max(8, 0.32 * len(labels)), 4.5))
    ax.bar(range(len(labels)), values, color=colors)
    ax.set_ylabel("steady median (ms)")
    ax.set_xticks(range(len(labels)), labels, rotation=75, ha="right")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=180)
    print(f"wrote {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
