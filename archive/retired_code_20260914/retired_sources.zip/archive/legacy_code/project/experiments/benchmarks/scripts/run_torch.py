#!/usr/bin/env python3
"""Run the two-method Torch benchmark.

The script is intentionally a small, fresh-process-friendly driver.  It
records one JSON object per method/case/mode and never imports the STDE
implementation.  Use ``--device cpu`` for a smoke test and ``--device cuda``
on an allocated T4.
"""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time
from typing import Any

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
SRC = ROOT / "src"
BENCH = ROOT / "experiments" / "benchmarks"
for path in (SRC, BENCH):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import torch

from apolarity.benchmarks import (
    BENCHMARK_METHODS,
    gkdv_loss,
    gkdv_residual,
    kdv2d_residual,
    polyharmonic_residual,
)
from apolarity.benchmarks.common import (
    seeded_fixture,
)
from apolarity.benchmarks.torch_backend import build_mlp, derivative, model_value
from bench_utils import family_direction_count, family_terms, json_default, load_config, target_by_name


def _sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def _real(value: torch.Tensor) -> torch.Tensor:
    return value.real if value.is_complex() else value


def _loss_from_output(value: torch.Tensor) -> torch.Tensor:
    real = _real(value)
    return (real * real).mean()


def _git_commit() -> str | None:
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=ROOT,
            check=False,
            capture_output=True,
            text=True,
        ).stdout.strip() or None
    except OSError:
        return None


def _case_output(
    model: torch.nn.Module,
    points: torch.Tensor,
    family: str,
    *,
    method: str,
    target: str | None = None,
    order: int | None = None,
    gradient_weight: float = 1.0e-3,
    return_loss: bool = False,
) -> torch.Tensor:
    cache: dict[tuple[int, ...], torch.Tensor] = {}

    def partial(alpha: tuple[int, ...]) -> torch.Tensor:
        alpha = tuple(alpha)
        if alpha not in cache:
            cache[alpha] = derivative(model, points, alpha, method=method)
        return cache[alpha]

    def value() -> torch.Tensor:
        return model_value(model, points)

    if family == "fixed_mixed":
        if target is None:
            raise ValueError("fixed_mixed requires target")
        output = partial(target_by_name(target).alpha)
    elif family == "kdv2d":
        output = kdv2d_residual(partial, value)
    elif family == "gkdv1d":
        if return_loss:
            output = gkdv_loss(partial, value, gradient_weight=gradient_weight)
        else:
            # The tuple is reduced to a vector only for value-time accounting;
            # all three components are still evaluated before the reduction.
            f, f_x, f_t = gkdv_residual(partial, value)
            output = torch.cat([_real(f).reshape(-1), _real(f_x).reshape(-1), _real(f_t).reshape(-1)])
    elif family == "polyharmonic2d":
        if order is None:
            raise ValueError("polyharmonic2d requires order")
        output = polyharmonic_residual(partial, dimension=2, order=order)
    else:
        raise ValueError(f"unknown family {family!r}")
    return output


def _evaluate_case(
    model: torch.nn.Module,
    points: torch.Tensor,
    family: str,
    *,
    method: str,
    target: str | None = None,
    order: int | None = None,
    gradient_weight: float = 1.0e-3,
    mode: str,
) -> tuple[torch.Tensor, torch.Tensor]:
    output = _case_output(
        model,
        points,
        family,
        method=method,
        target=target,
        order=order,
        gradient_weight=gradient_weight,
        return_loss=(family == "gkdv1d"),
    )
    if family == "gkdv1d":
        # ``gkdv_loss`` already is the complete eq=2 scalar objective.  Do
        # not square it a second time in backward mode.
        measured = output
    elif mode == "value":
        measured = output
    elif mode == "backward":
        measured = _loss_from_output(output)
    else:
        raise ValueError(f"unknown mode {mode!r}")
    return measured, output


def _fresh_model_and_points(
    config: dict[str, Any],
    family: str,
    device: torch.device,
    *,
    target: str | None = None,
    order: int | None = None,
    requires_grad: bool,
) -> tuple[torch.nn.Module, torch.Tensor, tuple[tuple[np.ndarray, np.ndarray], ...]]:
    if family == "fixed_mixed":
        input_dim = target_by_name(target or "").dimension
    elif family == "kdv2d":
        input_dim = 3
    elif family in ("gkdv1d", "polyharmonic2d"):
        input_dim = 2
    else:
        raise ValueError(f"unknown family {family!r}")
    family_cfg = config["families"][family]
    batch = int(family_cfg.get("batch_size", config["batch_size"]))
    params_np, points_np = seeded_fixture(
        int(config["seed"]),
        input_dim,
        int(config["network"]["width"]),
        int(config["network"]["depth"]),
        batch,
        dtype=np.float32,
    )
    model = build_mlp(params_np, dtype=torch.float32, device=device)
    model.train(False)
    for parameter in model.parameters():
        parameter.requires_grad_(requires_grad)
    points = torch.as_tensor(points_np, dtype=torch.float32, device=device)
    points.requires_grad_(True)
    return model, points, params_np


def _run_timed(
    config: dict[str, Any],
    family: str,
    method: str,
    mode: str,
    device: torch.device,
    *,
    target: str | None = None,
    order: int | None = None,
) -> dict[str, Any]:
    gradient_weight = float(config["families"].get("gkdv1d", {}).get("gradient_weight", 1.0e-3))
    requires_grad = mode == "backward"
    model, points, _params_np = _fresh_model_and_points(
        config,
        family,
        device,
        target=target,
        order=order,
        requires_grad=requires_grad,
    )
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)

    def invoke() -> torch.Tensor:
        model.zero_grad(set_to_none=True)
        if points.grad is not None:
            points.grad = None
        measured, _ = _evaluate_case(
            model,
            points,
            family,
            method=method,
            target=target,
            order=order,
            gradient_weight=gradient_weight,
            mode=mode,
        )
        if mode == "backward":
            measured.backward()
        return measured

    started = time.perf_counter()
    first = invoke()
    _sync(device)
    first_ms = (time.perf_counter() - started) * 1000.0
    for _ in range(int(config["warmups"])):
        invoke()
        _sync(device)
    samples: list[float] = []
    last: torch.Tensor | None = None
    for _ in range(int(config["repeats"])):
        started = time.perf_counter()
        last = invoke()
        _sync(device)
        samples.append((time.perf_counter() - started) * 1000.0)
    if last is None:
        last = first
    snapshot = last.detach().cpu().numpy()
    peak_mib = None
    if device.type == "cuda":
        peak_mib = float(torch.cuda.max_memory_allocated(device) / (1024.0**2))
    terms = family_terms(family, target=target, order=order)
    return {
        "status": "ok",
        "protocol_id": config["protocol_id"],
        "family": family,
        "target": target,
        "order": len(target_by_name(target).alpha) if target else order,
        "method": method,
        "mode": mode,
        "dtype": config["dtype"],
        "network_depth": config["network"]["depth"],
        "network_width": config["network"]["width"],
        "batch_size": int(points.shape[0]),
        "direction_count": family_direction_count(family, target=target, order=order),
        "term_count": len(terms),
        "compile_plus_first_call_ms": first_ms,
        "steady_median_ms": statistics.median(samples),
        "steady_samples_ms": samples,
        "output_l2": float(np.linalg.norm(snapshot.ravel())),
        "output_max_abs": float(np.max(np.abs(snapshot))),
        "peak_memory_mib": peak_mib,
        "device": str(device),
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "gpu_name": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
        "source_commit": _git_commit(),
        "direction_chunking": False,
        "complex_dtype": config["runtime"]["complex_dtype"],
        "gradient_weight": gradient_weight if family == "gkdv1d" else None,
        "case": config["families"].get(family, {}).get("case"),
        "equation": config["families"].get(family, {}).get("equation"),
        "_snapshot": snapshot.tolist(),
    }


def _run_safe(*args, **kwargs) -> dict[str, Any]:
    try:
        return _run_timed(*args, **kwargs)
    except RuntimeError as exc:
        text = str(exc)
        status = "oom" if "out of memory" in text.lower() else "error"
        return {
            "status": status,
            "family": args[1] if len(args) > 1 else kwargs.get("family"),
            "method": args[2] if len(args) > 2 else kwargs.get("method"),
            "mode": args[3] if len(args) > 3 else kwargs.get("mode"),
            "error": repr(exc),
        }
    except Exception as exc:  # benchmark manifests must preserve failures
        return {
            "status": "error",
            "family": args[1] if len(args) > 1 else kwargs.get("family"),
            "method": args[2] if len(args) > 2 else kwargs.get("method"),
            "mode": args[3] if len(args) > 3 else kwargs.get("mode"),
            "error": repr(exc),
        }


def _relative_l2(actual: Any, reference: Any) -> float:
    a = np.asarray(actual)
    r = np.asarray(reference)
    return float(np.linalg.norm(a.ravel() - r.ravel()) / max(np.linalg.norm(r.ravel()), 1e-30))


def cases_for(config: dict[str, Any], family: str):
    if family == "fixed_mixed":
        names = config["families"][family].get("targets")
        return [(name, None) for name in names]
    if family == "polyharmonic2d":
        return [(None, int(order)) for order in config["families"][family]["orders"]]
    return [(None, None)]


def run(config: dict[str, Any], families: list[str], modes: list[str], device: torch.device):
    rows: list[dict[str, Any]] = []
    for family in families:
        for target, order in cases_for(config, family):
            for mode in modes:
                reference = None
                for method in BENCHMARK_METHODS:
                    row = _run_safe(
                        config,
                        family,
                        method,
                        mode,
                        device,
                        target=target,
                        order=order,
                    )
                    snapshot = row.pop("_snapshot", None)
                    if method == "nested_ad" and row.get("status") == "ok" and mode == "value":
                        reference = snapshot
                    if method == "rank_optimal" and row.get("status") == "ok" and mode == "value" and reference is not None:
                        row["relative_l2_to_nested"] = _relative_l2(snapshot, reference)
                        row["max_abs_to_nested"] = float(
                            np.max(np.abs(np.asarray(snapshot) - np.asarray(reference)))
                        )
                    rows.append(row)
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "experiments/benchmarks/configs/main.json")
    parser.add_argument(
        "--family",
        choices=["all", "fixed_mixed", "kdv2d", "gkdv1d", "polyharmonic2d"],
        default="all",
    )
    parser.add_argument("--mode", choices=["value", "backward", "both"], default="both")
    parser.add_argument("--device", default=None, help="cpu or cuda; defaults to config/device availability")
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    config = load_config(args.config)
    if args.device is None:
        args.device = "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA was requested but is not available")
    families = (
        ["fixed_mixed", "kdv2d", "gkdv1d", "polyharmonic2d"]
        if args.family == "all"
        else [args.family]
    )
    modes = ["value", "backward"] if args.mode == "both" else [args.mode]
    rows = run(config, families, modes, device)
    payload = {
        "protocol_id": config["protocol_id"],
        "runner": "torch",
        "host": platform.node(),
        "python": sys.version,
        "environment": {
            "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
            "device": str(device),
        },
        "rows": rows,
    }
    text = json.dumps(payload, indent=2, default=json_default)
    if args.output is None:
        print(text)
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
        print(f"wrote {args.output}")
    return 0 if all(row.get("status") == "ok" for row in rows) else 2


if __name__ == "__main__":
    raise SystemExit(main())
