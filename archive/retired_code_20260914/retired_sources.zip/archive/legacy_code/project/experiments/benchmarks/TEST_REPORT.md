# Test report

This report is a template for the current source tree.  Performance numbers
must be generated from a fresh run of the frozen configuration and are not
filled in by the source-only validation.

## Static checks

- `python -m compileall src/apolarity/benchmarks experiments/benchmarks/scripts`
  should be run with the project interpreter.
- `pytest tests/test_benchmark_metadata.py tests/test_benchmark_pde.py` covers
  parser/rank metadata, Laplacian expansions, and the three residual assembly
  functions without requiring Torch or JAX.

## Backend smoke

Run:

```bash
python experiments/benchmarks/scripts/run_cpu_smoke.py \
  --output-dir output/benchmark_smoke --require-backends
```

The script writes `manifest.json`, one payload per available backend, and
stdout/stderr logs.  Missing optional dependencies are recorded as `skipped`
unless `--require-backends` is supplied.  A successful backend payload must
contain all requested families and both methods with `status == "ok"`.

## Known source-snapshot limitation

The local macOS development interpreter used during source review does not
ship Torch or JAX.  Therefore backend execution is intentionally not claimed
until the smoke command is run in the configured environment (for example,
the T4 interpreter recorded by `write_provenance.py`).  Any timeout, OOM, or
missing package must remain in the generated manifest rather than being
silently omitted.
