#!/usr/bin/env python3
"""Run the small CPU smoke for both optional numerical backends.

The script reports an unavailable optional dependency as ``skipped`` by
default, which keeps the Torch-only package install usable.  CI or a release
check can pass ``--require-backends`` to make either missing backend fatal.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[3]
SCRIPT_DIR = ROOT / "experiments" / "benchmarks" / "scripts"
SMOKE_CONFIG = ROOT / "experiments" / "benchmarks" / "configs" / "smoke.json"


def _available(module: str) -> bool:
    try:
        __import__(module)
    except Exception:
        return False
    return True


def _run(name: str, command: list[str], output: Path) -> dict:
    completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    output.write_text(completed.stdout + completed.stderr, encoding="utf-8")
    return {
        "backend": name,
        "status": "ok" if completed.returncode == 0 else "error",
        "returncode": completed.returncode,
        "output": str(output),
        "tail": (completed.stdout + completed.stderr)[-4000:],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=ROOT / "output/benchmark_smoke")
    parser.add_argument("--require-backends", action="store_true")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    records: list[dict] = []
    if _available("torch"):
        records.append(
            _run(
                "torch",
                [
                    sys.executable,
                    str(SCRIPT_DIR / "run_torch.py"),
                    "--config",
                    str(SMOKE_CONFIG),
                    "--device",
                    "cpu",
                    "--mode",
                    "value",
                    "--output",
                    str(args.output_dir / "torch.json"),
                ],
                args.output_dir / "torch.stdout.log",
            )
        )
    else:
        records.append({"backend": "torch", "status": "skipped", "reason": "torch is not installed"})

    if _available("jax"):
        records.append(
            _run(
                "jax",
                [
                    sys.executable,
                    str(SCRIPT_DIR / "run_jax.py"),
                    "--config",
                    str(SMOKE_CONFIG),
                    "--mode",
                    "value",
                    "--output",
                    str(args.output_dir / "jax.json"),
                ],
                args.output_dir / "jax.stdout.log",
            )
        )
    else:
        records.append({"backend": "jax", "status": "skipped", "reason": "jax is not installed"})

    manifest = {"config": str(SMOKE_CONFIG), "records": records}
    (args.output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2))
    if args.require_backends and any(record["status"] != "ok" for record in records):
        return 2
    return 0 if all(record["status"] in ("ok", "skipped") for record in records) else 2


if __name__ == "__main__":
    raise SystemExit(main())
