# Two-method derivative benchmark

This directory contains the reproducible numerical comparison requested for
the paper.  The primary comparison has exactly two methods:

* `nested_ad`: direct nested coordinate automatic differentiation;
* `rank_optimal`: the Waring-rank directional Taylor-jet representation from
  `src/apolarity`.

The STDE repository is retained only as a provenance/reference copy under
`reference/stde_upstream`; it is not imported by either runner and is not a
third row in the primary comparison.

## Frozen protocol

`configs/main.json` fixes the shared float32 MLP fixture, total affine depth
four (three hidden tanh layers and one scalar output), width 128, batch size
100, three warm-up calls, and five timed repetitions.  The four families are:

1. fixed mixed partials `u_112233`, `u_111222333`, `u_123456`, and
   `u_11223344`;
2. the two-dimensional nonlinear KdV residual from the STDE equation file
   (coordinates `(x,y,t)`, provenance case 4);
3. the g-KdV gradient-enhanced loss (case 4, equation 2, gradient weight
   `1e-3`);
4. two-dimensional polyharmonic operators of differential order four and six.

All residuals are assembled by `src/apolarity/benchmarks/pde.py`.  The same
termwise derivative list is passed to both methods, so the timing comparison
does not compare different mathematical operators.  No direction chunking is
enabled in the primary protocol.  Real `+/-1` Waring directions are kept in
real arithmetic; non-real roots use complex64 internally.

## Commands

Install the project and the optional backend you want to run:

```bash
python -m pip install -e .
python -m pip install -e '.[jax]'       # optional standalone JAX runner
```

Run a small CPU smoke (it reports an unavailable optional backend as skipped):

```bash
python experiments/benchmarks/scripts/run_cpu_smoke.py \
  --output-dir output/benchmark_smoke
```

Run the complete Torch protocol on an allocated GPU:

```bash
python experiments/benchmarks/scripts/run_torch.py \
  --config experiments/benchmarks/configs/main.json \
  --device cuda --mode both --output output/benchmark_torch.json
```

Run the standalone JAX protocol (the JAX build must match the CUDA runtime):

```bash
python experiments/benchmarks/scripts/run_jax.py \
  --config experiments/benchmarks/configs/main.json \
  --mode both --output output/benchmark_jax.json
```

The complete run can be shortened to one family with `--family fixed_mixed`,
`kdv2d`, `gkdv1d`, or `polyharmonic2d`.  Use `configs/smoke.json` for CPU
development; its output is diagnostic and must not be reported as a
performance result.

Aggregate backend payloads and make a timing plot:

```bash
python experiments/benchmarks/scripts/aggregate.py \
  output/benchmark_torch.json output/benchmark_jax.json \
  --output output/benchmark.csv
python experiments/benchmarks/scripts/plot.py output/benchmark.csv \
  --output output/benchmark_timing.png
```

Write a frozen environment record alongside a run:

```bash
python experiments/benchmarks/scripts/write_provenance.py \
  --config experiments/benchmarks/configs/main.json \
  --output output/benchmark_provenance.json
```

The JSON payload preserves status `error`, `oom`, or `skipped` rows instead of
silently dropping them.  A performance table should therefore filter on
`status == "ok"` and retain the accompanying manifest/provenance files.
