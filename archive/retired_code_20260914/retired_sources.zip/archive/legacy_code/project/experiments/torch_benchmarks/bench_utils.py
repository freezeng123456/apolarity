from __future__ import annotations

import csv
import hashlib
import json
import os
import platform
import resource
import statistics
import time
from pathlib import Path
from typing import Any, Callable

import torch
import yaml


def load_config(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def resolve_dtype(name: str) -> torch.dtype:
    if name == "float32":
        return torch.float32
    if name == "float64":
        return torch.float64
    raise ValueError(f"unsupported real dtype: {name}")


def resolve_device(name: str) -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but torch.cuda.is_available() is false")
    return device


def synchronize(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def process_max_rss_bytes() -> int:
    # Linux reports KiB; macOS reports bytes.  The evaluation container and
    # documented GPU commands target Linux.
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return int(value * 1024) if platform.system() != "Darwin" else int(value)


def measure(
    fn: Callable[[], Any], *, device: torch.device, warmups: int, repeats: int
) -> dict[str, Any]:
    for _ in range(warmups):
        out = fn()
        synchronize(device)
        del out
    times_ms: list[float] = []
    peak_bytes: int | None = None
    if device.type == "cuda":
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(device)
    for _ in range(repeats):
        synchronize(device)
        start = time.perf_counter()
        out = fn()
        synchronize(device)
        times_ms.append((time.perf_counter() - start) * 1000.0)
        del out
    if device.type == "cuda":
        peak_bytes = int(torch.cuda.max_memory_allocated(device))
        memory_method = "torch.cuda.max_memory_allocated"
    else:
        peak_bytes = process_max_rss_bytes()
        memory_method = (
            "process ru_maxrss high-water mark (absolute, not per-call delta)"
        )
    return {
        "times_ms": times_ms,
        "median_ms": statistics.median(times_ms),
        "mean_ms": statistics.mean(times_ms),
        "min_ms": min(times_ms),
        "max_ms": max(times_ms),
        "peak_memory_bytes": peak_bytes,
        "peak_memory_method": memory_method,
    }


def rel_l2(actual: torch.Tensor, expected: torch.Tensor) -> float:
    a = actual.detach()
    e = expected.detach()
    denom = torch.linalg.vector_norm(e.reshape(-1)).clamp_min(1e-30)
    return float((torch.linalg.vector_norm((a - e).reshape(-1)) / denom).cpu())


def max_abs(actual: torch.Tensor, expected: torch.Tensor) -> float:
    return float((actual.detach() - expected.detach()).abs().max().cpu())


def flatten_grads(model: torch.nn.Module) -> torch.Tensor:
    chunks = []
    for p in model.parameters():
        if p.grad is not None:
            chunks.append(p.grad.detach().reshape(-1))
    if not chunks:
        return torch.empty(0)
    return torch.cat(chunks)


def source_tree_sha256(root: Path) -> str:
    h = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        if rel.startswith(("results/", ".pytest_cache/")) or "__pycache__" in rel:
            continue
        h.update(rel.encode())
        h.update(path.read_bytes())
    return h.hexdigest()


def provenance(
    project_root: Path, config_path: Path, device: torch.device
) -> dict[str, Any]:
    return {
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "torch_cuda_version": torch.version.cuda,
        "cuda_available": torch.cuda.is_available(),
        "device": str(device),
        "device_name": torch.cuda.get_device_name(device)
        if device.type == "cuda"
        else platform.processor() or "CPU",
        "config_path": str(config_path),
        "source_tree_sha256": source_tree_sha256(project_root),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
    }


def write_results(rows: list[dict[str, Any]], output: str | Path) -> tuple[Path, Path]:
    out = Path(output)
    if out.suffix:
        stem = out.with_suffix("")
    else:
        stem = out
    stem.parent.mkdir(parents=True, exist_ok=True)
    json_path = stem.with_suffix(".json")
    csv_path = stem.with_suffix(".csv")
    json_path.write_text(json.dumps(rows, indent=2, default=str), encoding="utf-8")
    keys = sorted({k for row in rows for k in row.keys() if k != "times_ms"})
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for row in rows:
            flat = {k: row.get(k) for k in keys}
            for k, v in list(flat.items()):
                if isinstance(v, (dict, list, tuple)):
                    flat[k] = json.dumps(v, separators=(",", ":"), default=str)
            writer.writerow(flat)
    return json_path, csv_path
