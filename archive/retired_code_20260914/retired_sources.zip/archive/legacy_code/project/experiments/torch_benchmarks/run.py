#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import json
import math
import sys
import time
from pathlib import Path

import torch
import torch.nn as nn
import yaml

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(HERE))

from apolarity.benchmark_derivatives import (
    monomial_partial, rank_optimal_partial_raw, prepare_monomial_partial,
)
from apolarity.benchmark_models import (
    make_tanh_mlp,
    sample_normal_points,
    sample_upstream_unit_ball_space_time,
)
from apolarity.benchmark_multiindex import (
    exponent_pattern,
    parse_one_based_pattern,
    theoretical_waring_rank,
)
from apolarity.benchmark_residuals import (
    GKDV1D_TERMS,
    KDV2D_TERMS,
    POLYHARMONIC_2D,
    gkdv1d_gradient_enhanced_loss,
    kdv2d_residual,
    polyharmonic_2d_operator,
)
from bench_utils import (
    flatten_grads,
    load_config,
    max_abs,
    measure,
    provenance,
    rel_l2,
    resolve_device,
    resolve_dtype,
    synchronize,
    write_results,
)


class Sinh(nn.Module):
    def forward(self, x):
        return torch.sinh(x)


class Sin(nn.Module):
    def forward(self, x):
        return torch.sin(x)


def analytic_linear_activation(
    dim: int, *, kind: str, dtype: torch.dtype, device: torch.device
):
    activation: nn.Module = Sinh() if kind == "sinh" else Sin()
    model = nn.Sequential(nn.Linear(dim, 1, bias=True), activation).to(
        device=device, dtype=dtype
    )
    coeff = torch.linspace(
        0.35, 0.35 + 0.07 * (dim - 1), dim, dtype=dtype, device=device
    )
    with torch.no_grad():
        model[0].weight.copy_(coeff.view(1, -1))
        model[0].bias.fill_(0.13)
    return model, coeff


def analytic_sinh_partial(
    model: nn.Sequential, x: torch.Tensor, coeff: torch.Tensor, alpha: tuple[int, ...]
):
    z = x @ coeff.view(-1, 1) + model[0].bias
    factor = torch.ones((), dtype=x.dtype, device=x.device)
    for idx in alpha:
        factor = factor * coeff[idx]
    return factor * (torch.sinh(z) if len(alpha) % 2 == 0 else torch.cosh(z))


def component_error_dict(
    a: dict[str, torch.Tensor], b: dict[str, torch.Tensor], names: list[str]
) -> dict[str, float]:
    return {name: rel_l2(a[name], b[name]) for name in names}


def parameter_gradient(model: nn.Module, loss_fn):
    model.zero_grad(set_to_none=True)
    loss = loss_fn()
    if loss.is_complex():
        loss = loss.real
    loss.backward()
    return flatten_grads(model).clone(), loss.detach()


def validate_parameter_gradients_fixed(cfg, alpha, dtype, device):
    vcfg = cfg["validation"]
    # Always retain d=16 for configured derivative targets.
    d = cfg["fixed_derivatives"]["input_dim"]
    model_a = make_tanh_mlp(
        d,
        vcfg["width"],
        vcfg["depth"],
        seed=cfg["seed"] + 17,
        dtype=dtype,
        device=device,
    )
    model_b = copy.deepcopy(model_a)
    x = sample_normal_points(
        vcfg["batch_size"], d, seed=cfg["seed"] + 18, dtype=dtype, device=device
    )
    ga, _ = parameter_gradient(
        model_a,
        lambda: (
            monomial_partial(model_a, x, alpha, method="nested_ad", create_graph=True)[
                0
            ]
            .square()
            .mean()
        ),
    )
    gb, _ = parameter_gradient(
        model_b,
        lambda: (
            monomial_partial(
                model_b, x, alpha, method="rank_optimal", create_graph=True
            )[0]
            .square()
            .mean()
        ),
    )
    return rel_l2(gb, ga), max_abs(gb, ga)


def fixed_rows(cfg, method, mode, dtype, device):
    out = []
    d = cfg["fixed_derivatives"]["input_dim"]
    net = cfg["network"]
    timing_fixture = cfg["fixed_derivatives"].get("timing_fixture", "mlp")
    points = sample_normal_points(
        cfg["batch_size"],
        d,
        seed=cfg["seed"] + 1,
        dtype=dtype,
        device=device,
        std=cfg["fixed_derivatives"]["point_std"],
    )
    for target in cfg["fixed_derivatives"]["targets"]:
        alpha = parse_one_based_pattern(target)
        analytic_model, coeff = analytic_linear_activation(
            d, kind="sinh", dtype=dtype, device=device
        )
        model = (
            make_tanh_mlp(
                d,
                net["width"],
                net["depth"],
                seed=cfg["seed"] + 2,
                dtype=dtype,
                device=device,
            )
            if timing_fixture == "mlp"
            else copy.deepcopy(analytic_model)
        )
        ax = points[: min(points.shape[0], cfg["validation"]["analytic_batch_size"])]
        with torch.enable_grad():
            actual_analytic, meta = monomial_partial(
                analytic_model,
                ax,
                alpha,
                method=method,
                create_graph=False,
                return_complex=False,
            )
        expected_analytic = analytic_sinh_partial(analytic_model, ax, coeff, alpha)
        analytic_rel = rel_l2(actual_analytic, expected_analytic)
        analytic_abs = max_abs(actual_analytic, expected_analytic)
        imag_max = 0.0
        if method == "rank_optimal":
            with torch.no_grad():
                raw, raw_meta = rank_optimal_partial_raw(analytic_model, ax, alpha)
            if raw.is_complex():
                imag_max = float(raw.imag.abs().max().cpu())
            meta = raw_meta
        grad_rel, grad_abs = validate_parameter_gradients_fixed(
            cfg, alpha, dtype, device
        )

        execution = cfg.get("fixed_execution", {})
        prepared = None
        preparation_ms = None
        if execution.get("prepare", False):
            if not all(math.isfinite(e) and e < 1e-3 for e in (analytic_rel, grad_rel)):
                raise RuntimeError(f"basic consistency check failed for {target}")
            synchronize(device)
            start = time.perf_counter()
            prepared = prepare_monomial_partial(
                model, points, alpha, method=method,
                direction_execution=execution.get("directions", "batched"),
                compile_jets=execution.get("compile_jets", False) and method == "rank_optimal",
            )
            synchronize(device)
            preparation_ms = (time.perf_counter() - start) * 1000

        def value_call():
            if prepared is not None:
                return prepared(False)
            if method == "rank_optimal":
                with torch.no_grad():
                    return monomial_partial(
                        model, points, alpha, method=method, create_graph=False
                    )[0]
            return monomial_partial(
                model, points, alpha, method=method, create_graph=False
            )[0]

        def grad_call():
            model.zero_grad(set_to_none=True)
            if prepared is not None:
                value = prepared(True)
                # Do not accumulate gradients into the reusable input tensor.
                torch.autograd.backward(value.square().mean(), inputs=tuple(model.parameters()))
            else:
                value = monomial_partial(
                    model, points, alpha, method=method, create_graph=True
                )[0]
                value.square().mean().backward()
            return value

        call = value_call if mode == "value" else grad_call
        first_call_ms = None
        if prepared is not None:
            synchronize(device)
            start = time.perf_counter()
            first_output = call()
            synchronize(device)
            first_call_ms = (time.perf_counter() - start) * 1000
            if not torch.isfinite(first_output).all():
                raise RuntimeError(f"nonfinite output for {target}")
            del first_output
        timing = measure(
            call, device=device, warmups=cfg["warmups"], repeats=cfg["repeats"]
        )
        out.append(
            {
                "status": "ok",
                "backend": "torch",
                "benchmark": "fixed_mixed_partial",
                "case": f"u_{target}",
                "method": method,
                "prepared": prepared is not None,
                "direction_execution": execution.get("directions", "batched") if method == "rank_optimal" else None,
                "compile_jets": bool(execution.get("compile_jets", False) and method == "rank_optimal"),
                "preparation_ms": preparation_ms,
                "first_call_ms": first_call_ms,
                "mode": mode,
                "dtype_real": cfg["dtype"],
                "dtype_direction": meta.direction_dtype,
                "requires_complex": meta.requires_complex,
                "batch_size": cfg["batch_size"],
                "network_depth_linear_layers": net["depth"],
                "network_hidden_layers": net["depth"] - 1,
                "network_width": net["width"],
                "timing_fixture": timing_fixture,
                "multi_index_zero_based": list(alpha),
                "order": len(alpha),
                "exponent_pattern": list(exponent_pattern(alpha)),
                "theoretical_direction_count": theoretical_waring_rank(alpha),
                "evaluated_direction_count": meta.direction_count,
                "analytic_rel_l2_error": analytic_rel,
                "analytic_max_abs_error": analytic_abs,
                "imaginary_leak_max_abs": imag_max,
                "parameter_gradient_rel_l2_vs_nested": grad_rel,
                "parameter_gradient_max_abs_vs_nested": grad_abs,
                **timing,
            }
        )
    return out


def validate_pde_parameter_grad(cfg, benchmark, dtype, device):
    v = cfg["validation"]
    dim = (
        3
        if benchmark == "kdv2d"
        else (
            2 if benchmark.startswith("gkdv") or benchmark.startswith("poly") else None
        )
    )
    assert dim is not None
    a = make_tanh_mlp(
        dim, v["width"], v["depth"], seed=cfg["seed"] + 31, dtype=dtype, device=device
    )
    b = copy.deepcopy(a)
    if benchmark == "kdv2d":
        x = sample_upstream_unit_ball_space_time(
            v["batch_size"], 2, seed=cfg["seed"] + 32, dtype=dtype, device=device
        )
        la = lambda: kdv2d_residual(a, x, method="nested_ad").value.square().mean()
        lb = lambda: kdv2d_residual(b, x, method="rank_optimal").value.square().mean()
    elif benchmark == "gkdv1d":
        x = sample_upstream_unit_ball_space_time(
            v["batch_size"], 1, seed=cfg["seed"] + 32, dtype=dtype, device=device
        )
        la = lambda: gkdv1d_gradient_enhanced_loss(a, x, method="nested_ad").value
        lb = lambda: gkdv1d_gradient_enhanced_loss(b, x, method="rank_optimal").value
    else:
        order = 4 if benchmark == "poly4" else 6
        x = sample_normal_points(
            v["batch_size"],
            2,
            seed=cfg["seed"] + 32,
            dtype=dtype,
            device=device,
            std=0.25,
        )
        la = lambda: (
            polyharmonic_2d_operator(a, x, order=order, method="nested_ad")
            .value.square()
            .mean()
        )
        lb = lambda: (
            polyharmonic_2d_operator(b, x, order=order, method="rank_optimal")
            .value.square()
            .mean()
        )
    ga, _ = parameter_gradient(a, la)
    gb, _ = parameter_gradient(b, lb)
    return rel_l2(gb, ga), max_abs(gb, ga)


def kdv_analytic_validation(method, dtype, device):
    model, coeff = analytic_linear_activation(
        3, kind="sinh", dtype=dtype, device=device
    )
    x = torch.tensor([[0.1, -0.2, 0.3], [0.25, 0.15, 0.4]], dtype=dtype, device=device)
    result = kdv2d_residual(model, x, method=method)
    u = torch.sinh(x @ coeff.view(-1, 1) + model[0].bias)
    # Build each derivative by the closed-form sinh/cosh rule, then the exact residual.
    exact = {
        name: analytic_sinh_partial(model, x, coeff, alpha)
        for name, alpha in KDV2D_TERMS.items()
    }
    r = (
        exact["u_ty"]
        + exact["u_xxxy"]
        + 3 * (exact["u_xy"] * exact["u_x"] + exact["u_y"] * exact["u_xx"])
        - exact["u_xx"]
        + 2 * exact["u_yy"]
    )
    return rel_l2(result.value, r), max_abs(result.value, r)


def gkdv_analytic_validation(method, dtype, device):
    model, coeff = analytic_linear_activation(
        2, kind="sinh", dtype=dtype, device=device
    )
    x = torch.tensor([[0.1, 0.3], [-0.25, 0.4]], dtype=dtype, device=device)
    result = gkdv1d_gradient_enhanced_loss(model, x, method=method)
    d = {
        name: analytic_sinh_partial(model, x, coeff, alpha)
        for name, alpha in GKDV1D_TERMS.items()
    }
    u = model(x)
    f = d["u_t"] + u * d["u_x"] + 0.0025 * d["u_xxx"]
    fx = d["u_tx"] + d["u_x"] ** 2 + u * d["u_xx"] + 0.0025 * d["u_xxxx"]
    ft = d["u_tt"] + d["u_t"] * d["u_x"] + u * d["u_tx"] + 0.0025 * d["u_txxx"]
    loss = f.square().mean() + 1e-3 * (fx.square().mean() + ft.square().mean())
    errs = component_error_dict(
        result.components, {"f": f, "f_x": fx, "f_t": ft}, ["f", "f_x", "f_t"]
    )
    return (
        rel_l2(result.value.reshape(1), loss.reshape(1)),
        max_abs(result.value.reshape(1), loss.reshape(1)),
        errs,
    )


def poly_analytic_validation(method, order, dtype, device):
    model, coeff = analytic_linear_activation(2, kind="sin", dtype=dtype, device=device)
    x = torch.tensor([[0.1, -0.2], [0.25, 0.15]], dtype=dtype, device=device)
    result = polyharmonic_2d_operator(model, x, order=order, method=method)
    u = model(x)
    expected = (-(coeff.square().sum())) ** (order // 2) * u
    return rel_l2(result.value, expected), max_abs(result.value, expected)


def residual_row(cfg, benchmark, method, mode, dtype, device):
    net = cfg["network"]
    if benchmark == "kdv2d":
        dim = 3
        points = sample_upstream_unit_ball_space_time(
            cfg["batch_size"],
            2,
            seed=cfg["seed"] + 41,
            dtype=dtype,
            device=device,
            max_radius=cfg["pde"]["max_radius"],
            T=cfg["pde"]["T"],
        )
        timing_fixture = cfg["pde"].get("timing_fixture", "mlp")
        model = (
            make_tanh_mlp(
                dim,
                net["width"],
                net["depth"],
                seed=cfg["seed"] + 42,
                dtype=dtype,
                device=device,
            )
            if timing_fixture == "mlp"
            else analytic_linear_activation(
                dim, kind="sinh", dtype=dtype, device=device
            )[0]
        )
        evaluator = lambda create_graph=True: kdv2d_residual(
            model, points, method=method, create_graph=create_graph
        )
        ar, aa = kdv_analytic_validation(method, dtype, device)
        component_errors = None
        max_order = 4
        source = "STDE upstream KdV2d_res; equation independent of jet schedule; supplied source sets case=4"
    elif benchmark == "gkdv1d":
        dim = 2
        points = sample_upstream_unit_ball_space_time(
            cfg["batch_size"],
            1,
            seed=cfg["seed"] + 41,
            dtype=dtype,
            device=device,
            max_radius=cfg["pde"]["max_radius"],
            T=cfg["pde"]["T"],
        )
        timing_fixture = cfg["pde"].get("timing_fixture", "mlp")
        model = (
            make_tanh_mlp(
                dim,
                net["width"],
                net["depth"],
                seed=cfg["seed"] + 42,
                dtype=dtype,
                device=device,
            )
            if timing_fixture == "mlp"
            else analytic_linear_activation(
                dim, kind="sinh", dtype=dtype, device=device
            )[0]
        )
        evaluator = lambda create_graph=True: gkdv1d_gradient_enhanced_loss(
            model,
            points,
            method=method,
            lam1=cfg["gkdv1d"]["lambda1"],
            dispersion=cfg["gkdv1d"]["dispersion"],
            create_graph=create_graph,
        )
        ar, aa, component_errors = gkdv_analytic_validation(method, dtype, device)
        max_order = 4
        source = "STDE upstream highord1d_res case=4, eq=2; full f/f_x/f_t gradient-enhanced objective"
    else:
        order = 4 if benchmark == "poly4" else 6
        dim = 2
        points = sample_normal_points(
            cfg["batch_size"],
            2,
            seed=cfg["seed"] + 41,
            dtype=dtype,
            device=device,
            std=cfg["polyharmonic"]["point_std"],
        )
        timing_fixture = cfg["polyharmonic"].get("timing_fixture", "mlp")
        model = (
            make_tanh_mlp(
                dim,
                net["width"],
                net["depth"],
                seed=cfg["seed"] + 42,
                dtype=dtype,
                device=device,
            )
            if timing_fixture == "mlp"
            else analytic_linear_activation(
                dim, kind="sin", dtype=dtype, device=device
            )[0]
        )
        evaluator = lambda create_graph=True: polyharmonic_2d_operator(
            model, points, order=order, method=method, create_graph=create_graph
        )
        ar, aa = poly_analytic_validation(method, order, dtype, device)
        component_errors = None
        max_order = order
        source = f"Delta^{order // 2} in 2D expanded with binomial coefficients"

    validation_eval = evaluator()
    direction_evals = validation_eval.direction_evaluations
    grad_rel, grad_abs = validate_pde_parameter_grad(cfg, benchmark, dtype, device)

    def value_call():
        if method == "rank_optimal":
            with torch.no_grad():
                return evaluator(create_graph=False).value
        # The nested baseline still needs an input derivative graph to obtain
        # high-order values, but it does not need a parameter graph in value
        # mode.  Passing create_graph=False removes that avoidable component.
        return evaluator(create_graph=False).value

    def grad_call():
        model.zero_grad(set_to_none=True)
        ev = evaluator()
        loss = ev.value if ev.value.numel() == 1 else ev.value.square().mean()
        if loss.is_complex():
            loss = loss.real
        loss.backward()
        return loss

    timing = measure(
        value_call if mode == "value" else grad_call,
        device=device,
        warmups=cfg["warmups"],
        repeats=cfg["repeats"],
    )
    row = {
        "status": "ok",
        "backend": "torch",
        "benchmark": benchmark,
        "case": benchmark,
        "method": method,
        "mode": mode,
        "dtype_real": cfg["dtype"],
        "batch_size": cfg["batch_size"],
        "network_depth_linear_layers": net["depth"],
        "network_hidden_layers": net["depth"] - 1,
        "network_width": net["width"],
        "timing_fixture": timing_fixture,
        "max_derivative_order": max_order,
        "evaluated_direction_count": direction_evals,
        "analytic_rel_l2_error": ar,
        "analytic_max_abs_error": aa,
        "parameter_gradient_rel_l2_vs_nested": grad_rel,
        "parameter_gradient_max_abs_vs_nested": grad_abs,
        "definition_source": source,
        **timing,
    }
    if component_errors is not None:
        row["analytic_component_rel_l2"] = component_errors
        row["gkdv_lambda1"] = cfg["gkdv1d"]["lambda1"]
        row["gkdv_dispersion"] = cfg["gkdv1d"]["dispersion"]
    if benchmark.startswith("poly"):
        order = 4 if benchmark == "poly4" else 6
        row["operator_terms"] = [[c, list(a)] for c, a in POLYHARMONIC_2D[order]]
    return row


def main():
    parser = argparse.ArgumentParser(
        description="Torch Apolarity vs nested-AD benchmark"
    )
    parser.add_argument("--config", default=str(ROOT / "configs/main.yaml"))
    parser.add_argument(
        "--benchmark",
        choices=["all", "fixed", "kdv2d", "gkdv1d", "poly4", "poly6"],
        default="all",
    )
    parser.add_argument(
        "--method", choices=["both", "nested_ad", "rank_optimal"], default="both"
    )
    parser.add_argument(
        "--mode", choices=["both", "value", "parameter_grad"], default="both"
    )
    parser.add_argument(
        "--device", default=None, help="override config device: auto/cpu/cuda"
    )
    parser.add_argument("--out", default=str(ROOT / "results/torch_benchmark"))
    parser.add_argument("--direction-execution", choices=["batched", "serial"], default=None,
                        help="fixed-partial prepared protocol only; serial is an internal ablation")
    parser.add_argument("--compile-jets", action="store_true",
                        help="fixed-partial prepared protocol only; separately labelled optimization")
    args = parser.parse_args()
    config_path = Path(args.config).resolve()
    cfg = load_config(config_path)
    if cfg.get("fixed_execution", {}).get("prepare", False) and args.benchmark != "fixed":
        parser.error("the prepared first-group protocol requires --benchmark fixed")
    if args.direction_execution is not None or args.compile_jets:
        if args.benchmark != "fixed" or not cfg.get("fixed_execution", {}).get("prepare", False):
            parser.error("execution overrides require the prepared first-group configuration")
        if args.direction_execution is not None:
            cfg["fixed_execution"]["directions"] = args.direction_execution
        if args.compile_jets:
            cfg["fixed_execution"]["compile_jets"] = True
    if cfg.get("fixed_execution", {}).get("prepare", False):
        from apolarity.taylor_jet import set_compile_mode
        set_compile_mode(False)  # no hidden environment-based compilation
        torch.set_float32_matmul_precision("highest")
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    dtype = resolve_dtype(cfg["dtype"])
    device = resolve_device(args.device or cfg.get("device", "auto"))
    methods = ["nested_ad", "rank_optimal"] if args.method == "both" else [args.method]
    modes = ["value", "parameter_grad"] if args.mode == "both" else [args.mode]
    benches = (
        ["fixed", "kdv2d", "gkdv1d", "poly4", "poly6"]
        if args.benchmark == "all"
        else [args.benchmark]
    )
    rows = []
    for bench in benches:
        for method in methods:
            for mode in modes:
                try:
                    if bench == "fixed":
                        rows.extend(fixed_rows(cfg, method, mode, dtype, device))
                    else:
                        rows.append(
                            residual_row(cfg, bench, method, mode, dtype, device)
                        )
                except Exception as exc:
                    rows.append(
                        {
                            "status": "error",
                            "backend": "torch",
                            "benchmark": bench,
                            "method": method,
                            "mode": mode,
                            "error": repr(exc),
                        }
                    )
    prov = provenance(ROOT, config_path, device)
    for row in rows:
        row.update(
            {
                "seed": cfg["seed"],
                "device": str(device),
                "protocol_kind": cfg.get("protocol_kind", "primary"),
            }
        )
    json_path, csv_path = write_results(rows, args.out)
    prov_path = json_path.with_name(json_path.stem + "_provenance.json")
    prov_path.write_text(json.dumps(prov, indent=2), encoding="utf-8")
    frozen = json_path.with_name(json_path.stem + "_frozen_config.yaml")
    frozen.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
    print(
        json.dumps(
            {
                "results_json": str(json_path),
                "results_csv": str(csv_path),
                "provenance": str(prov_path),
                "rows": rows,
            },
            indent=2,
            default=str,
        )
    )
    if any(r.get("status") != "ok" for r in rows):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
