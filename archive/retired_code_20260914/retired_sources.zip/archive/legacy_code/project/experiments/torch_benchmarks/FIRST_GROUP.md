# First group: fixed mixed partials, official PyTorch only

## Question and scope

Measure the cost of one prescribed partial derivative of the SAME real-valued
network on the SAME batch of points. This is a derivative-backend benchmark,
not PDE training or a comparison of network architectures. No external
differentiation library, STDE adapter, JAX, custom CUDA kernel, or direction
chunking is used by this protocol. The existing Taylor rules and custom
activation backward are implemented with official PyTorch tensor operations.

Main comparison: `nested_ad` versus `rank_optimal`, both eager. Serial direction
execution and compiled jets are separately labelled internal ablations.

| Expanded target | Order | Complex Waring rank |
|---|---:|---:|
| 111111 | 6 | 1 |
| 111222 | 6 | 4 |
| 112233 | 6 | 9 |
| 123456 | 6 | 32 |
| 11223344 | 8 | 27 |
| 111222333 | 9 | 16 |

The four order-six cases isolate exponent structure at fixed order. Rank is
not a claim about GPU runtime, peak memory, or optimality over all algorithms.

## Frozen primary setting

`configs/first_group_torch.yaml`: scalar tanh MLP, 16 inputs, three hidden
layers of width 128, 100 points sampled from N(0, 0.35^2 I), float32 real
parameters and complex64 directions only when the roots require them.
TF32, AMP and the legacy environment-based jet compilation switch are disabled.
Model weights and points are reproduced from the same seeds for each method.
There is no optimizer and no parameter update inside the benchmark.

For T_p = D_v^p u / p!, weights include the normalization needed to recover
the prescribed partial. The batch and direction axes are flattened together;
linear layers also concatenate the coefficient orders into one matrix multiply.
Activation recurrences keep their order dependencies but operate on all points
and directions as tensors. Serial mode uses identical directions and weights,
stacks the coefficients, and uses the same final reduction.

## What is timed

Setup is separate: model construction, sampling, directions/weights, fixed
direction expansion, and reference checks. `preparation_ms` records evaluator
preparation, not the whole program's initialization. No parameter-dependent
activation, parameter cast, or derivative value is cached across calls.

- `value`: compute the B partial values, including jet propagation and weighted
  summation. The jet path disables parameter graph recording; nested AD retains
  the input graphs needed for high-order differentiation.
- `parameter_grad`: clear parameter gradients, recompute the B partials,
  form mean(partial ** 2), and backpropagate to all network parameters.
  Input gradients are not accumulated. This is forward-plus-backward timing,
  not backward-only timing.

`first_call_ms` includes the first evaluation (and first compilation/backward
compilation where applicable). It is excluded from steady-state statistics.
Use 10 warmups and 30 synchronized wall-clock samples. CUDA memory is the
absolute peak allocated bytes, INCLUDING resident model/prepared tensors; CPU
RSS is process-wide and is not suitable for a per-case memory comparison.
Use separate processes for formal memory comparisons. The JSON retains raw
timing samples and the frozen effective configuration records CLI overrides.

Basic analytic-value and small-network parameter-gradient checks run before
timing; nonfinite or relative discrepancies >= 1e-3 stop that target group.
These checks are a smoke gate, not a numerical stability study. Regression
tests separately check the prepared/serial paths and parameter updates.

## Entry points (not yet executed on H20)

Main eager comparison (24 rows per seed):

```bash
python experiments/torch_benchmarks/run.py --config configs/first_group_torch.yaml --benchmark fixed --out results/first_group/eager_seed20260908
```

Direction-parallelism ablation, otherwise identical:

```bash
python experiments/torch_benchmarks/run.py --config configs/first_group_torch.yaml --benchmark fixed --method rank_optimal --direction-execution serial --out results/first_group/serial_seed20260908
```

Optional compiler ablation (not merged into the main eager-versus-eager table):

```bash
python experiments/torch_benchmarks/run.py --config configs/first_group_torch.yaml --benchmark fixed --method rank_optimal --compile-jets --out results/first_group/compiled_seed20260908
```

Compilation uses fullgraph=True: a graph break or unsupported operation is an
error, not an eager fallback labelled as compiled. Actual CUDA compiler support,
complex paths, speedups and memory costs must be verified on the selected H20.

Use fresh output prefixes; do not overwrite historical measurements. The old
`configs/main.yaml`, JAX protocol, PDE formulas, and T4 artifacts are unchanged.
Before publication, freeze independent repeats (suggested seeds 20260908,
20260909, 20260910) and record actual GPU, software, source snapshot, allocation
baseline and workload isolation. Do not infer H20 results from CPU tests.
