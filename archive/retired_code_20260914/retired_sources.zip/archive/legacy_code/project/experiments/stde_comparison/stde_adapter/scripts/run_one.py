#!/usr/bin/env python3
"""Run exactly one value/gradient benchmark case in a fresh process."""

import argparse
import json

import _bootstrap
from webexp.benchmark import run_case
from webexp.config import load


parser = argparse.ArgumentParser()
parser.add_argument("--target", required=True)
parser.add_argument(
    "--method", choices=["rank_optimal", "stde", "nested_ad"], required=True
)
parser.add_argument("--mode", choices=["value", "backward"], default="value")
parser.add_argument("--depth", type=int)
parser.add_argument("--width", type=int)
parser.add_argument("--batch", type=int)
parser.add_argument("--chunk", default="all")
args = parser.parse_args()

cfg = load(_bootstrap.EXP / "configs/main.yaml")
chunk = args.chunk if args.chunk == "all" else int(args.chunk)
row = run_case(
    args.method,
    args.target,
    cfg,
    args.mode,
    depth=args.depth,
    width=args.width,
    batch=args.batch,
    chunk_size=chunk,
)
print(json.dumps(row, default=str))
