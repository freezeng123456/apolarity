from __future__ import annotations


def derivative_one(fun, point, alpha, chunk_size=None):
    import jax

    f = fun
    for coordinate in alpha:
        prev = f

        def next_function(z, prev=prev, c=int(coordinate)):
            return jax.grad(prev)(z)[c]

        f = next_function
    return f(point)
