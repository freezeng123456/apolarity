import numpy as np
import jax
import jax.numpy as jnp
from webexp.methods import METHODS
from webexp.fixtures import mlp_one

jax.config.update("jax_enable_x64", True)

PARAMS = (
    (
        jnp.array([[0.2, -0.3], [0.5, 0.1], [-0.4, 0.25]], dtype=jnp.float64),
        jnp.array([0.01, -0.02, 0.03], dtype=jnp.float64),
    ),
    (
        jnp.array([[0.4, -0.2, 0.3]], dtype=jnp.float64),
        jnp.array([0.05], dtype=jnp.float64),
    ),
)
X = jnp.array([[-0.25, 0.1], [0.2, -0.4], [0.15, 0.3]], dtype=jnp.float64)


def test_values_and_parameter_gradients_match_nested():
    for alpha in [(0, 1), (0, 0, 1), (0, 0, 0, 0)]:

        def values(name, params):
            a = METHODS[name]
            return jax.vmap(
                lambda p: a.derivative_one(lambda z: mlp_one(params, z), p, alpha)
            )(X)

        ref = values("nested_ad", PARAMS)

        def loss(name, params):
            return jnp.mean(jnp.real(values(name, params)) ** 2)

        rg = jax.grad(lambda p: loss("nested_ad", p))(PARAMS)
        for name in ["rank_optimal", "stde"]:
            got = values(name, PARAMS)
            np.testing.assert_allclose(
                np.asarray(got).real, np.asarray(ref), rtol=2e-8, atol=2e-9
            )
            np.testing.assert_allclose(np.asarray(got).imag, 0, atol=2e-9)
            gg = jax.grad(lambda p: loss(name, p))(PARAMS)
            for x, y in zip(
                jax.tree_util.tree_leaves(gg), jax.tree_util.tree_leaves(rg)
            ):
                np.testing.assert_allclose(
                    np.asarray(x), np.asarray(y), rtol=2e-7, atol=2e-9
                )
