#!/usr/bin/env python3
"""Run the flagship chunk ablation with one fresh process per cell."""

import argparse
import json
import sys

import _bootstrap
from webexp.config import load
from webexp.io import write_records
from webexp.runner import run_with_timeout
from webexp.targets import FLAGSHIP


def decode_row(stdout):
    for line in reversed(stdout.splitlines()):
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    raise ValueError("worker did not emit a JSON row")


parser = argparse.ArgumentParser()
parser.parse_args()
cfg = load(_bootstrap.EXP / "configs/main.yaml")
worker = _bootstrap.EXP / "scripts/run_one.py"
rows = []
for target in FLAGSHIP:
    for method in ["rank_optimal", "stde"]:
        for chunk in cfg["direction_chunks"]:
            for mode in ["value", "backward"]:
                command = [
                    sys.executable,
                    str(worker),
                    "--target",
                    target,
                    "--method",
                    method,
                    "--mode",
                    mode,
                    "--chunk",
                    str(chunk),
                ]
                result = run_with_timeout(command, cfg["compile_timeout_seconds"])
                if result.get("status") == "ok":
                    try:
                        row = decode_row(result.get("stdout", ""))
                    except Exception as error:
                        row = {
                            "status": "error",
                            "error": f"could not parse worker output: {error}",
                        }
                else:
                    row = dict(result)
                row.update(
                    {
                        "target": target,
                        "method": method,
                        "mode": mode,
                        "chunk_size": str(chunk),
                    }
                )
                rows.append(row)
write_records(rows, _bootstrap.EXP / "results/chunks")
print(json.dumps(rows, indent=2, default=str))
