from __future__ import annotations
import math
from jax.experimental import jet


def jet_factorial_scaled(fun, primals, series):
    """Call :func:`jax.experimental.jet.jet` in derivative normalization.

    JAX releases before the public ``factorial_scaled`` keyword already used
    factorial-scaled derivatives.  The compatibility branch keeps the pinned
    STDE/JAX 0.4.x environment working while making the intended convention
    explicit on newer releases.
    """

    try:
        return jet.jet(fun, primals, series, factorial_scaled=True)
    except TypeError as error:
        if "factorial_scaled" not in str(error):
            raise
        return jet.jet(fun, primals, series)


def taylor_series(fun, point, direction, order):
    import jax.numpy as jnp

    z = jnp.zeros_like(direction)
    series = (direction,) + tuple(z for _ in range(order - 1))
    _, out = jet_factorial_scaled(fun, (point,), (series,))
    return tuple(out[k] / math.factorial(k + 1) for k in range(order))


def taylor_coeff(fun, point, direction, order):
    return taylor_series(fun, point, direction, order)[order - 1]


def sparse_taylor_derivative(fun, point, series, order):
    """Return the order-``order`` factorial-scaled jet entry.

    ``series`` contains the input derivatives at orders one through
    ``order``.  The original STDE construction uses these higher-order seed
    terms directly, rather than representing every evaluation as a linear
    path.  Keeping the explicit ``factorial_scaled`` flag makes the
    coefficient convention independent of the installed JAX default.
    """

    _, out = jet_factorial_scaled(fun, (point,), (tuple(series),))
    return out[order - 1]
