#!/usr/bin/env python3
import _bootstrap
import argparse
from webexp.config import load
from webexp.accuracy import run
from webexp.io import write_records

p = argparse.ArgumentParser()
p.add_argument("--include-optional", action="store_true")
a = p.parse_args()
cfg = load(_bootstrap.EXP / "configs/main.yaml")
rows = run(cfg, a.include_optional)
write_records(rows, _bootstrap.EXP / "results/accuracy")
print(len(rows), "records")
