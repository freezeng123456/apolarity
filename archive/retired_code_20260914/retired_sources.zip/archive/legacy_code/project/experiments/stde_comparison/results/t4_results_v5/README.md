# T4 run record (2026-09-03, primary protocol v5)

These files were copied from the isolated run rooted at
`/data/apolarity_stde_runs_20260903_v5/web_experiments_20260903` on the
Tesla T4 host. The comparison contains exactly `rank_optimal`, the
deterministic original `stde` control, and `nested_ad`; randomized methods and
STDE++ are excluded.

The frozen protocol uses real `float32` arithmetic (and `complex64` only for
the rank-optimal complex directions), a four-hidden-layer width-128 tanh
network, and **batch 100**. The batch follows the upstream STDE
`EqnConfig` default and the high-order `insep.sh` example. The primary STDE
rows use the full direction set (`chunk=all`): the upstream implementation
does not direction-chunk these deterministic Taylor jets. The optional chunk
argument in the harness is retained only for a separately labelled memory
diagnostic and is not part of the primary table.

The run used Python 3.10.20, JAX/JAXLIB 0.4.30, driver 535.161.07,
`CUDA_VISIBLE_DEVICES=0`, and `XLA_PYTHON_CLIENT_PREALLOCATE=false`. The
JAX compiler was rolled back from the wheel's CUDA 12.9 `ptxas` to the
isolated `nvidia-cuda-nvcc-cu12==12.2.140` package, matching the host driver's
CUDA 12.2 release. The post-rollback GPU smoke test selected the `gpu`
backend, and the v5 runs did not emit the earlier compiler-version warning.
The compiler path and version are recorded in `provenance.json`.

`accuracy.json` contains 60 rows: 52 successful checks and eight explicit
high-order nested-AD skips. The four residual JSON files contain three
successful methods each. `manual_timing.json` records the fresh-process
high-order and representative low-order timing rows, including the bounded
nested-AD timeout. `peak_bytes_in_use` is the XLA allocator peak reported by
the benchmark process; it should not be read as an independent NVML trace.

The unchunked high-order value cases fit on the T4 at batch 100. A separate
high-order parameter-backward table was not made part of this primary run;
an A100 is therefore not needed for the current value comparison. It is a
reasonable follow-up only if the paper requires that additional backward
scaling table.
