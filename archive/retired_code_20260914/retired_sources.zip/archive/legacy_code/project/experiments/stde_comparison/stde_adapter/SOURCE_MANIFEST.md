# Source manifest

This package is a reviewable experiment harness generated from the uploaded
source trees. The source trees themselves are not modified by this package.

* **Apolarity implementation:** `https://github.com/freezeng123456/apolarity`
  (the uploaded working tree was used as context; uncommitted repository state
  is intentionally not represented as a source commit here).
* **STDE implementation:** `https://github.com/sail-sg/stde`, commit
  `fae88663b1d2f1b0666d4d250c38a3c34b852ac0`.
* **External references:** the official STDE NeurIPS 2024 paper and the JAX
  `jax.experimental.jet` documentation.

The primary comparison has three methods only: the rank-optimal apolarity
schedule, the deterministic original-STDE jet construction, and nested AD.
No grouped-polarization implementation is included. The STDE residual
adapters follow the deterministic KdV and g-KdV schedule shapes from the
pinned STDE tree; the monomial adapter uses the deterministic
sparse/multi-pushforward form of the original paper's arbitrary mixed-partial
construction.
