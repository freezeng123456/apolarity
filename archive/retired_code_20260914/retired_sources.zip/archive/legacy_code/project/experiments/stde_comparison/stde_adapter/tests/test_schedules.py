from webexp.schedules import (
    coefficient_residual,
    stde_schedule,
    waring_roots_of_unity,
    moment_residual,
)
from webexp.targets import TARGET_MAP, theoretical_rank


def test_flagship_counts_and_moments():
    expected = {"u_11223344": (27, 108, 20), "u_111222333": (16, 37, 18)}
    for name, (rank, stde_jets, stde_order) in expected.items():
        alpha = TARGET_MAP[name].alpha
        wr = waring_roots_of_unity(alpha, 16)
        st = stde_schedule(alpha, 16)
        assert len(wr.weights) == rank == theoretical_rank(alpha)
        assert len(st.weights) == stde_jets
        assert st.order == stde_order
        assert moment_residual(wr, alpha) < 1e-10
        assert coefficient_residual(st, alpha) < 1e-10


def test_controls_counts():
    for name in ["u_12", "u_112", "pure4", "u_1234", "pure6"]:
        a = TARGET_MAP[name].alpha
        assert len(waring_roots_of_unity(a, 16).weights) == theoretical_rank(a)
        assert coefficient_residual(stde_schedule(a, 16), a) < 1e-10
