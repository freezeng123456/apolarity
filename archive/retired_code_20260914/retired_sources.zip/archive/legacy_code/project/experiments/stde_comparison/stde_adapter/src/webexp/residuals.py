from __future__ import annotations
from .methods import METHODS
from .methods.common import jet_factorial_scaled

KDV2D_ALPHAS = {
    "u_x": (0,),
    "u_y": (1,),
    "u_xx": (0, 0),
    "u_xy": (0, 1),
    "u_yy": (1, 1),
    "u_ty": (1, 2),
    "u_xxxy": (0, 0, 0, 1),
}
GKDV1D_ALPHAS = {
    "u_x": (0,),
    "u_t": (1,),
    "u_xx": (0, 0),
    "u_tx": (1, 0),
    "u_tt": (1, 1),
    "u_xxx": (0, 0, 0),
    "u_xxxx": (0, 0, 0, 0),
    "u_txxx": (1, 0, 0, 0),
}


def _partial(adapter, fun, point, alpha):
    return adapter.derivative_one(fun, point, alpha)


def kdv2d_generic(method, fun, point):
    a = METHODS[method]
    d = {k: _partial(a, fun, point, v) for k, v in KDV2D_ALPHAS.items()}
    return (
        d["u_ty"]
        + d["u_xxxy"]
        + 3 * (d["u_xy"] * d["u_x"] + d["u_y"] * d["u_xx"])
        - d["u_xx"]
        + 2 * d["u_yy"]
    )


def gkdv1d_generic(method, fun, point):
    a = METHODS[method]
    d = {k: _partial(a, fun, point, v) for k, v in GKDV1D_ALPHAS.items()}
    u = fun(point)
    f = d["u_t"] + u * d["u_x"] + 0.0025 * d["u_xxx"]
    fx = d["u_tx"] + d["u_x"] ** 2 + u * d["u_xx"] + 0.0025 * d["u_xxxx"]
    ft = d["u_tt"] + d["u_t"] * d["u_x"] + u * d["u_tx"] + 0.0025 * d["u_txxx"]
    return f, fx, ft


def stde_official_kdv2d_case3(fun, point):
    """Original STDE KdV2d case=3 schedule (one 9-jet and two 3-jets).

    This is the lower-order deterministic schedule in the official STDE
    implementation.  The mixed ninth-order coefficient is evaluated from the
    partition ``9=2+2+2+3``; its Faà di Bruno factor is 1260.
    """
    import jax.numpy as jnp

    xy = point[:2]
    t = point[2]
    zero2 = jnp.zeros(2, dtype=point.dtype)
    series = [zero2 for _ in range(9)]
    series[1] = jnp.eye(2, dtype=point.dtype)[0]
    series[2] = jnp.eye(2, dtype=point.dtype)[1]

    def fxy(q):
        return fun(jnp.array([q[0], q[1], t], dtype=point.dtype))

    out = jet_factorial_scaled(fxy, (xy,), (tuple(series),))[1]
    u_x = out[1]
    u_y = out[2]
    u_xx = out[3] / 3
    u_xy = out[4] / 10
    mixed = out[8]

    e_y = jnp.eye(3, dtype=point.dtype)[1]
    e_t = jnp.eye(3, dtype=point.dtype)[2]
    zero3 = jnp.zeros(3, dtype=point.dtype)
    y_t_mix = jet_factorial_scaled(fun, (point,), ((e_y, e_t, zero3),))[1][2]
    y_only = jet_factorial_scaled(fun, (point,), ((e_y, zero3, zero3),))[1]
    u_yy = y_only[1]
    u_yyy = y_only[2]
    u_xxxy = (mixed - 280 * u_yyy) / 1260
    u_ty = (y_t_mix - u_yyy) / 3
    return u_ty + u_xxxy + 3 * (u_xy * u_x + u_y * u_xx) - u_xx + 2 * u_yy


def stde_official_gkdv_7jet(fun, point):
    """Official STDE gPINN case=4 schedule (x,t), plus the official t-only 2-jet."""
    import jax.numpy as jnp

    series = [jnp.zeros(2, dtype=point.dtype) for _ in range(7)]
    series[0] = jnp.eye(2, dtype=point.dtype)[0]
    u0, out1 = jet_factorial_scaled(fun, (point,), (tuple(series),))
    ux, uxx, uxxx, uxxxx, uxxxxx = out1[:5]
    series[3] = jnp.eye(2, dtype=point.dtype)[1]
    _, out2 = jet_factorial_scaled(fun, (point,), (tuple(series),))
    # t_coeff(7, [(4,1),(1,3)]) = 35
    utxxx = (out2[6] - out1[6]) / 35
    utx = (out2[4] - uxxxxx) / 5
    ut = out2[3] - uxxxx
    e_t = jnp.eye(2, dtype=point.dtype)[1]
    z = jnp.zeros(2, dtype=point.dtype)
    utt = jet_factorial_scaled(fun, (point,), ((e_t, z),))[1][1]
    f = ut + u0 * ux + 0.0025 * uxxx
    fx = utx + ux * ux + u0 * uxx + 0.0025 * uxxxx
    ft = utt + ut * ux + u0 * utx + 0.0025 * utxxx
    return f, fx, ft


def schedule_summary(method, operator):
    if method == "nested_ad":
        return {
            "distinct_jets": None,
            "by_order": {},
            "max_jet_order": None,
            "construction": "nested coordinate AD",
        }
    if method == "stde" and operator == "kdv2d":
        return {
            "distinct_jets": 3,
            "by_order": {"9": 1, "3": 2},
            "max_jet_order": 9,
            "construction": "official original STDE KdV2d case=3: one 9-jet and two 3-jets",
        }
    if method == "stde" and operator == "gkdv1d":
        return {
            "distinct_jets": 3,
            "by_order": {"7": 2, "2": 1},
            "max_jet_order": 7,
            "construction": "official original STDE gPINN case=4: two 7-jets and one 2-jet",
        }
    alphas = KDV2D_ALPHAS.values() if operator == "kdv2d" else GKDV1D_ALPHAS.values()
    adapter = METHODS[method]
    req = []
    for alpha in alphas:
        s = adapter.schedule(alpha, 3 if operator == "kdv2d" else 2)
        req.extend((v, len(alpha)) for v in s.directions)
    by = {}
    for _, order in req:
        by[str(order)] = by.get(str(order), 0) + 1
    return {
        "distinct_jets": len(req),
        "by_order": by,
        "max_jet_order": max(order for _, order in req),
        "construction": "termwise schedules; no cross-term reuse",
    }
