from __future__ import annotations
from ..schedules import stde_schedule
from .common import sparse_taylor_derivative


def schedule(alpha, d):
    return stde_schedule(tuple(alpha), d)


def derivative_one(fun, point, alpha, chunk_size=None):
    import jax
    import jax.numpy as jnp

    s = schedule(alpha, point.shape[0])
    series = jnp.asarray(s.tangent_series, dtype=point.dtype)
    ws = jnp.asarray(s.weights, dtype=point.dtype)
    n = series.shape[0]
    chunk = n if chunk_size in (None, "all") else int(chunk_size)

    def ev(ss):
        return jax.vmap(
            lambda one_series: sparse_taylor_derivative(fun, point, one_series, s.order)
        )(ss)

    if chunk >= n:
        return jnp.sum(ws * ev(series))

    # Keep the chunk loop inside a lazy JAX map.  A Python loop here is
    # unrolled while the outer benchmark function is traced by ``jit``;
    # for high-order targets this creates one large compilation graph for
    # every chunk.  Padding the final block lets ``lax.map`` compile one
    # fixed-size block and accumulate the blocks sequentially, reducing
    # compilation pressure and peak live memory without changing the
    # directional schedule or its arithmetic.
    num_chunks = (n + chunk - 1) // chunk
    padded = num_chunks * chunk - n
    series_pad_width = ((0, padded),) + ((0, 0),) * (series.ndim - 1)
    series_padded = jnp.pad(series, series_pad_width)
    weights_padded = jnp.pad(ws, ((0, padded),))
    series_blocks = series_padded.reshape((num_chunks, chunk) + series.shape[1:])
    weight_blocks = weights_padded.reshape((num_chunks, chunk))

    def block_value(block):
        block_series, block_weights = block
        return jnp.sum(block_weights * ev(block_series))

    return jnp.sum(jax.lax.map(block_value, (series_blocks, weight_blocks)))
