from . import rank_optimal, stde_deterministic, nested_ad

stde = stde_deterministic
METHODS = {"rank_optimal": rank_optimal, "stde": stde, "nested_ad": nested_ad}
