from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import cmath
import itertools
import math
from functools import lru_cache

import numpy as np


@dataclass(frozen=True)
class Schedule:
    """A fixed collection of Taylor-jet evaluations.

    ``directions`` and ``weights`` describe the ordinary linear-jet schedules
    used by the rank-optimal method.  The original STDE construction also
    allows higher-order input tangent terms.  Such schedules store the
    factorial-scaled input series in ``tangent_series`` with shape
    ``(number_of_jets, jet_order, dimension)``.  Keeping both representations
    in one small record lets the benchmark use the same accounting code for
    the two methods without treating an STDE jet as a collection of ordinary
    first-order directions.
    """

    directions: np.ndarray
    weights: np.ndarray
    order: int
    construction: str
    tangent_series: np.ndarray | None = None


def _weighted_compositions(weights, total):
    """Return all nonnegative vectors ``m`` with ``weights @ m == total``."""

    out = []

    def visit(i, remaining, prefix):
        if i == len(weights):
            if remaining == 0:
                out.append(tuple(prefix))
            return
        step = int(weights[i])
        for count in range(remaining // step + 1):
            visit(i + 1, remaining - count * step, (*prefix, count))

    visit(0, int(total), ())
    return tuple(out)


def _weighted_composition_count(weights, total, cap=2):
    """Count weighted compositions, stopping once ``cap`` is reached."""

    weights = tuple(int(x) for x in weights)

    @lru_cache(maxsize=None)
    def count(index, remaining):
        if index == len(weights):
            return int(remaining == 0)
        step = weights[index]
        total_count = 0
        for multiplicity in range(remaining // step + 1):
            total_count += count(index + 1, remaining - multiplicity * step)
            if total_count >= cap:
                return cap
        return total_count

    return count(0, int(total))


def _unique_weighted_representation(positions, target, total):
    """Check whether ``target`` is the unique solution of a weighted sum."""

    if sum(m * j for m, j in zip(target, positions)) != total:
        return False
    return _weighted_composition_count(positions, total) == 1


def _find_unique_positions(exponents, max_position=16):
    """Find a small deterministic STDE position set when one exists.

    Appendix F of the original STDE paper isolates a mixed derivative by
    choosing Taylor positions for which the target partition is unique.  The
    search is finite and cached because the benchmark uses a fixed target
    catalogue.  Returning ``None`` is intentional: the original paper also
    allows several pushforwards when a unique partition is unavailable.
    """

    target = tuple(int(x) for x in exponents)
    best = None
    for positions in itertools.combinations(range(1, max_position + 1), len(target)):
        total = sum(q * j for q, j in zip(target, positions))
        if _unique_weighted_representation(positions, target, total):
            candidate = (total, positions)
            if best is None or candidate < best:
                best = candidate
    return None if best is None else best[1]


def _coefficient(order, multiplicities, positions):
    """Faà di Bruno coefficient for one sparse input Taylor jet."""

    log_value = math.lgamma(order + 1)
    log_value -= sum(math.lgamma(m + 1) for m in multiplicities)
    log_value -= sum(m * math.lgamma(j + 1) for m, j in zip(multiplicities, positions))
    return math.exp(log_value)


def _deterministic_nodes(number, dimension):
    """A reproducible real node cloud used by the multi-jet STDE fallback."""

    # A fixed low-discrepancy sequence avoids a hidden random seed while
    # providing full-rank evaluation matrices for the small supports here.
    # Keep the coordinates in (approximately) [0, 1] rather than centering
    # them at zero: centered Halton points can contain an exact zero, which
    # makes the odd-monomial Vandermonde system singular for some supports.
    bases = (2, 3, 5, 7, 11, 13)
    nodes = []
    for index in range(1, number + 1):
        row = []
        for base in bases[:dimension]:
            value = 0.0
            factor = 1.0
            quotient = index
            while quotient:
                factor /= base
                value += factor * (quotient % base)
                quotient //= base
            row.append(2.0 * value - 1.0)
        nodes.append(row)
    return (np.asarray(nodes, dtype=np.float64) + 1.0) / 2.0


def _interpolation_weights(support, order, positions):
    """Solve the deterministic STDE multi-pushforward coefficient system."""

    count = len(support)
    nodes = _deterministic_nodes(count, len(positions))
    coeffs = np.asarray(
        [_coefficient(order, m, positions) for m in support], dtype=np.float64
    )
    matrix = np.asarray(
        [
            [np.prod(nodes[row] ** np.asarray(m)) for m in support]
            for row in range(count)
        ],
        dtype=np.float64,
    )
    matrix *= coeffs[None, :]
    # The caller replaces the right-hand side with the target support index.
    return nodes, coeffs, matrix


@lru_cache(maxsize=None)
def _stde_schedule_cached(alpha, d):
    counts = Counter(alpha)
    active = tuple(sorted(counts))
    exponents = tuple(counts[index] for index in active)

    # First use the one-pushforward construction whenever the target partition
    # is unique.  This is the direct deterministic construction described in
    # the original STDE paper.  Extremely high-order one-pushforward jets can
    # amplify roundoff through very large Faà di Bruno coefficients, so the
    # bounded-order fallback below is preferred once the sparse jet becomes
    # numerically extreme.
    positions = _find_unique_positions(exponents)
    if positions is not None:
        jet_order = sum(q * j for q, j in zip(exponents, positions))
        coefficient = _coefficient(jet_order, exponents, positions)
        if jet_order <= 16 and np.isfinite(coefficient):
            tangent = np.zeros((1, jet_order, d), dtype=np.float64)
            for index, position in zip(active, positions):
                tangent[0, position - 1, index] = 1.0
            weight = 1.0 / coefficient
            representative = tangent[:, 0, :]
            return Schedule(
                representative,
                np.asarray([weight], dtype=np.float64),
                jet_order,
                "original STDE deterministic sparse single-jet construction",
                tangent,
            )

    # If no unique partition is available, retain the original STDE option of
    # using several deterministic pushforwards and solving the resulting
    # linear coefficient system.  The low-order positions keep the jet order
    # modest; the number of jets is the size of the finite partition support.
    positions = tuple(range(1, len(active) + 1))
    jet_order = sum(q * j for q, j in zip(exponents, positions))
    support = _weighted_compositions(positions, jet_order)
    if exponents not in support:
        raise ValueError("the target multi-index is absent from the STDE jet support")
    nodes, _, matrix = _interpolation_weights(support, jet_order, positions)
    rhs = np.zeros(len(support), dtype=np.float64)
    rhs[support.index(exponents)] = 1.0
    weights = np.linalg.solve(matrix.T, rhs)
    tangent = np.zeros((len(nodes), jet_order, d), dtype=np.float64)
    for row, node in enumerate(nodes):
        for index, position, amplitude in zip(active, positions, node):
            tangent[row, position - 1, index] = amplitude
    representative = tangent[:, 0, :]
    return Schedule(
        representative,
        weights,
        jet_order,
        "original STDE deterministic multi-jet coefficient interpolation",
        tangent,
    )


def stde_schedule(alpha, d):
    """Construct the deterministic, non-randomized original-STDE schedule.

    The schedule uses the paper's sparse Taylor positions and, when needed,
    a deterministic coefficient solve over several pushforwards.  This is the
    only STDE schedule exposed by the experiment protocol.
    """

    return _stde_schedule_cached(tuple(int(x) for x in alpha), int(d))


def waring_roots_of_unity(alpha, d):
    counts = Counter(alpha)
    active = sorted(counts.items(), key=lambda kv: (kv[1], kv[0]))
    base = active[0][0]
    other = active[1:]
    rank = math.prod(e + 1 for _, e in other)
    af = math.prod(math.factorial(e) for e in counts.values())
    roots = [
        tuple(cmath.exp(2j * math.pi * k / (e + 1)) for k in range(e + 1))
        for _, e in other
    ]
    ds = []
    ws = []
    for rr in itertools.product(*roots) if roots else [()]:
        v = np.zeros(d, np.complex128)
        v[base] = 1
        w = af / rank
        for (idx, _), r in zip(other, rr):
            v[idx] = r
            w *= r
        ds.append(v)
        ws.append(w)
    return Schedule(
        np.stack(ds),
        np.asarray(ws, np.complex128),
        len(alpha),
        "rank-optimal roots-of-unity Waring",
    )


def moment_residual(schedule: Schedule, alpha, atol_filter=1e-12):
    """Exact coefficient-filter residual over all degree-p monomials on active coordinates."""
    active = sorted(set(alpha))
    p = len(alpha)
    target = tuple(sorted(alpha))
    worst = 0.0

    def rec(pos, left, prefix):
        if pos == len(active) - 1:
            yield prefix + (active[pos],) * left
            return
        for n in range(left + 1):
            yield from rec(pos + 1, left - n, prefix + (active[pos],) * n)

    for beta in rec(0, p, ()):
        bc = Counter(beta)
        denom = math.prod(math.factorial(v) for v in bc.values())
        powers = np.ones(len(schedule.weights), dtype=np.complex128)
        for idx, pow_ in bc.items():
            powers *= schedule.directions[:, idx] ** pow_
        actual = np.sum(schedule.weights * powers) / denom
        expected = 1.0 if beta == target else 0.0
        worst = max(worst, float(abs(actual - expected)))
    return worst


def coefficient_residual(schedule: Schedule, alpha):
    """Check the coefficient identity for either schedule representation."""

    if schedule.tangent_series is None:
        return moment_residual(schedule, alpha)

    counts = Counter(alpha)
    active = tuple(sorted(counts))
    exponents = tuple(counts[index] for index in active)
    positions = []
    for index in active:
        nonzero = np.flatnonzero(
            np.abs(schedule.tangent_series[:, :, index]).max(axis=0) > 1e-14
        )
        if len(nonzero) != 1:
            return float("inf")
        positions.append(int(nonzero[0]) + 1)
    positions = tuple(positions)
    support = _weighted_compositions(positions, schedule.order)
    worst = 0.0
    for beta in support:
        value = 0.0
        beta_coeff = _coefficient(schedule.order, beta, positions)
        for row, weight in enumerate(schedule.weights):
            amplitudes = [
                schedule.tangent_series[row, position - 1, index]
                for index, position in zip(active, positions)
            ]
            value += (
                weight
                * beta_coeff
                * np.prod(np.asarray(amplitudes) ** np.asarray(beta))
            )
        expected = 1.0 if beta == exponents else 0.0
        worst = max(worst, float(abs(value - expected)))
    return worst
