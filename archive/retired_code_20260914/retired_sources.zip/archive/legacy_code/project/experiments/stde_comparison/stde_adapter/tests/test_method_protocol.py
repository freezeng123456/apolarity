from pathlib import Path

import yaml

from webexp.config import ALLOWED_METHODS


def test_primary_protocol_contains_only_requested_methods():
    config_path = Path(__file__).parents[1] / "configs" / "main.yaml"
    configured = yaml.safe_load(config_path.read_text())["methods"]
    assert configured == ["rank_optimal", "stde", "nested_ad"]
    assert tuple(configured) == ALLOWED_METHODS

    # Importing the registry also imports JAX.  Keep the source-level protocol
    # check runnable in the lightweight review environment, where JAX is absent.
    registry = config_path.parents[1] / "src" / "webexp" / "methods" / "__init__.py"
    text = registry.read_text()
    for name in ALLOWED_METHODS:
        assert f'"{name}"' in text
    assert "stde++" not in text
    assert "grouped_polarization" not in text
