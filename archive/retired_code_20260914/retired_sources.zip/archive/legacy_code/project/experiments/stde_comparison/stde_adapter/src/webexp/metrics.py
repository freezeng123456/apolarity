from __future__ import annotations
import numpy as np


def errors(actual, reference):
    a = np.asarray(actual)
    r = np.asarray(reference)
    diff = a - r
    denom = max(float(np.linalg.norm(r.ravel())), 1e-30)
    return {
        "relative_l2": float(np.linalg.norm(diff.ravel()) / denom),
        "max_abs": float(np.max(np.abs(diff))),
        "imaginary_leakage": float(np.max(np.abs(np.imag(a)))),
    }


def flatten_tree(tree):
    import jax

    return np.concatenate(
        [np.asarray(x).reshape(-1) for x in jax.tree_util.tree_leaves(tree)]
    )
