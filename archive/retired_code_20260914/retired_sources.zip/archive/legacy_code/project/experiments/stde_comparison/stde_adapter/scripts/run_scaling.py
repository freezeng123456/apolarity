#!/usr/bin/env python3
"""Launch each scaling cell in an isolated worker process."""

import argparse
import json
import sys

import _bootstrap
from webexp.config import load
from webexp.io import write_records
from webexp.runner import run_with_timeout
from webexp.targets import SCALING_TARGETS


def decode_row(stdout):
    for line in reversed(stdout.splitlines()):
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    raise ValueError("worker did not emit a JSON row")


parser = argparse.ArgumentParser()
parser.add_argument("--factor", choices=["depth", "width", "batch"], required=True)
parser.add_argument("--mode", choices=["value", "backward"], default="value")
args = parser.parse_args()
cfg = load(_bootstrap.EXP / "configs/main.yaml")
worker = _bootstrap.EXP / "scripts/run_one.py"
rows = []
for target in SCALING_TARGETS:
    for method in cfg["methods"]:
        for value in cfg["scaling"][args.factor]:
            command = [
                sys.executable,
                str(worker),
                "--target",
                target,
                "--method",
                method,
                "--mode",
                args.mode,
                f"--{args.factor}",
                str(value),
            ]
            result = run_with_timeout(command, cfg["compile_timeout_seconds"])
            if result.get("status") == "ok":
                try:
                    row = decode_row(result.get("stdout", ""))
                except Exception as error:
                    row = {
                        "status": "error",
                        "error": f"could not parse worker output: {error}",
                        "worker_stdout": result.get("stdout", "")[-4000:],
                    }
            else:
                row = dict(result)
            row.update(
                {
                    "target": target,
                    "method": method,
                    "mode": args.mode,
                    "scaling_factor": args.factor,
                    "scaling_value": int(value),
                }
            )
            rows.append(row)
write_records(rows, _bootstrap.EXP / f"results/scaling_{args.factor}_{args.mode}")
print(json.dumps(rows, indent=2, default=str))
