# Reproduction commands for the v5 primary protocol

The commands below were run from
`/data/apolarity_stde_runs_20260903_v5/web_experiments_20260903` on the T4
host, with a fresh process for each GPU method/case:

```text
export CUDA_VISIBLE_DEVICES=0
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export PYTHONPATH=$PWD/src
export PYTHONUNBUFFERED=1

/data/apolarity-stde-venv-20260903/bin/python -m pytest -q
/data/apolarity-stde-venv-20260903/bin/python scripts/write_provenance.py
/data/apolarity-stde-venv-20260903/bin/python scripts/run_accuracy.py
/data/apolarity-stde-venv-20260903/bin/python scripts/run_residual.py --operator kdv2d --mode value
/data/apolarity-stde-venv-20260903/bin/python scripts/run_residual.py --operator kdv2d --mode backward
/data/apolarity-stde-venv-20260903/bin/python scripts/run_residual.py --operator gkdv1d --mode value
/data/apolarity-stde-venv-20260903/bin/python scripts/run_residual.py --operator gkdv1d --mode backward
```

Representative high-order value probes were launched as follows:

```text
/data/apolarity-stde-venv-20260903/bin/python scripts/run_one.py --target u_11223344 --method rank_optimal --mode value --batch 100 --chunk all
/data/apolarity-stde-venv-20260903/bin/python scripts/run_one.py --target u_11223344 --method stde --mode value --batch 100 --chunk all
/data/apolarity-stde-venv-20260903/bin/python scripts/run_one.py --target u_111222333 --method rank_optimal --mode value --batch 100 --chunk all
/data/apolarity-stde-venv-20260903/bin/python scripts/run_one.py --target u_111222333 --method stde --mode value --batch 100 --chunk all
```

The nested-AD probe for `u_11223344` was bounded by a 120-second shell
timeout and is recorded as `timeout` rather than being replaced by a number.
The primary protocol does not use the optional `run_chunks.py` diagnostic.
