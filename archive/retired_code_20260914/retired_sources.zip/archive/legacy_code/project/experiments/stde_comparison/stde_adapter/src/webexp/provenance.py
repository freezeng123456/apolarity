from __future__ import annotations
import hashlib
import os
import platform
import shutil
import subprocess
from pathlib import Path


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def collect(root):
    import jax
    import numpy

    try:
        import jaxlib

        jaxlib_version = jaxlib.__version__
    except Exception:
        jaxlib_version = None
    stde_commit = "fae88663b1d2f1b0666d4d250c38a3c34b852ac0"
    root = Path(root)
    manifest = root / "SOURCE_MANIFEST.md"
    request = root / "WEB_MODEL_REQUEST.md"
    ptxas_path = None
    ptxas_version = None
    try:
        from jax._src import lib as jax_lib

        if jax_lib.cuda_path:
            candidate = Path(jax_lib.cuda_path) / "bin" / "ptxas"
            if candidate.exists():
                ptxas_path = str(candidate)
        if ptxas_path is None:
            ptxas_path = shutil.which("ptxas")
        if ptxas_path:
            completed = subprocess.run(
                [ptxas_path, "--version"],
                check=False,
                capture_output=True,
                text=True,
            )
            lines = (completed.stdout + completed.stderr).splitlines()
            ptxas_version = next(
                (line.strip() for line in lines if "release" in line.lower()),
                None,
            )
    except Exception:
        pass
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "jax": jax.__version__,
        "jaxlib": jaxlib_version,
        "numpy": numpy.__version__,
        "backend": jax.default_backend(),
        "devices": [str(x) for x in jax.devices()],
        "ptxas_path": ptxas_path,
        "ptxas_version": ptxas_version,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "xla_preallocate": os.environ.get("XLA_PYTHON_CLIENT_PREALLOCATE"),
        "stde_source_commit": stde_commit,
        "apolarity_source_note": "uploaded source tree; Git metadata intentionally excluded",
        "source_manifest_sha256": sha256(manifest) if manifest.exists() else None,
        "web_model_request_sha256": sha256(request) if request.exists() else None,
    }
