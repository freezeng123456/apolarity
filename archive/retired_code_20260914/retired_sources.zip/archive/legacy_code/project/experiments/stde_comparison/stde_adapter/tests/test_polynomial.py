import math
from collections import Counter
import numpy as np
import jax.numpy as jnp
from webexp.methods import METHODS


def poly(z, alpha):
    c = Counter(alpha)
    out = jnp.asarray(1.0, dtype=z.dtype)
    for i, a in c.items():
        out *= z[i] ** (a + 1)
    return out


def exact(z, alpha):
    c = Counter(alpha)
    out = 1.0
    for i, a in c.items():
        out *= math.factorial(a + 1) * float(z[i])
    return out


def test_high_order_polynomial_all_methods():
    z = jnp.linspace(0.1, 0.8, 16, dtype=jnp.float32)
    for alpha in [
        (0,) * 6,
        (0, 0, 1, 1, 2, 2),
        (0, 0, 1, 1, 2, 2, 3, 3),
        (0, 0, 0, 1, 1, 1, 2, 2, 2),
    ]:
        ref = exact(z, alpha)
        for name in ["rank_optimal", "stde"]:
            a = METHODS[name]
            got = a.derivative_one(lambda x: poly(x, alpha), z, alpha)
            np.testing.assert_allclose(float(jnp.real(got)), ref, rtol=3e-3, atol=3e-4)
