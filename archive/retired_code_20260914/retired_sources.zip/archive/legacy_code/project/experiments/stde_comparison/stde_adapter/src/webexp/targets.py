from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class Target:
    name: str
    alpha: tuple[int, ...]
    optional: bool = False


TARGETS = (
    Target("u_1", (0,)),
    Target("u_12", (0, 1)),
    Target("u_112", (0, 0, 1)),
    Target("pure4", (0, 0, 0, 0)),
    Target("u_1122", (0, 0, 1, 1)),
    Target("u_1234", (0, 1, 2, 3)),
    Target("pure6", (0,) * 6),
    Target("u_111222", (0, 0, 0, 1, 1, 1)),
    Target("u_112233", (0, 0, 1, 1, 2, 2)),
    Target("u_123456", tuple(range(6))),
    Target("u_11223344", (0, 0, 1, 1, 2, 2, 3, 3)),
    Target("u_111222333", (0, 0, 0, 1, 1, 1, 2, 2, 2)),
    Target("pure8", (0,) * 8),
    Target("pure9", (0,) * 9),
    Target("u_11112222", (0, 0, 0, 0, 1, 1, 1, 1), True),
)
TARGET_MAP = {t.name: t for t in TARGETS}
FLAGSHIP = ("u_11223344", "u_111222333")
SCALING_TARGETS = ("u_12", "pure6", "u_11223344", "u_111222333")


def exponent_pattern(alpha):
    return tuple(sorted(Counter(alpha).values(), reverse=True))


def alpha_factorial(alpha):
    return math.prod(math.factorial(v) for v in Counter(alpha).values())


def theoretical_rank(alpha):
    exps = sorted(Counter(alpha).values())
    return math.prod(e + 1 for e in exps[1:]) if exps else 0
