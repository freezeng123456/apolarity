#!/usr/bin/env python3
import _bootstrap
import json
import shutil
from webexp.provenance import collect

p = _bootstrap.EXP / "results/provenance.json"
p.parent.mkdir(exist_ok=True)
p.write_text(json.dumps(collect(_bootstrap.ROOT), indent=2))
shutil.copy2(
    _bootstrap.EXP / "configs/main.yaml", _bootstrap.EXP / "results/frozen_config.yaml"
)
print(p)
