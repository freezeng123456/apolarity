from pathlib import Path
import os
import sys

HERE = Path(__file__).resolve()
EXP = HERE.parents[1]
ROOT = EXP
# Avoid process-wide device preallocation when several fresh benchmark
# processes are launched on the same GPU.
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
sys.path.insert(0, str(EXP / "src"))
