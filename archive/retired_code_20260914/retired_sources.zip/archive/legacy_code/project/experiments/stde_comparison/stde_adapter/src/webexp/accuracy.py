from __future__ import annotations
import numpy as np
from .fixtures import numpy_fixture, to_jax, mlp_one
from .methods import METHODS
from .metrics import errors, flatten_tree
from .schedules import coefficient_residual
from .targets import TARGETS


def analytic_polynomial(point, alpha):
    import jax.numpy as jnp

    # Product x_i^(a_i+1): derivative has a simple independent analytic value.
    from collections import Counter

    c = Counter(alpha)
    y = jnp.asarray(1.0, dtype=point.dtype)
    for i, a in c.items():
        y = y * point[i] ** (a + 1)
    return y


def analytic_polynomial_derivative(points, alpha):
    from collections import Counter
    import math

    c = Counter(alpha)
    out = []
    for x in np.asarray(points):
        y = 1.0
        for i, a in c.items():
            y *= math.factorial(a + 1) * x[i]
        out.append(y)
    return np.asarray(out)


def run(cfg, include_optional=False):
    import jax
    import jax.numpy as jnp

    # Configure the reference precision before constructing any JAX values.
    # This keeps the independent network check genuinely float64.
    jax.config.update("jax_enable_x64", True)
    records = []
    for t in TARGETS:
        if t.optional and not include_optional:
            continue
        # cheap polynomial coefficient identity, all targets
        pts = np.linspace(0.13, 0.37, cfg["input_dim"], dtype=np.float32)[None, :]
        ref = analytic_polynomial_derivative(pts, t.alpha)
        for name, adapter in METHODS.items():
            if name == "nested_ad" and len(t.alpha) > 4:
                records.append(
                    {
                        "kind": "polynomial",
                        "method": name,
                        "target": t.name,
                        "status": "skipped",
                        "reason": "nested reverse-mode control is limited to order <= 4",
                    }
                )
                continue
            try:
                p = jnp.asarray(pts[0])
                got = adapter.derivative_one(
                    lambda z: analytic_polynomial(z, t.alpha), p, t.alpha
                )
                rec = {
                    "kind": "polynomial",
                    "method": name,
                    "target": t.name,
                    **errors(np.asarray([got]), ref),
                    "status": "ok",
                }
                if hasattr(adapter, "schedule"):
                    rec["coefficient_residual"] = coefficient_residual(
                        adapter.schedule(t.alpha, cfg["input_dim"]), t.alpha
                    )
                records.append(rec)
            except Exception as e:
                records.append(
                    {
                        "kind": "polynomial",
                        "method": name,
                        "target": t.name,
                        "status": "error",
                        "error": repr(e),
                    }
                )
    # Small-network independent nested float64 reference for tractable controls.
    for t in [x for x in TARGETS if len(x.alpha) <= 4]:
        pnp, xnp = numpy_fixture(cfg["seed"], cfg["input_dim"], 12, 2, 3, np.float64)
        params, x = to_jax(pnp, xnp, jnp.float64)
        ref_adapter = METHODS["nested_ad"]
        ref = jax.vmap(
            lambda pt: ref_adapter.derivative_one(
                lambda z: mlp_one(params, z), pt, t.alpha
            )
        )(x)

        def refloss(prm):
            v = jax.vmap(
                lambda pt: ref_adapter.derivative_one(
                    lambda z: mlp_one(prm, z), pt, t.alpha
                )
            )(x)
            return jnp.mean(v**2)

        refg = jax.grad(refloss)(params)
        refgf = flatten_tree(refg)
        for name, adapter in METHODS.items():
            val = jax.vmap(
                lambda pt: adapter.derivative_one(
                    lambda z: mlp_one(params, z), pt, t.alpha
                )
            )(x)

            def loss(prm):
                v = jax.vmap(
                    lambda pt: adapter.derivative_one(
                        lambda z: mlp_one(prm, z), pt, t.alpha
                    )
                )(x)
                return jnp.mean(jnp.real(v) ** 2)

            g = jax.grad(loss)(params)
            records.append(
                {
                    "kind": "network64",
                    "method": name,
                    "target": t.name,
                    "status": "ok",
                    **{
                        f"value_{k}": v
                        for k, v in errors(np.asarray(val), np.asarray(ref)).items()
                    },
                    **{
                        f"grad_{k}": v
                        for k, v in errors(flatten_tree(g), refgf).items()
                    },
                }
            )
    return records
