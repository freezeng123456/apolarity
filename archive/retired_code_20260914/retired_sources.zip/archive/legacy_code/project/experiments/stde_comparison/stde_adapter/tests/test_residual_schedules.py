from webexp.residuals import schedule_summary


def test_official_stde_schedule_metadata():
    a = schedule_summary("stde", "kdv2d")
    assert a["distinct_jets"] == 3 and a["max_jet_order"] == 9
    b = schedule_summary("stde", "gkdv1d")
    assert b["distinct_jets"] == 3 and b["max_jet_order"] == 7


def test_rank_schedule_dedup_summary():
    a = schedule_summary("rank_optimal", "kdv2d")
    assert a["distinct_jets"] > 0 and a["max_jet_order"] == 4


def test_official_kdv_case3_matches_nested():
    import jax

    jax.config.update("jax_enable_x64", True)
    import jax.numpy as jnp
    from webexp.residuals import stde_official_kdv2d_case3, kdv2d_generic

    p = jnp.array([0.2, 0.3, 0.4], dtype=jnp.float64)

    def f(z):
        return z[0] ** 4 * z[1] + z[1] * z[2] + z[0] ** 2 + z[1] ** 3 + z[0] * z[1]

    a = stde_official_kdv2d_case3(f, p)
    b = kdv2d_generic("nested_ad", f, p)
    assert float(jnp.abs(a - b)) < 1e-9
