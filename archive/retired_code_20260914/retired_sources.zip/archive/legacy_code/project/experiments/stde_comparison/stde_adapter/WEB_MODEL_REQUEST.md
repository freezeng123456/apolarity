# Web-model request record

The web model was asked to write a reproducible JAX experiment harness for a
three-way comparison: the rank-optimal apolarity method, the original STDE
method, and a nested automatic-differentiation baseline. The requested
benchmarks cover derivative accuracy, value and parameter-gradient timing,
direction/jet scaling, memory, and representative KdV/g-KdV residuals on a
single Tesla T4. Randomized variants and an unvalidated PINN-training study
were excluded from the primary protocol.

This record is a concise provenance note; it does not contain credentials,
browser state, or hidden prompts.
