#!/usr/bin/env python3
import _bootstrap
import argparse
import json
from webexp.config import load
from webexp.benchmark import run_case
from webexp.io import write_records

p = argparse.ArgumentParser()
p.add_argument("--target", default="u_11223344")
p.add_argument("--method", choices=["rank_optimal", "stde", "nested_ad"])
p.add_argument("--mode", choices=["value", "backward"], default="value")
p.add_argument("--chunk", default="all")
a = p.parse_args()
cfg = load(_bootstrap.EXP / "configs/main.yaml")
ms = [a.method] if a.method else cfg["methods"]
chunk = a.chunk if a.chunk == "all" else int(a.chunk)
rows = [run_case(m, a.target, cfg, a.mode, chunk_size=chunk) for m in ms]
write_records(rows, _bootstrap.EXP / f"results/timing_{a.target}_{a.mode}_{a.chunk}")
print(json.dumps(rows, indent=2, default=str))
