#!/usr/bin/env python3
import _bootstrap
from webexp.config import load
from webexp.benchmark import run_case
from webexp.io import write_records

cfg = load(_bootstrap.EXP / "configs/main.yaml")
cfg = {
    **cfg,
    "network": {**cfg["network"], "depth": 2, "width": 8},
    "batch_size": 2,
    "warmups": 0,
    "repeats": 1,
}
rows = []
for target in ["u_1", "u_12", "u_112", "pure4"]:
    for method in cfg["methods"]:
        rows.append(run_case(method, target, cfg))
write_records(rows, _bootstrap.EXP / "results/smoke")
print("smoke ok:", len(rows), "cases")
