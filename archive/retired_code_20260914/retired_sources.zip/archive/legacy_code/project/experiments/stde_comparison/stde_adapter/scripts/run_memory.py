#!/usr/bin/env python3
"""Fresh-process memory/timing launcher. GPU peaks use JAX device memory_stats when exposed.
For T4 production runs, launch each case separately; OOM/timeout are recorded, not retried with altered budgets.
"""

import _bootstrap
import argparse
import json
import sys
from webexp.config import load
from webexp.runner import run_with_timeout
from webexp.io import write_records

p = argparse.ArgumentParser()
p.add_argument("--target", default="u_11223344")
p.add_argument("--mode", choices=["value", "backward"], default="backward")
a = p.parse_args()
cfg = load(_bootstrap.EXP / "configs/main.yaml")
rows = []
for m in cfg["methods"]:
    cmd = [
        sys.executable,
        str(_bootstrap.EXP / "scripts/run_timing.py"),
        "--target",
        a.target,
        "--method",
        m,
        "--mode",
        a.mode,
    ]
    r = run_with_timeout(cmd, cfg["compile_timeout_seconds"])
    if r.get("status") == "ok":
        try:
            payload = json.loads(r.get("stdout", ""))
            rec = payload[0] if isinstance(payload, list) else payload
            rows.append({**rec, "fresh_process_status": "ok"})
        except Exception as e:
            rows.append(
                {
                    "method": m,
                    "target": a.target,
                    "mode": a.mode,
                    "status": "error",
                    "error": f"could not parse worker output: {e}",
                    "worker_stdout": r.get("stdout", "")[-2000:],
                }
            )
    else:
        rows.append({"method": m, "target": a.target, "mode": a.mode, **r})
write_records(rows, _bootstrap.EXP / f"results/memory_process_{a.target}_{a.mode}")
print(json.dumps(rows, indent=2))
