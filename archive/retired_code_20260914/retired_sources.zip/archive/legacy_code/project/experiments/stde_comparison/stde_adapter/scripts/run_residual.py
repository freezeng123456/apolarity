#!/usr/bin/env python3
"""Launch each residual/method cell in an isolated worker process."""

import argparse
import json
import sys

import _bootstrap
from webexp.config import load
from webexp.io import write_records
from webexp.runner import run_with_timeout


def decode_rows(stdout):
    for line in reversed(stdout.splitlines()):
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, list):
            return value
    raise ValueError("worker did not emit a JSON list")


parser = argparse.ArgumentParser()
parser.add_argument("--operator", choices=["kdv2d", "gkdv1d"], default="kdv2d")
parser.add_argument("--mode", choices=["value", "backward"], default="value")
args = parser.parse_args()
cfg = load(_bootstrap.EXP / "configs/main.yaml")
worker = _bootstrap.EXP / "scripts/run_residual_one.py"
rows = []
for method in cfg["methods"]:
    command = [
        sys.executable,
        str(worker),
        "--operator",
        args.operator,
        "--method",
        method,
        "--mode",
        args.mode,
    ]
    result = run_with_timeout(command, cfg["compile_timeout_seconds"])
    if result.get("status") == "ok":
        try:
            worker_rows = decode_rows(result.get("stdout", ""))
            rows.extend(worker_rows)
        except Exception as error:
            rows.append(
                {
                    "status": "error",
                    "operator": args.operator,
                    "method": method,
                    "mode": args.mode,
                    "error": f"could not parse worker output: {error}",
                    "worker_stdout": result.get("stdout", "")[-4000:],
                }
            )
    else:
        rows.append(
            {
                "operator": args.operator,
                "method": method,
                "mode": args.mode,
                **result,
            }
        )
write_records(rows, _bootstrap.EXP / f"results/residual_{args.operator}_{args.mode}")
print(json.dumps(rows, indent=2, default=str))
