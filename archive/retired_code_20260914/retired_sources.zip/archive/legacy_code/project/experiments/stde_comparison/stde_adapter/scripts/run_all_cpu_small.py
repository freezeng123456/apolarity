#!/usr/bin/env python3
"""Run the small validation suite with bounded fresh subprocesses."""

import json
import sys

import _bootstrap
from webexp.config import load
from webexp.runner import run_with_timeout


cfg = load(_bootstrap.EXP / "configs/main.yaml")
for script in ["run_smoke.py", "run_accuracy.py", "write_provenance.py"]:
    result = run_with_timeout(
        [sys.executable, str(_bootstrap.EXP / "scripts" / script)],
        cfg["compile_timeout_seconds"],
    )
    print(json.dumps({"script": script, **result}, default=str))
    if result.get("status") != "ok":
        raise SystemExit(f"{script} failed with status {result.get('status')}")
