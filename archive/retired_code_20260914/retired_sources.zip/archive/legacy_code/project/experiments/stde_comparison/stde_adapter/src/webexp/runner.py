from __future__ import annotations
import subprocess


def run_with_timeout(cmd, timeout):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if p.returncode != 0:
            text = (p.stderr or p.stdout).lower()
            status = (
                "oom"
                if ("out of memory" in text or "resource exhausted" in text)
                else "error"
            )
            return {
                "status": status,
                "returncode": p.returncode,
                "stderr": p.stderr[-4000:],
                "stdout": p.stdout[-4000:],
            }
        return {"status": "ok", "stdout": p.stdout, "stderr": p.stderr}
    except subprocess.TimeoutExpired as e:
        return {
            "status": "timeout",
            "timeout_seconds": timeout,
            "stdout": (e.stdout or "")[-4000:] if isinstance(e.stdout, str) else "",
            "stderr": (e.stderr or "")[-4000:] if isinstance(e.stderr, str) else "",
        }
