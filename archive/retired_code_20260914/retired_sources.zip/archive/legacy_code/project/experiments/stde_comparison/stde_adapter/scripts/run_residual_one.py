#!/usr/bin/env python3
"""Run one residual/method case in a fresh process."""

import argparse
import json

import _bootstrap
from webexp.config import load
from webexp.residual_benchmark import run


parser = argparse.ArgumentParser()
parser.add_argument("--operator", choices=["kdv2d", "gkdv1d"], required=True)
parser.add_argument(
    "--method", choices=["rank_optimal", "stde", "nested_ad"], required=True
)
parser.add_argument("--mode", choices=["value", "backward"], default="value")
args = parser.parse_args()

cfg = load(_bootstrap.EXP / "configs/main.yaml")
print(
    json.dumps(run(cfg, args.operator, args.mode, methods=[args.method]), default=str)
)
