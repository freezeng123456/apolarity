# Source audit notes

The uploaded apolarity and STDE trees are read-only inputs. No source file
under `apolarity/`, `stde/`, `comparison/`, or `paper/` was edited.

## Method identity

The primary suite has three entries only: the apolarity rank-optimal method,
the original STDE method, and nested AD. The previous grouped multiple-linear-
jet implementation was removed from the STDE adapter because it is not the
original STDE baseline. No randomized estimator is used in the deterministic
STDE control.

For arbitrary monomial targets, the adapter follows the original STDE paper's
two deterministic options: choose sparse Taylor positions whose target
partition is unique, or use several deterministic pushforwards and solve the
finite coefficient system when extra partitions remain. The coefficient
system is checked independently before a target is used in a benchmark.

## Official residual schedules

The 2-D KdV residual uses the deterministic case-3 schedule in the official
original-STDE implementation: one 9-jet and two 3-jets. The mixed ninth-order
coefficient is divided by 1260, the Faà di Bruno factor for the partition
`9=2+2+2+3`; the upstream code's 840 is not used. The 1-D g-KdV/gPINN
residual uses the official case-4 schedule: two 7-jets and one t-only 2-jet.
These adapters are separate from the generic monomial schedule and preserve
the original-STDE schedule shapes without editing the pinned upstream tree.

## Precision and validation

The primary configuration is float32 for real paths and complex64 only for the
rank-optimal roots-of-unity directions. Float64 nested AD is used only for
tractable independent network references. The analytic polynomial fixtures
are independent of both Taylor-jet implementations. The JAX wrapper requests
factorial scaling explicitly on releases that expose the keyword and falls
back to the documented factorial-scaled behavior of the pinned JAX 0.4.x API.

The deterministic multi-jet STDE fallback can be numerically ill-conditioned;
its coefficient residual is reported and tested rather than hidden. This is a
property of the deterministic interpolation control and should be discussed
alongside its timings if it appears in the final paper.

## Batch and chunking protocol

The primary batch size is 100, matching the official STDE `EqnConfig` default
and the `insep.sh` entry point used for the high-order example. The original
STDE code does not expose direction chunking for these deterministic Taylor
jets; its `block_size` option concerns network weight sharing. Accordingly,
primary runs pass `chunk_size="all"`. The adapter retains an explicit chunk
argument only for a separate memory diagnostic, and any such rows are labelled
as exploratory rather than used as the STDE setting.

The T4 JAX environment uses `nvidia-cuda-nvcc-cu12==12.2.140`, so the
compiler `ptxas` release is compatible with the host driver. The provenance
writer records both the compiler path and its reported release.

## Unrun GPU work

This review container exposes no JAX installation and no T4 device. No GPU
timing, peak-memory, OOM, scaling, or residual result is pre-populated. The
fresh-process launchers record `timeout`, `oom`, or `error` rather than
substituting a numeric result.
