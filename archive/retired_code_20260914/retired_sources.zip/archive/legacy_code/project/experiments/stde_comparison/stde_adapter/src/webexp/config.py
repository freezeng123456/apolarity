from pathlib import Path
import yaml


ALLOWED_METHODS = ("rank_optimal", "stde", "nested_ad")


def load(path):
    cfg = yaml.safe_load(Path(path).read_text())
    methods = tuple(cfg.get("methods", ()))
    unknown = sorted(set(methods) - set(ALLOWED_METHODS))
    if unknown:
        raise ValueError(
            "unsupported method(s): "
            + ", ".join(unknown)
            + "; allowed methods are "
            + ", ".join(ALLOWED_METHODS)
        )
    return cfg
