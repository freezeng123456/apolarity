# Isolated STDE comparison archive

This directory contains the earlier experiment harness that was developed
from the public STDE project and the corresponding T4 comparison records. It
is retained for provenance and reproducibility, but it is not part of the
mainline `apolarity` implementation or the numerical comparison reported in
the manuscript.

The mainline benchmark now compares exactly two methods:

- `nested_ad`, the direct nested automatic-differentiation control;
- `rank_optimal`, the Waring-rank directional Taylor-jet method.

The isolated harness under `stde_adapter/` contains the deterministic STDE
control together with the two methods above. The original STDE source itself
is kept separately under `reference/stde_upstream/`. The directory
`results/t4_results_v5/` preserves the earlier T4 records, including their
frozen configuration, provenance, accuracy checks, and timing outputs. Those
records must not be mixed with the current two-method tables.

The adapter is deliberately self-contained and does not modify either the
upstream STDE tree or the mainline source package. Its documentation records
the upstream commit, schedule choices, precision, and known limitations.
