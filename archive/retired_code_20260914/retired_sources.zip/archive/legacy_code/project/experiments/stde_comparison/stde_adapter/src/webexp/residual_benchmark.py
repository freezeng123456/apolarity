from __future__ import annotations
import time
import statistics
import numpy as np
from .fixtures import numpy_fixture, to_jax, mlp_one
from .residuals import (
    kdv2d_generic,
    gkdv1d_generic,
    stde_official_kdv2d_case3,
    stde_official_gkdv_7jet,
    schedule_summary,
)


def run(cfg, operator="kdv2d", mode="value", methods=None):
    import jax
    import jax.numpy as jnp

    d = 3 if operator == "kdv2d" else 2
    pnp, xnp = numpy_fixture(
        cfg["seed"],
        d,
        cfg["network"]["width"],
        cfg["network"]["depth"],
        cfg["batch_size"],
        np.float32,
    )
    params, x = to_jax(pnp, xnp, jnp.float32)
    run_meta = {
        "seed": cfg["seed"],
        "dtype": cfg["dtype"],
        "depth": cfg["network"]["depth"],
        "width": cfg["network"]["width"],
        "batch": cfg["batch_size"],
        "device": str(jax.devices()[0]),
    }
    out = []
    for method in cfg["methods"] if methods is None else methods:

        def one(prm, pt):
            def f(z):
                return mlp_one(prm, z)

            if method == "stde":
                return (
                    stde_official_kdv2d_case3(f, pt)
                    if operator == "kdv2d"
                    else jnp.asarray(stde_official_gkdv_7jet(f, pt))
                )
            return (
                kdv2d_generic(method, f, pt)
                if operator == "kdv2d"
                else jnp.asarray(gkdv1d_generic(method, f, pt))
            )

        vf = jax.jit(jax.vmap(one, in_axes=(None, 0)))
        if mode == "value":

            def fn(prm):
                return vf(prm, x)
        else:

            def loss(prm):
                return jnp.mean(jnp.real(vf(prm, x)) ** 2)

            fn = jax.jit(jax.grad(loss))

        def sync(v):
            for a in jax.tree_util.tree_leaves(v):
                a.block_until_ready()

        try:
            s = time.perf_counter()
            z = fn(params)
            sync(z)
            first = time.perf_counter() - s
            for _ in range(cfg["warmups"]):
                sync(fn(params))
            ts = []
            for _ in range(cfg["repeats"]):
                s = time.perf_counter()
                z = fn(params)
                sync(z)
                ts.append((time.perf_counter() - s) * 1000)
            out.append(
                {
                    "status": "ok",
                    "operator": operator,
                    "method": method,
                    "mode": mode,
                    "compile_plus_first_call_s": first,
                    "steady_median_ms": statistics.median(ts),
                    **run_meta,
                    **schedule_summary(method, operator),
                }
            )
        except Exception as e:
            out.append(
                {
                    "status": "error",
                    "operator": operator,
                    "method": method,
                    "mode": mode,
                    "error": repr(e),
                    **run_meta,
                    **schedule_summary(method, operator),
                }
            )
    return out
