from __future__ import annotations
import os
import time
import statistics
import numpy as np
from .fixtures import numpy_fixture, to_jax, mlp_one
from .methods import METHODS
from .targets import TARGET_MAP, exponent_pattern, theoretical_rank


def _sync(x):
    import jax

    for y in jax.tree_util.tree_leaves(x):
        y.block_until_ready()


def run_case(
    method,
    target_name,
    cfg,
    mode="value",
    depth=None,
    width=None,
    batch=None,
    chunk_size=None,
):
    os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
    import jax
    import jax.numpy as jnp

    dtype = jnp.float32 if cfg["dtype"] == "float32" else jnp.float64
    t = TARGET_MAP[target_name]
    depth = depth or cfg["network"]["depth"]
    width = width or cfg["network"]["width"]
    batch = batch or cfg["batch_size"]
    pnp, xnp = numpy_fixture(
        cfg["seed"],
        cfg["input_dim"],
        width,
        depth,
        batch,
        np.float32 if dtype == jnp.float32 else np.float64,
    )
    params, x = to_jax(pnp, xnp, dtype)
    adapter = METHODS[method]

    def one(prm, pt):
        return adapter.derivative_one(
            lambda z: mlp_one(prm, z), pt, t.alpha, chunk_size
        )

    vals = jax.jit(jax.vmap(one, in_axes=(None, 0)))
    if mode == "value":

        def fn(prm):
            return vals(prm, x)
    else:

        def loss(prm):
            v = vals(prm, x)
            return jnp.mean(jnp.real(v) ** 2)

        fn = jax.jit(jax.grad(loss))
    start = time.perf_counter()
    first = fn(params)
    _sync(first)
    first_s = time.perf_counter() - start
    for _ in range(cfg["warmups"]):
        _sync(fn(params))
    samples = []
    last = None
    for _ in range(cfg["repeats"]):
        s = time.perf_counter()
        last = fn(params)
        _sync(last)
        samples.append((time.perf_counter() - s) * 1000)
    raw = vals(params, x)
    _sync(raw)
    arr = np.asarray(raw)
    mem = jax.devices()[0].memory_stats() or {}
    schedule_count = schedule_order = schedule_construction = None
    if hasattr(adapter, "schedule"):
        schedule = adapter.schedule(t.alpha, cfg["input_dim"])
        schedule_count = len(schedule.weights)
        schedule_order = schedule.order
        schedule_construction = schedule.construction
    return {
        "status": "ok",
        "method": method,
        "target": target_name,
        "mode": mode,
        "dtype": cfg["dtype"],
        "order": len(t.alpha),
        "exponent_pattern": str(exponent_pattern(t.alpha)),
        "active_coordinates": len(set(t.alpha)),
        "theoretical_rank": theoretical_rank(t.alpha),
        "actual_distinct_jets": schedule_count,
        "schedule_jet_order": schedule_order,
        "schedule_construction": schedule_construction,
        "depth": depth,
        "width": width,
        "batch": batch,
        "chunk_size": str(chunk_size or "all"),
        "compile_plus_first_call_s": first_s,
        "steady_median_ms": statistics.median(samples),
        "steady_samples_ms": samples,
        "max_abs_imaginary": float(np.max(np.abs(np.imag(arr)))),
        "peak_bytes_in_use": mem.get("peak_bytes_in_use"),
        "device": str(jax.devices()[0]),
    }
