from __future__ import annotations
import numpy as np
from ..schedules import waring_roots_of_unity
from .common import taylor_coeff


def schedule(alpha, d):
    return waring_roots_of_unity(tuple(alpha), d)


def derivative_one(fun, point, alpha, chunk_size=None):
    import jax
    import jax.numpy as jnp

    s = schedule(alpha, point.shape[0])
    need_complex = np.max(np.abs(s.directions.imag)) > 1e-14
    if need_complex:
        cd = jnp.complex128 if point.dtype == jnp.float64 else jnp.complex64
        dirs = jnp.asarray(s.directions, dtype=cd)
        weights = jnp.asarray(s.weights, dtype=cd)
        p = point.astype(cd)
    else:
        dirs = jnp.asarray(s.directions.real, dtype=point.dtype)
        weights = jnp.asarray(s.weights.real, dtype=point.dtype)
        p = point
    n = dirs.shape[0]
    chunk = n if chunk_size in (None, "all") else int(chunk_size)

    def eval_slice(ds):
        return jax.vmap(lambda v: taylor_coeff(fun, p, v, len(alpha)))(ds)

    if chunk >= n:
        return jnp.sum(weights * eval_slice(dirs))
    total = jnp.asarray(0, dtype=weights.dtype)
    for i in range(0, n, chunk):
        total = total + jnp.sum(
            weights[i : i + chunk] * eval_slice(dirs[i : i + chunk])
        )
    return total
