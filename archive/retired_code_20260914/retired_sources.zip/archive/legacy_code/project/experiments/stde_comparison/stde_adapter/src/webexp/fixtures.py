from __future__ import annotations
import math
import numpy as np


def numpy_fixture(
    seed: int, input_dim: int, width: int, depth: int, batch: int, dtype=np.float32
):
    rng = np.random.default_rng(seed)
    dims = [input_dim] + [width] * depth + [1]
    params = []
    for fi, fo in zip(dims[:-1], dims[1:]):
        scale = math.sqrt(2.0 / (fi + fo))
        params.append(
            (
                (rng.standard_normal((fo, fi)) * scale).astype(dtype),
                (rng.standard_normal((fo,)) * 0.05).astype(dtype),
            )
        )
    x = (rng.standard_normal((batch, input_dim)) * 0.35).astype(dtype)
    return tuple(params), x


def to_jax(params_np, x_np, dtype):
    import jax.numpy as jnp

    return tuple(
        (jnp.asarray(w, dtype=dtype), jnp.asarray(b, dtype=dtype)) for w, b in params_np
    ), jnp.asarray(x_np, dtype=dtype)


def mlp_one(params, x):
    import jax.numpy as jnp

    y = x
    for i, (w, b) in enumerate(params):
        y = w @ y + b
        if i + 1 < len(params):
            y = jnp.tanh(y)
    return y[0]
