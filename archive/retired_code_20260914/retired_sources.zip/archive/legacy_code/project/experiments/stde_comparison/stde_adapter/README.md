# Reproducible JAX experiment suite

This directory is a reviewable experiment harness. It does **not** edit the
uploaded apolarity or STDE source trees. The primary comparison contains
exactly three methods:

* `rank_optimal`: the roots-of-unity Waring-rank construction implemented with
  complex Taylor jets;
* `stde`: a deterministic, non-randomized realization of the original STDE
  sparse-jet construction. When the target partition is unique, one sparse
  high-order jet is used. Otherwise the original STDE multi-pushforward idea
  is instantiated as a deterministic coefficient solve over a finite set of
  jets;
* `nested_ad`: repeated coordinate-wise reverse-mode differentiation.

Randomized estimators, grouped-polarization variants, PyTorch, and an
unvalidated PINN-training study are outside this primary comparison. Thus the
second method is the original STDE baseline only; no STDE++ method is being
benchmarked.

## Frozen primary protocol

`configs/main.yaml` fixes seed `20260903`, `float32` real arithmetic
(`complex64` only when rank-optimal directions genuinely require complex
roots), `d=16`, a four-hidden-layer width-128 tanh MLP, batch 100, five
warmups, ten steady-state repeats, and a 300 s fresh-process timeout. The
batch size follows the official STDE `EqnConfig` default and its high-order
`insep.sh` entry point. The primary protocol evaluates STDE without direction
chunking; the optional `--chunk` argument is reserved for a separately
labelled memory diagnostic. A configurable dtype remains available for
validation, but the main table is float32. Compilation-plus-first-call time
is reported separately from the steady-state median. GPU OOM and the fixed
timeout are statuses, not numeric values.

## CPU smoke and validation

From this directory:

```bash
python scripts/run_smoke.py
pytest -q
python scripts/run_accuracy.py
python scripts/write_provenance.py
```

The smoke configuration overrides only size/repetition locally (2x8 network,
batch 2). The tests check the full coefficient identity for the rank-optimal
and deterministic STDE schedules. `run_accuracy.py` checks analytic polynomial
derivatives for the full target taxonomy and compares values and parameter
gradients against an independent float64 nested-AD reference on tractable
low-order controls. High-order nested-AD rows are recorded as explicit skips
when the configured control is intentionally intractable.

## T4 / single-GPU runs

Use one idle T4 and a fresh process per method/case. Recommended environment:

```bash
export CUDA_VISIBLE_DEVICES=0
export XLA_PYTHON_CLIENT_PREALLOCATE=false
```

Examples:

```bash
python scripts/run_timing.py --target u_11223344 --method rank_optimal --mode value
python scripts/run_timing.py --target u_11223344 --method stde --mode backward
python scripts/run_memory.py --target u_111222333 --mode backward
python scripts/run_chunks.py
python scripts/run_scaling.py --factor depth --mode value
python scripts/run_scaling.py --factor width --mode backward
python scripts/run_scaling.py --factor batch --mode value
python scripts/run_residual.py --operator kdv2d --mode value
python scripts/run_residual.py --operator kdv2d --mode backward
python scripts/run_residual.py --operator gkdv1d --mode value
python scripts/run_residual.py --operator gkdv1d --mode backward
```

The primary flagship comparison uses the unchunked (`all`) STDE schedule, in
accordance with the original implementation. A separate chunk diagnostic may
be launched explicitly when studying a T4 memory limit, but those rows must
not be mixed into the unchunked primary table. Width 1024 remains in the
requested scaling list; if it exceeds the fixed GPU memory budget, preserve
the OOM record instead of silently shrinking the case. Each scaling and
residual case is run in an isolated worker process, so a timeout or OOM cannot
poison later cases.

## Targets and schedule metadata

The monomial sweep includes `u_1`, `u_12`, `u_112`, pure orders 4 and 6,
`u_1122`, square-free `u_1234`, `u_111222`, `u_112233`, square-free
`u_123456`, `u_11223344`, `u_111222333`, pure orders 8 and 9, with
`u_11112222` optional. Every row records the target order, exponent pattern,
active-coordinate count, theoretical complex Waring rank, the number of
evaluated jets, the STDE jet order when applicable, and the schedule
construction. The two high-order flagship targets are retained specifically
to expose the different scaling of the rank-optimal and original-STDE
constructions.

For operator residuals, the STDE adapter follows the official original-STDE
Korteweg--de Vries schedules from `stde/stde/equations.py`: the deterministic
2-D KdV case uses one 9-jet and two 3-jets, while the 1-D g-KdV/gPINN case
uses two 7-jets plus one t-only 2-jet. Generic residual evaluation is
termwise for all methods; no claim of a globally optimal schedule for a sum of
operators is made.

## Taylor-jet and coefficient conventions

All method adapters use expanded zero-based multi-indices. The JAX wrapper
passes `factorial_scaled=True` where that keyword is available and uses the
same factorial-scaled convention of the pinned JAX 0.4.x API otherwise. Thus
an ordinary linear order-`p` jet returns the order-`p` directional derivative
and the rank-optimal adapter divides by `p!` before applying its normalized
directional weights. Sparse STDE jets use the factorial-scaled input tangent
terms prescribed by the original jet construction, with the corresponding
Faà di Bruno coefficient system solved once and cached for each target.

`tests/test_schedules.py` evaluates all weighted monomial coefficients in the
finite jet support, not only the target monomial. A residual above tolerance
is a validation failure, not a silently accepted benchmark result.

## Outputs and provenance

Result files are created only by scripts that actually ran; this package does
not ship pre-filled benchmark tables. Every result writer emits JSON and CSV.
`scripts/write_provenance.py` records Python/JAX/JAXLIB versions, backend and
devices, the official STDE source commit, environment controls, and hashes of
`SOURCE_MANIFEST.md` and `WEB_MODEL_REQUEST.md`, together with a frozen copy of
the configuration. It also records the `ptxas` path and reported CUDA release
used by the JAX compiler.

GPU peak memory depends on whether the installed JAX backend exposes
`memory_stats()`. For publication-grade T4 measurements, retain the isolated
process records and supplement allocator peaks with a process-level GPU
sampler if required by the machine environment. No T4 timing, memory, OOM, or
scaling result is asserted until the corresponding fresh-process run has
completed.
