from __future__ import annotations
import csv
import json
from pathlib import Path


def write_records(records, outbase):
    p = Path(outbase)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.with_suffix(".json").write_text(
        json.dumps(records, indent=2, sort_keys=True, default=str)
    )
    rows = records if isinstance(records, list) else [records]
    if rows:
        keys = sorted(set().union(*(r.keys() for r in rows)))
        with p.with_suffix(".csv").open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(rows)
