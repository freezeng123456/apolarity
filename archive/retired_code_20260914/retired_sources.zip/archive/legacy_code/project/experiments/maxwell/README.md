# Time-harmonic Maxwell, lossy medium (complex-valued)

**Problem.** TM-mode reduction to a complex Helmholtz equation
\(\Delta E + \kappa^2 E = f\) on \((-1,1)^2\), \(\kappa^2=(a\pi)^2(1+i\beta)\),
\(\beta=0.2\) (loss tangent → complex permittivity → genuinely complex \(E\)).
Manufactured plane wave \(E=e^{i a\pi(x+y)}\), Dirichlet \(=E_\star\). Real baselines
use a split-real (Re/Im) pair (RVPINN).

**Source.** Jiang 2024 (lossy TM variant).

**Sweep.** wavenumber \(a\in\{2,4,6\}\). Init \(\omega_0=\max(10,2\pi a)\),
\(\sigma=\max(2,\pi a)\).

## Formal comparison

The three sweep values are formal `jsc_v3` settings with frozen
`pow10_reasonable_v1` scalar weights in `experiments/common/boundary_weights.py`.
The only formal methods are `complex_sinh` and `complex_sinh_autodiff`: the
same native-complex network is run once with the jet backend and once with
direct nested coordinate autodiff. Both use literal hidden width \(H=128\) and
the same wall-clock budget.

## Current outputs

`data/` is empty. The completed fixed-`bc_weight=100` `jsc_v2` bundle is kept as
historical evidence under `experiments/results/jsc_v2/`; no `jsc_v3` Maxwell
result has been launched yet, so the new Maxwell paper figure and table are
**TBD**.

## Launch one formal setting

```bash
bash scripts/run_jsc_main3.sh maxwell --sweep 4
python scripts/validate_jsc_results.py \
  experiments/results/jsc_v3/maxwell_a4
```

Choose exactly one allowed `--sweep` value per launch. The family-local
`run.sh`, historical completion/merge scripts, and archived runners are
implementation diagnostics only; their outputs cannot be used as paper
evidence.
