#!/usr/bin/env bash
set -euo pipefail
SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUNDLE_ROOT="$(cd "$SOURCE_ROOT/.." && pwd)"
OUT="${1:-$BUNDLE_ROOT/../apolarity_benchmarks_final_$(date +%Y%m%d_%H%M%S).zip}"

find "$BUNDLE_ROOT" -type d \( -name __pycache__ -o -name .pytest_cache -o -name .mypy_cache \) -prune -exec rm -rf {} + || true
find "$BUNDLE_ROOT" -type f \( -name '*.pyc' -o -name '.DS_Store' \) -delete
rm -f "$OUT"
(cd "$(dirname "$BUNDLE_ROOT")" && zip -qr "$OUT" "$(basename "$BUNDLE_ROOT")" \
  -x '*/__pycache__/*' '*/.pytest_cache/*' '*/.mypy_cache/*' '*.pyc' '*.DS_Store')
echo "$OUT"
