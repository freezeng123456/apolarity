#!/usr/bin/env python3
"""Plot the two-method benchmark records.

The script intentionally reads the JSON emitted by the benchmark runner rather
than re-running a model.  It produces publication-ready PDF/PNG figures for
the fixed mixed-partial and PDE cases in the current protocol.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


CASE_ORDER = [
    "u_112233",
    "u_111222333",
    "u_11223344",
    "u_123456",
    "kdv2d",
    "gkdv1d",
    "poly4",
    "poly6",
]
CASE_LABEL = {
    "u_112233": r"$u_{112233}$",
    "u_111222333": r"$u_{111222333}$",
    "u_11223344": r"$u_{11223344}$",
    "u_123456": r"$u_{123456}$",
    "kdv2d": "KdV2D",
    "gkdv1d": "g-KdV",
    "poly4": r"$\Delta^2$",
    "poly6": r"$\Delta^3$",
}


def load_rows(path: Path) -> list[dict]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload["rows"] if isinstance(payload, dict) and "rows" in payload else payload
    if not isinstance(rows, list):
        raise ValueError(f"{path} does not contain a list of result rows")
    return [row for row in rows if row.get("status") == "ok"]


def index_rows(rows: list[dict], mode: str) -> dict[tuple[str, str], dict]:
    return {
        (row["case"], row["method"]): row
        for row in rows
        if row.get("mode") == mode
        and row.get("method") in {"nested_ad", "rank_optimal"}
    }


def present_cases(index: dict[tuple[str, str], dict]) -> list[str]:
    return [
        case
        for case in CASE_ORDER
        if (case, "nested_ad") in index and (case, "rank_optimal") in index
    ]


def _save(fig: plt.Figure, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches="tight")
    if path.suffix.lower() == ".pdf":
        fig.savefig(path.with_suffix(".png"), dpi=220, bbox_inches="tight")
    plt.close(fig)


def plot_runtime(rows: list[dict], out: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.0), sharey=True)
    for ax, mode, title in zip(
        axes,
        ("value", "parameter_grad"),
        ("Derivative value", "Parameter gradient"),
    ):
        index = index_rows(rows, mode)
        cases = present_cases(index)
        x = list(range(len(cases)))
        width = 0.36
        nested = [index[(case, "nested_ad")]["median_ms"] for case in cases]
        rank = [index[(case, "rank_optimal")]["median_ms"] for case in cases]
        ax.bar([i - width / 2 for i in x], nested, width, label="Nested AD", color="#4C78A8")
        ax.bar([i + width / 2 for i in x], rank, width, label="Rank-optimal", color="#F58518")
        ax.set_yscale("log")
        ax.set_title(title)
        ax.set_xticks(x, [CASE_LABEL[case] for case in cases], rotation=45, ha="right")
        ax.grid(axis="y", which="both", alpha=0.25)
        ax.set_ylabel("Median time (ms)")
    axes[0].legend(frameon=False, loc="upper left")
    fig.tight_layout()
    _save(fig, out)


def plot_speedup(rows: list[dict], out: Path) -> None:
    fig, ax = plt.subplots(figsize=(9.0, 4.0))
    x = list(range(len(CASE_ORDER)))
    for offset, mode, label, color in (
        (-0.18, "value", "Value", "#4C78A8"),
        (0.18, "parameter_grad", "Parameter gradient", "#F58518"),
    ):
        index = index_rows(rows, mode)
        cases = present_cases(index)
        values = []
        labels = []
        for case in CASE_ORDER:
            if case not in cases:
                continue
            nested = index[(case, "nested_ad")]["median_ms"]
            rank = index[(case, "rank_optimal")]["median_ms"]
            values.append(nested / rank)
            labels.append(case)
        positions = [CASE_ORDER.index(case) + offset for case in labels]
        ax.bar(positions, values, 0.34, label=label, color=color)
    ax.axhline(1.0, color="black", linewidth=0.8)
    ax.set_xticks(x, [CASE_LABEL[case] for case in CASE_ORDER], rotation=45, ha="right")
    ax.set_ylabel("Nested AD time / rank-optimal time")
    ax.set_title("Rank-optimal speedup on the T4")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    _save(fig, out)


def plot_memory(rows: list[dict], out: Path) -> None:
    fig, ax = plt.subplots(figsize=(9.0, 4.0))
    index = index_rows(rows, "value")
    cases = present_cases(index)
    ratios = []
    labels = []
    for case in cases:
        nested = index[(case, "nested_ad")].get("peak_memory_bytes")
        rank = index[(case, "rank_optimal")].get("peak_memory_bytes")
        if nested is None or rank is None or rank == 0:
            continue
        labels.append(case)
        ratios.append(nested / rank)
    x = list(range(len(labels)))
    bars = ax.bar(x, ratios, color="#54A24B")
    ax.axhline(1.0, color="black", linewidth=0.8)
    ax.set_xticks(x, [CASE_LABEL[case] for case in labels], rotation=45, ha="right")
    ax.set_ylabel("Nested AD peak / rank-optimal peak")
    ax.set_title("CUDA peak allocation ratio (value mode)")
    ax.grid(axis="y", alpha=0.25)
    for bar, value in zip(bars, ratios):
        ax.text(bar.get_x() + bar.get_width() / 2, value, f"{value:.2f}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout()
    _save(fig, out)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    rows = load_rows(args.input)
    plot_runtime(rows, args.out_dir / "fig_benchmark_t4_runtime.pdf")
    plot_speedup(rows, args.out_dir / "fig_benchmark_t4_speedup.pdf")
    plot_memory(rows, args.out_dir / "fig_benchmark_t4_memory.pdf")
    print(args.out_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
