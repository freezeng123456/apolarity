#!/usr/bin/env python3
"""Run pytest and force process exit after its final report.

Some JAX CPU runtimes keep non-daemon cleanup activity alive after pytest has
already completed.  This helper is only a process-lifecycle wrapper; it does
not alter test collection or results.
"""

from __future__ import annotations
import os
import sys
import pytest

code = pytest.main(sys.argv[1:])
sys.stdout.flush()
sys.stderr.flush()
os._exit(int(code))
