#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, platform, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def hfile(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


files = []
for p in sorted(ROOT.rglob("*")):
    if (
        p.is_file()
        and "results/" not in p.as_posix()
        and "__pycache__" not in p.as_posix()
        and ".pytest_cache" not in p.as_posix()
    ):
        files.append((p.relative_to(ROOT).as_posix(), hfile(p)))
h = hashlib.sha256()
for n, d in files:
    h.update(n.encode())
    h.update(d.encode())
info = {
    "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "python": platform.python_version(),
    "platform": platform.platform(),
    "source_tree_sha256": h.hexdigest(),
    "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
}
try:
    import torch

    info.update(
        {
            "torch": torch.__version__,
            "torch_cuda": torch.version.cuda,
            "torch_cuda_available": torch.cuda.is_available(),
            "torch_device": torch.cuda.get_device_name(0)
            if torch.cuda.is_available()
            else "CPU",
        }
    )
except Exception as e:
    info["torch_error"] = repr(e)
try:
    import jax

    info.update(
        {
            "jax": jax.__version__,
            "jax_backend": jax.default_backend(),
            "jax_devices": [str(d) for d in jax.devices()],
        }
    )
except Exception as e:
    info["jax_error"] = repr(e)
out = ROOT / "results/provenance.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(info, indent=2), encoding="utf-8")
print(out)
