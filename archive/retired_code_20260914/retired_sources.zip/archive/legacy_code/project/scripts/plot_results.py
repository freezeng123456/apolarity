#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import matplotlib.pyplot as plt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--backend", choices=["torch", "jax"], required=True)
    ap.add_argument("--mode", choices=["value", "parameter_grad"], default="value")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    rows = json.loads(Path(args.input).read_text(encoding="utf-8"))
    rows = [
        r
        for r in rows
        if r.get("status") == "ok"
        and r.get("backend") == args.backend
        and r.get("mode") == args.mode
    ]
    labels = []
    nested = {}
    rank = {}
    for r in rows:
        label = r.get("case") or r.get("benchmark")
        if label not in labels:
            labels.append(label)
        (nested if r.get("method") == "nested_ad" else rank)[label] = r.get("median_ms")
    x = list(range(len(labels)))
    width = 0.38
    fig, ax = plt.subplots(figsize=(max(8, len(labels) * 0.65), 4.8))
    ax.bar(
        [i - width / 2 for i in x],
        [nested.get(k, float("nan")) for k in labels],
        width,
        label="nested_ad",
    )
    ax.bar(
        [i + width / 2 for i in x],
        [rank.get(k, float("nan")) for k in labels],
        width,
        label="rank_optimal",
    )
    ax.set_ylabel("Median wall time (ms)")
    ax.set_title(f"{args.backend}: {args.mode}")
    ax.set_xticks(x, labels, rotation=45, ha="right")
    ax.legend()
    fig.tight_layout()
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=180)
    print(out)


if __name__ == "__main__":
    main()
