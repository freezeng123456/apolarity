#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULT = ROOT / "results/cpu_smoke"
PARTS = RESULT / "jax_parts"


def run(cmd, *, cwd=ROOT, env=None, timeout=180):
    print("+", " ".join(map(str, cmd)), flush=True)
    merged = os.environ.copy()
    if env:
        merged.update(env)
    completed = subprocess.run(
        cmd, cwd=cwd, env=merged, text=True, timeout=timeout, capture_output=True
    )
    if completed.returncode != 0:
        if completed.stdout:
            print(completed.stdout[-4000:], file=sys.stderr)
        if completed.stderr:
            print(completed.stderr[-4000:], file=sys.stderr)
        raise SystemExit(
            f"command failed with exit code {completed.returncode}: {' '.join(map(str, cmd))}"
        )
    if completed.stderr.strip():
        # Keep explicit backend-fallback/provenance notices without dumping per-row JSON.
        print(completed.stderr.strip()[-1000:], file=sys.stderr, flush=True)


def write_csv(rows, path):
    keys = sorted({k for r in rows for k in r if k != "times_ms"})
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            q = {k: r.get(k) for k in keys}
            for k, v in list(q.items()):
                if isinstance(v, (list, dict, tuple)):
                    q[k] = json.dumps(v, separators=(",", ":"), default=str)
            w.writerow(q)


def main():
    RESULT.mkdir(parents=True, exist_ok=True)
    if PARTS.exists():
        shutil.rmtree(PARTS)
    PARTS.mkdir(parents=True)

    run(
        [
            sys.executable,
            str(ROOT / "experiments/torch_benchmarks/run.py"),
            "--config",
            str(ROOT / "configs/cpu_smoke.yaml"),
            "--benchmark",
            "all",
            "--method",
            "both",
            "--mode",
            "both",
            "--device",
            "cpu",
            "--out",
            str(RESULT / "torch"),
        ],
        env={"PYTHONPATH": str(ROOT / "src")},
        timeout=180,
    )
    jax_dir = ROOT / "experiments/jax_benchmarks"
    rows = []
    for benchmark in ("fixed", "kdv2d", "gkdv1d", "poly4", "poly6"):
        for method in ("nested_ad", "rank_optimal"):
            for mode in ("value", "parameter_grad"):
                stem = PARTS / f"{benchmark}_{method}_{mode}"
                run(
                    [
                        sys.executable,
                        str(jax_dir / "run.py"),
                        "--config",
                        str(jax_dir / "configs/cpu_smoke.yaml"),
                        "--benchmark",
                        benchmark,
                        "--method",
                        method,
                        "--mode",
                        mode,
                        "--out",
                        str(stem),
                    ],
                    cwd=jax_dir,
                    env={
                        "PYTHONPATH": str(jax_dir / "src"),
                        "JAX_BENCH_FORCE_EXIT": "1",
                        "JAX_PLATFORMS": "cpu",
                    },
                    timeout=120,
                )
                part = json.loads(stem.with_suffix(".json").read_text(encoding="utf-8"))
                rows.extend(part)
    (RESULT / "jax.json").write_text(
        json.dumps(rows, indent=2, default=str), encoding="utf-8"
    )
    write_csv(rows, RESULT / "jax.csv")
    print(
        json.dumps(
            {
                "torch_rows": len(json.loads((RESULT / "torch.json").read_text())),
                "jax_rows": len(rows),
                "jax_ok": sum(r.get("status") == "ok" for r in rows),
                "result_dir": str(RESULT),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
