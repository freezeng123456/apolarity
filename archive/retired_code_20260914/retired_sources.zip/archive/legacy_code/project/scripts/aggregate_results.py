#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path


def load(path: Path):
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, dict) and "rows" in data:
        data = data["rows"]
    if not isinstance(data, list):
        raise ValueError(f"{path} does not contain a JSON row list")
    return data


def write_csv(rows, path):
    keys = sorted({k for r in rows for k in r if k != "times_ms"})
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            q = {k: r.get(k) for k in keys}
            for k, v in list(q.items()):
                if isinstance(v, (dict, list, tuple)):
                    q[k] = json.dumps(v, separators=(",", ":"), default=str)
            w.writerow(q)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("--out", default="results/combined")
    args = ap.parse_args()
    rows = []
    for p in map(Path, args.inputs):
        rows.extend(load(p))
    stem = Path(args.out)
    stem.parent.mkdir(parents=True, exist_ok=True)
    stem.with_suffix(".json").write_text(
        json.dumps(rows, indent=2, default=str), encoding="utf-8"
    )
    write_csv(rows, stem.with_suffix(".csv"))
    summary = []
    for r in rows:
        summary.append(
            {
                k: r.get(k)
                for k in (
                    "backend",
                    "benchmark",
                    "case",
                    "method",
                    "mode",
                    "dtype_real",
                    "timing_fixture",
                    "order",
                    "theoretical_direction_count",
                    "evaluated_direction_count",
                    "median_ms",
                    "peak_memory_bytes",
                    "analytic_rel_l2_error",
                    "parameter_gradient_rel_l2_vs_nested",
                    "status",
                )
            }
        )
    write_csv(summary, stem.with_name(stem.name + "_summary").with_suffix(".csv"))
    print(
        json.dumps(
            {
                "rows": len(rows),
                "ok": sum(r.get("status") == "ok" for r in rows),
                "out": str(stem),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
