"""Small model and sampling utilities shared by the Torch benchmarks."""

from __future__ import annotations

import math
import torch
import torch.nn as nn


def make_tanh_mlp(
    input_dim: int,
    width: int,
    depth: int,
    *,
    seed: int,
    dtype: torch.dtype,
    device: torch.device,
) -> nn.Sequential:
    """Build the STDE ``ModelConfig.depth`` architecture.

    In the supplied upstream STDE source, ``depth=4`` creates three width-128
    hidden Linear+Tanh blocks followed by one scalar output Linear layer.
    PyTorch's default Linear initialization is the same Kaiming-uniform family
    used by the upstream default.
    """
    if depth < 2:
        raise ValueError("depth counts Linear layers including output and must be >= 2")
    torch.manual_seed(seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(seed)
    layers: list[nn.Module] = []
    in_dim = input_dim
    for _ in range(depth - 1):
        layers.append(nn.Linear(in_dim, width))
        layers.append(nn.Tanh())
        in_dim = width
    layers.append(nn.Linear(in_dim, 1))
    return nn.Sequential(*layers).to(device=device, dtype=dtype)


def sample_normal_points(
    n: int,
    d: int,
    *,
    seed: int,
    dtype: torch.dtype,
    device: torch.device,
    std: float = 0.35,
) -> torch.Tensor:
    gen = torch.Generator(device="cpu")
    gen.manual_seed(seed)
    x = torch.randn((n, d), generator=gen, dtype=dtype) * std
    return x.to(device)


def sample_upstream_unit_ball_space_time(
    n: int,
    spatial_dim: int,
    *,
    seed: int,
    dtype: torch.dtype,
    device: torch.device,
    max_radius: float = 1.0,
    T: float = 1.0,
) -> torch.Tensor:
    """Mirror ``unit_ball_sample_domain_fn`` from the supplied STDE source.

    The upstream samples a Gaussian direction, normalizes it, multiplies by a
    radius uniform on [0,max_radius], then samples time uniformly on [0,T].
    Note that this is not volume-uniform for spatial_dim>1; we intentionally
    preserve the upstream convention.
    """
    gen = torch.Generator(device="cpu")
    gen.manual_seed(seed)
    r = torch.rand((n, 1), generator=gen, dtype=dtype) * max_radius
    x = torch.randn((n, spatial_dim), generator=gen, dtype=dtype)
    x = x / torch.linalg.vector_norm(x, dim=-1, keepdim=True).clamp_min(1e-12) * r
    t = torch.rand((n, 1), generator=gen, dtype=dtype) * T
    return torch.cat([x, t], dim=-1).to(device)


class AnalyticExp(nn.Module):
    """Holomorphic scalar fixture with closed-form derivatives."""

    def __init__(self, coeff: torch.Tensor):
        super().__init__()
        self.register_buffer("coeff", coeff)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        coeff = self.coeff.to(dtype=x.dtype, device=x.device)
        return torch.exp((x * coeff).sum(dim=-1, keepdim=True))


def analytic_exp_partial(
    x: torch.Tensor, coeff: torch.Tensor, alpha: tuple[int, ...]
) -> torch.Tensor:
    c = coeff.to(dtype=x.dtype, device=x.device)
    value = torch.exp((x * c).sum(dim=-1, keepdim=True))
    factor = math.prod(float(coeff[i]) for i in alpha)
    return value * factor


__all__ = [
    "make_tanh_mlp",
    "sample_normal_points",
    "sample_upstream_unit_ball_space_time",
    "AnalyticExp",
    "analytic_exp_partial",
]
