"""Torch adapters for the reproducible two-method benchmark."""
from __future__ import annotations

from typing import Iterable

import numpy as np
import torch
from torch import Tensor
import torch.nn as nn

from ..operators import single_monomial_partial


def build_mlp(
    params: tuple[tuple[np.ndarray, np.ndarray], ...],
    *,
    dtype: torch.dtype = torch.float32,
    device: torch.device | str = "cpu",
) -> nn.Sequential:
    """Build an MLP from the backend-independent NumPy fixture."""
    layers: list[nn.Module] = []
    for layer_index, (weight, bias) in enumerate(params):
        linear = nn.Linear(weight.shape[1], weight.shape[0], bias=True)
        linear = linear.to(device=device, dtype=dtype)
        with torch.no_grad():
            linear.weight.copy_(torch.as_tensor(weight, device=device, dtype=dtype))
            linear.bias.copy_(torch.as_tensor(bias, device=device, dtype=dtype))
        layers.append(linear)
        if layer_index + 1 < len(params):
            layers.append(nn.Tanh())
    return nn.Sequential(*layers)


def model_value(model: nn.Module, points: Tensor) -> Tensor:
    """Evaluate a scalar-output model and enforce the benchmark shape."""
    value = model(points)
    if value.ndim != 2 or value.shape[1] != 1:
        raise ValueError(
            "benchmark models must return shape (batch, 1); "
            f"got {tuple(value.shape)}"
        )
    return value


def derivative(
    model: nn.Module,
    points: Tensor,
    alpha: Iterable[int],
    *,
    method: str,
    create_graph: bool = True,
) -> Tensor:
    """Evaluate one expanded partial with one of the two benchmark methods."""
    if method == "nested_ad":
        backend = "direct_autodiff"
    elif method == "rank_optimal":
        backend = "rank_optimal"
    else:
        raise ValueError(
            f"unknown benchmark method {method!r}; expected nested_ad or rank_optimal"
        )
    return single_monomial_partial(
        model,
        points,
        tuple(int(index) for index in alpha),
        backend=backend,
        create_graph=create_graph,
    )


__all__ = ["build_mlp", "derivative", "model_value"]
