r"""Backend-independent benchmark metadata and deterministic fixtures.

The benchmark code uses an expanded multi-index: ``(0, 0, 1)`` denotes
``\partial_{x_0}^2\partial_{x_1}``.  Keeping this convention in one module
prevents the JAX and Torch drivers from silently measuring different
derivatives.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import math
from typing import Iterable

import numpy as np


BENCHMARK_METHODS: tuple[str, str] = ("nested_ad", "rank_optimal")


def expanded_multi_index(value: str | Iterable[int]) -> tuple[int, ...]:
    """Parse an expanded multi-index in a strict, unambiguous form.

    Strings use the one-based labels customary in derivative names: ``"1122"``
    denotes ``(0, 0, 1, 1)`` internally.  Comma/space separated strings are
    accepted for dimensions larger than nine and follow the same one-based
    convention.  Iterable inputs are already zero-based and are preserved.
    """
    if isinstance(value, str):
        text = value.strip()
        if not text:
            raise ValueError("a multi-index must not be empty")
        if any(sep in text for sep in (",", " ", ";")):
            tokens = text.replace(";", ",").replace(" ", ",").split(",")
            try:
                labels = tuple(int(token) for token in tokens if token != "")
            except ValueError as exc:
                raise ValueError(f"invalid multi-index {value!r}") from exc
            if any(label < 1 for label in labels):
                raise ValueError("string multi-index labels must be positive")
            alpha = tuple(label - 1 for label in labels)
        elif text.isdigit():
            labels = tuple(int(char) for char in text)
            if any(label < 1 for label in labels):
                raise ValueError("string multi-index labels must be positive")
            alpha = tuple(label - 1 for label in labels)
        else:
            raise ValueError(
                "a string multi-index must contain digits or comma-separated integers"
            )
    else:
        alpha = tuple(int(index) for index in value)
    if not alpha:
        raise ValueError("a multi-index must have positive order")
    if any(index < 0 for index in alpha):
        raise ValueError(f"multi-index entries must be non-negative: {alpha}")
    return alpha


def monomial_rank(alpha: Iterable[int]) -> int:
    """Return the complex Waring rank of the monomial for ``alpha``."""
    alpha_t = expanded_multi_index(alpha)
    exponents = sorted(Counter(alpha_t).values())
    return math.prod(exponent + 1 for exponent in exponents[1:])


def exponent_pattern(alpha: Iterable[int]) -> tuple[int, ...]:
    """Return active exponents in non-increasing order for table labels."""
    return tuple(sorted(Counter(expanded_multi_index(alpha)).values(), reverse=True))


def rank_directions_are_real(alpha: Iterable[int]) -> bool:
    """Whether the roots-of-unity schedule can be represented over the reals.

    The construction chooses the smallest active exponent as the base.  Every
    remaining exponent equal to one contributes the two real roots ``+1`` and
    ``-1``; any remaining exponent greater than one requires genuinely complex
    roots.  This criterion also covers a pure derivative (rank one).
    """
    counts = Counter(expanded_multi_index(alpha))
    active = sorted(counts.items(), key=lambda item: (item[1], item[0]))
    return all(exponent == 1 for _, exponent in active[1:])


@dataclass(frozen=True)
class BenchmarkTarget:
    """Named fixed mixed-partial target used by both backend drivers."""

    name: str
    alpha: tuple[int, ...]

    @property
    def order(self) -> int:
        return len(self.alpha)

    @property
    def dimension(self) -> int:
        return max(self.alpha) + 1

    @property
    def rank(self) -> int:
        return monomial_rank(self.alpha)

    @property
    def pattern(self) -> tuple[int, ...]:
        return exponent_pattern(self.alpha)


# The four requested high-order stress tests are kept together with two small
# calibration cases.  The stress-test names use the same notation as the
# manuscript and the STDE reference inventory.
MIXED_TARGETS: tuple[BenchmarkTarget, ...] = (
    BenchmarkTarget("u_12", (0, 1)),
    BenchmarkTarget("u_1122", (0, 0, 1, 1)),
    BenchmarkTarget("u_112233", (0, 0, 1, 1, 2, 2)),
    BenchmarkTarget("u_111222333", (0, 0, 0, 1, 1, 1, 2, 2, 2)),
    BenchmarkTarget("u_123456", (0, 1, 2, 3, 4, 5)),
    BenchmarkTarget("u_11223344", (0, 0, 1, 1, 2, 2, 3, 3)),
)


def seeded_fixture(
    seed: int,
    input_dim: int,
    width: int,
    depth: int,
    batch: int,
    *,
    dtype: np.dtype = np.dtype(np.float32),
) -> tuple[tuple[tuple[np.ndarray, np.ndarray], ...], np.ndarray]:
    """Create a deterministic STDE-compatible MLP fixture.

    ``depth`` is the total number of affine layers, as in the STDE
    ``ModelConfig``.  Thus ``depth=4`` means three hidden tanh layers followed
    by a scalar output layer.  The same NumPy arrays are converted by the JAX
    and Torch runners, so backend comparisons share parameters and points.
    """
    if input_dim < 1 or width < 1 or depth < 2 or batch < 1:
        raise ValueError("input_dim, width, batch must be positive and depth >= 2")
    dtype = np.dtype(dtype)
    if dtype not in (np.dtype(np.float32), np.dtype(np.float64)):
        raise ValueError("fixtures support float32 or float64")
    rng = np.random.default_rng(int(seed))
    dimensions = [input_dim] + [width] * (depth - 1) + [1]
    params: list[tuple[np.ndarray, np.ndarray]] = []
    for fan_in, fan_out in zip(dimensions[:-1], dimensions[1:]):
        scale = math.sqrt(2.0 / (fan_in + fan_out))
        weight = (rng.standard_normal((fan_out, fan_in)) * scale).astype(dtype)
        bias = (rng.standard_normal(fan_out) * 0.05).astype(dtype)
        params.append((weight, bias))
    points = (rng.standard_normal((batch, input_dim)) * 0.35).astype(dtype)
    return tuple(params), points


__all__ = [
    "BENCHMARK_METHODS",
    "BenchmarkTarget",
    "MIXED_TARGETS",
    "expanded_multi_index",
    "exponent_pattern",
    "monomial_rank",
    "rank_directions_are_real",
    "seeded_fixture",
]
