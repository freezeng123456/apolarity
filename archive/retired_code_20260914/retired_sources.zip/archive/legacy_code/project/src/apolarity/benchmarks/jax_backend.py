"""JAX adapters for the reproducible two-method benchmark.

This module is intentionally independent of STDE.  It uses the public
``apolarity.jax_backend`` implementation for the proposed method and nested
``jax.grad`` for the control.
"""
from __future__ import annotations

from typing import Iterable

import jax
import jax.numpy as jnp

from ..jax_backend import jax_nested_monomial_partial, jax_single_monomial_partial


def to_jax(
    params_np,
    points_np,
    *,
    dtype=jnp.float32,
):
    params = tuple(
        (jnp.asarray(weight, dtype=dtype), jnp.asarray(bias, dtype=dtype))
        for weight, bias in params_np
    )
    return params, jnp.asarray(points_np, dtype=dtype)


def model_one(params, point):
    value = point
    for layer_index, (weight, bias) in enumerate(params):
        value = weight @ value + bias
        if layer_index + 1 < len(params):
            value = jnp.tanh(value)
    return value[0]


def model_batch(params, points):
    return jax.vmap(lambda point: model_one(params, point))(points)


def derivative(params, points, alpha: Iterable[int], *, method: str):
    """Evaluate a batch of partials with ``nested_ad`` or ``rank_optimal``."""
    alpha_t = tuple(int(index) for index in alpha)
    fun = lambda point: model_one(params, point)
    if method == "nested_ad":
        return jax_nested_monomial_partial(fun, points, alpha_t)
    if method == "rank_optimal":
        return jax_single_monomial_partial(fun, points, alpha_t)
    raise ValueError(
        f"unknown benchmark method {method!r}; expected nested_ad or rank_optimal"
    )


__all__ = ["derivative", "model_batch", "model_one", "to_jax"]
