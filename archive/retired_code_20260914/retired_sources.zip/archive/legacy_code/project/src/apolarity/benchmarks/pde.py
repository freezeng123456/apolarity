"""Method-independent PDE operators used by the benchmark runners.

Each function receives a ``value`` callback and a ``partial`` callback.  The
callbacks are supplied by the nested-AD or rank-optimal backend, so both
methods evaluate exactly the same mathematical residual.  No STDE code is
imported here.
"""
from __future__ import annotations

from math import factorial
from typing import Callable, Iterable


Partial = Callable[[tuple[int, ...]], object]


def _compositions(total: int, parts: int) -> Iterable[tuple[int, ...]]:
    if parts == 1:
        yield (total,)
        return
    for first in range(total + 1):
        for tail in _compositions(total - first, parts - 1):
            yield (first, *tail)


def laplacian_power_terms(
    dimension: int, power: int
) -> list[tuple[float, tuple[int, ...]]]:
    """Expand ``(sum_i partial_i^2)^power`` into monomial terms.

    The returned coefficient is the multinomial coefficient and the expanded
    multi-index contains coordinate ``i`` exactly ``2*k_i`` times.  Terms are
    ordered lexicographically by the exponent composition, which makes JSON
    manifests deterministic.
    """
    if dimension < 1 or power < 1:
        raise ValueError("dimension and power must be positive")
    terms: list[tuple[float, tuple[int, ...]]] = []
    for counts in _compositions(power, dimension):
        coefficient = factorial(power)
        for count in counts:
            coefficient /= factorial(count)
        alpha: list[int] = []
        for coordinate, count in enumerate(counts):
            alpha.extend([coordinate] * (2 * count))
        terms.append((float(coefficient), tuple(alpha)))
    return terms


def kdv2d_residual(partial: Partial, value: Callable[[], object]) -> object:
    """Return the two-dimensional nonlinear KdV residual from STDE.

    Coordinates are ordered ``(x, y, t)`` and the residual is

    ``u_ty + u_xxxy + 3 (u_xy u_x + u_y u_xx) - u_xx + 2 u_yy``.
    """
    u_x = partial((0,))
    u_y = partial((1,))
    u_xx = partial((0, 0))
    u_xy = partial((0, 1))
    u_yy = partial((1, 1))
    u_ty = partial((2, 1))
    u_xxxy = partial((0, 0, 0, 1))
    return u_ty + u_xxxy + 3.0 * (u_xy * u_x + u_y * u_xx) - u_xx + 2.0 * u_yy


def gkdv_residual(
    partial: Partial, value: Callable[[], object]
) -> tuple[object, object, object]:
    """Return ``(f, f_x, f_t)`` for the STDE g-KdV gradient-enhanced case.

    Coordinates are ordered ``(x, t)``.  The dispersive coefficient is the
    official ``0.0025`` value; the returned components are assembled before
    squaring in :func:`gkdv_loss`.
    """
    u = value()
    u_x = partial((0,))
    u_t = partial((1,))
    u_xx = partial((0, 0))
    u_tx = partial((1, 0))
    u_tt = partial((1, 1))
    u_xxx = partial((0, 0, 0))
    u_xxxx = partial((0, 0, 0, 0))
    u_txxx = partial((1, 0, 0, 0))
    f = u_t + u * u_x + 0.0025 * u_xxx
    f_x = u_tx + u_x * u_x + u * u_xx + 0.0025 * u_xxxx
    f_t = u_tt + u_t * u_x + u * u_tx + 0.0025 * u_txxx
    return f, f_x, f_t


def _mean_square(value: object) -> object:
    real = getattr(value, "real", value)
    return (real * real).mean()


def gkdv_loss(
    partial: Partial,
    value: Callable[[], object],
    *,
    gradient_weight: float = 1.0e-3,
) -> object:
    """Return the complete ``eq=2`` gPINN loss used for benchmarking."""
    f, f_x, f_t = gkdv_residual(partial, value)
    return _mean_square(f) + float(gradient_weight) * (
        _mean_square(f_x) + _mean_square(f_t)
    )


def polyharmonic_residual(
    partial: Partial,
    *,
    dimension: int = 2,
    order: int = 4,
) -> object:
    """Evaluate ``Delta^(order/2) u`` for an even differential order."""
    if order < 2 or order % 2:
        raise ValueError("polyharmonic order must be a positive even integer")
    power = order // 2
    result = None
    for coefficient, alpha in laplacian_power_terms(dimension, power):
        term = float(coefficient) * partial(alpha)
        result = term if result is None else result + term
    return result


__all__ = [
    "gkdv_loss",
    "gkdv_residual",
    "kdv2d_residual",
    "laplacian_power_terms",
    "polyharmonic_residual",
]
