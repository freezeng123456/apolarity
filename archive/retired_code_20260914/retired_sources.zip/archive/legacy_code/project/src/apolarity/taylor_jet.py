"""Forward-mode Taylor jet propagation for Linear+Tanh MLPs.

Mathematical setting
====================
Let g(tau) = u(x + tau * Z), where u: R^d -> R is an MLP composed of
nn.Linear and nn.Tanh layers in nn.Sequential, and Z in R^d is a fixed
"direction" vector.  We want the directional Taylor coefficients

    T_k(Z) := g^{(k)}(0) / k!,    k = 1, ..., p.

A standard reverse-mode implementation does p nested ``torch.autograd.grad``
calls, building a graph of depth O(p * L), peak memory
O((p+1) * L * B * K * H) with a non-trivial PyTorch allocator constant.

This module replaces that with a forward-mode "Taylor jet" pass: each
intermediate activation in the MLP is augmented from a single tensor
``y_0`` to a tuple ``(y_0, y_1, ..., y_p)`` representing
``y_k = (1/k!) d^k y / dtau^k |_{tau=0}``.  The MLP is then evaluated once
with each primitive (Linear / Tanh / +) replaced by its jet rule.

Key jet rules (probabilist convention y_k = (1/k!) d^k y / dtau^k):

  Linear   y = W x + b:
    y_0 = W x_0 + b
    y_k = W x_k                      for k >= 1

  Affine offset (input to first jet):
    x(tau) = x + tau * Z  ->  jet = (x, Z, 0, 0, ..., 0)

  Pointwise tanh   y = tanh(x):
    z := 1 - y^2 = tanh'(x), itself a jet
    y_0 = tanh(x_0)
    z_0 = 1 - y_0 * y_0
    For k = 1, ..., p:
      y_k = (1/k) sum_{j=0}^{k-1} (k - j) * z_j * x_{k-j}
      z_k = -sum_{j=0}^{k} y_j * y_{k-j}

  Add (broadcast bias-like):  trivial elementwise add per order.

The recurrence for tanh comes from the standard Faa-di-Bruno expansion using
the ODE form  y' = z * x'  (chain rule outer factor) together with the
identity z = 1 - y^2.

Numerical correctness: verified against torch nested autograd to machine
precision (max rel err < 5e-16 in fp64) for p up to 6 -- see
tests/test_backend_equivalence.py.

Memory and gradient backflow
============================
Each jet term ``y_k`` is a regular torch.Tensor with shape identical to the
ordinary forward activation at that layer.  Storing p+1 such tensors per
layer makes the per-step activation footprint ``(p+1) * L * B * K * H``
tensor elements -- same asymptotic order as reverse-mode nested grads, but
*without* the reverse-engine constant blow-up (no graph chaining).

Because every jet primitive is built from standard differentiable PyTorch
ops (matmul, add, mul, tanh), gradients with respect to model parameters
flow naturally through the entire jet propagation when the caller invokes
``loss.backward()``.  The output T_p tensor remains a leaf of the autograd
graph leading back to the model parameters.

torch.compile integration (opt-in)
==================================
Setting the env var ``TAYLOR_JET_COMPILE=1`` (or calling
``set_compile_mode(True)``) wraps ``jet_forward_sequential`` with
``torch.compile(mode="reduce-overhead")`` on first use.  The wrapper is
cached per ``(net_id, p, dtype)`` so successive calls with identical net
instance and jet order hit the fast path.

Risk profile (project-internal evaluation, 2026-05-11):
- Shape-stable: ``B*K*d`` and ``p`` are fixed across training steps (KdV
  and CH6 both use constant ``n_residual``, ``K``, and operator order).
  No recompile thrash.
- ``model(...)`` calls outside the jet path (forward eval, BC, IC,
  validation) are NOT affected -- compile only wraps jet_forward_sequential.
- ``reverse`` and ``fd`` backends are NOT compiled (they contain
  ``torch.autograd.grad(create_graph=True)`` which Dynamo cannot trace).
- ``loss.backward()`` through a compiled jet still flows to model parameters
  (the eager path is covered by
  tests/test_backend_equivalence.py::test_real_parameter_gradients_match_direct).
- First compile on each net+p incurs ~1-30 s overhead (Inductor fusion +
  kernel selection); amortized over a 20-min training run.
"""
from __future__ import annotations

import math
import os
from typing import Callable, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
from torch import Tensor


# ============================================================================
# Compile mode (opt-in)
# ============================================================================

_COMPILE_ENABLED: bool = os.environ.get("TAYLOR_JET_COMPILE", "0") == "1"
_COMPILE_CACHE: Dict[Tuple[int, int, torch.dtype], Callable] = {}


def set_compile_mode(enabled: bool) -> None:
    """Enable/disable torch.compile for jet_forward_sequential at runtime.

    When enabled, the first call for each (model.id, p, dtype) triple
    triggers compilation (~1-30 s); subsequent calls hit the fast path.
    Disabling clears the per-net compile cache.
    """
    global _COMPILE_ENABLED
    _COMPILE_ENABLED = enabled
    if not enabled:
        _COMPILE_CACHE.clear()


def is_compile_enabled() -> bool:
    return _COMPILE_ENABLED


# ============================================================================
# Jet container
# ============================================================================

class TaylorJet:
    """A length-(p+1) sequence of tensors, where ``terms[k]`` represents
    the k-th Taylor coefficient ``(1/k!) d^k / dtau^k`` of the jet's value
    at ``tau = 0``.

    All terms share the same shape (broadcast-compatible).  We do NOT enforce
    any specific dtype/device; rules below propagate the input convention.
    """

    __slots__ = ("terms",)

    def __init__(self, terms: List[Tensor]) -> None:
        if len(terms) == 0:
            raise ValueError("TaylorJet must have at least one term (order 0)")
        self.terms = terms

    @property
    def order(self) -> int:
        """Highest order p stored (so length is p+1)."""
        return len(self.terms) - 1

    @classmethod
    def from_input(cls, x: Tensor, Z: Tensor, p: int) -> "TaylorJet":
        """Build the input jet for ``g(tau) = u(x + tau * Z)``:
            terms[0] = x,  terms[1] = Z,  terms[k>=2] = 0.
        Both ``x`` and ``Z`` have shape (N, d) with N = B*K samples.
        """
        if p < 1:
            raise ValueError(f"p must be >= 1; got {p}")
        zero = torch.zeros_like(x)
        return cls([x, Z] + [zero for _ in range(p - 1)])

    @classmethod
    def from_constant(cls, x: Tensor, p: int) -> "TaylorJet":
        """Build a jet with constant value ``x`` (used only in tests)."""
        if p < 0:
            raise ValueError(f"p must be >= 0; got {p}")
        zero = torch.zeros_like(x)
        return cls([x] + [zero for _ in range(p)])


# ============================================================================
# Jet rules for primitives appearing in our MLPs
# ============================================================================

def _linear_params_for_term(weight: Tensor, bias: Tensor | None, term: Tensor) -> tuple[Tensor, Tensor | None]:
    """Cast real parameters to a complex term dtype when needed.

    This keeps complex-direction Taylor jets usable with real-valued models:
    gradients through ``weight.to(complex*)`` flow back to the original real
    parameters via PyTorch's cast backward.
    """
    if term.dtype.is_complex and not weight.dtype.is_complex:
        w = weight.to(dtype=term.dtype)
        b = None if bias is None else bias.to(dtype=term.dtype)
        return w, b
    return weight, bias




def _is_sin_module(m: nn.Module) -> bool:
    return m.__class__.__name__.lower() in {
        "sin", "sine", "scaledsin", "sinactivation"
    }


def _is_sinh_module(m: nn.Module) -> bool:
    return m.__class__.__name__.lower() in {"sinh", "sinhactivation"}

def jet_linear(jet: TaylorJet, weight: Tensor, bias: Tensor | None) -> TaylorJet:
    """Apply  y = x @ W^T + b  to a jet.  Bias adds only to the order-0 term.

    All Taylor coefficients share the same shape, so we concatenate the order
    dimension into the batch dimension and use a single GEMM per Linear layer.
    This reduces the number of forward/backward matmul nodes from ``p+1`` to
    one per layer.
    """
    w, b = _linear_params_for_term(weight, bias, jet.terms[0])
    n = jet.terms[0].shape[0]
    flat = torch.cat(jet.terms, dim=0)
    yflat = flat @ w.T
    out = list(yflat.split(n, dim=0))
    if b is not None:
        out[0] = out[0] + b
    return TaylorJet(out)



def _activation_vjp(q_terms: tuple[Tensor, ...], grad_outputs: tuple[Tensor | None, ...]) -> tuple[Tensor, ...]:
    """VJP for y(t)=phi(x(t)) with q(t)=phi'(x(t)).

    If y_k = sum_{j=0}^k q_j x_{k-j}, then the adjoint is
    grad_x_m = sum_{j=0}^{p-m} conj(q_j) * grad_y_{m+j}.
    """
    p = len(q_terms) - 1
    gy: list[Tensor] = []
    for g in grad_outputs:
        gy.append(torch.zeros_like(q_terms[0]) if g is None else g)
    gx: list[Tensor] = []
    for m in range(p + 1):
        acc = gy[m] * q_terms[0].conj()
        for j in range(1, p - m + 1):
            acc = acc + gy[m + j] * q_terms[j].conj()
        gx.append(acc)
    return tuple(gx)


class _TanhJetFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *terms: Tensor):
        p = len(terms) - 1
        x = list(terms)
        y: List[Tensor] = [torch.tanh(x[0])]
        z: List[Tensor] = [1.0 - y[0] * y[0]]
        for k in range(1, p + 1):
            acc = k * z[0] * x[k]
            for j in range(1, k):
                acc = acc + (k - j) * z[j] * x[k - j]
            y_k = acc / float(k)
            y.append(y_k)
            zk = -y[0] * y[k]
            for j in range(1, k + 1):
                zk = zk - y[j] * y[k - j]
            z.append(zk)
        ctx.save_for_backward(*z)
        return tuple(y)

    @staticmethod
    def backward(ctx, *grad_outputs):
        return _activation_vjp(ctx.saved_tensors, grad_outputs)


class _SigmoidJetFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *terms: Tensor):
        p = len(terms) - 1
        x = list(terms)
        y: List[Tensor] = [torch.sigmoid(x[0])]
        z: List[Tensor] = [y[0] - y[0] * y[0]]
        for k in range(1, p + 1):
            acc = k * z[0] * x[k]
            for j in range(1, k):
                acc = acc + (k - j) * z[j] * x[k - j]
            y_k = acc / float(k)
            y.append(y_k)
            yy = y[0] * y[k]
            for j in range(1, k + 1):
                yy = yy + y[j] * y[k - j]
            z.append(y[k] - yy)
        ctx.save_for_backward(*z)
        return tuple(y)

    @staticmethod
    def backward(ctx, *grad_outputs):
        return _activation_vjp(ctx.saved_tensors, grad_outputs)


class _SinJetFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, *terms: Tensor):
        p = len(terms) - 1
        x = list(terms)
        y: List[Tensor] = [torch.sin(x[0])]
        c: List[Tensor] = [torch.cos(x[0])]
        for k in range(1, p + 1):
            acc_y = k * c[0] * x[k]
            acc_c = -k * y[0] * x[k]
            for j in range(1, k):
                acc_y = acc_y + (k - j) * c[j] * x[k - j]
                acc_c = acc_c - (k - j) * y[j] * x[k - j]
            y.append(acc_y / float(k))
            c.append(acc_c / float(k))
        ctx.save_for_backward(*c)
        return tuple(y)

    @staticmethod
    def backward(ctx, *grad_outputs):
        return _activation_vjp(ctx.saved_tensors, grad_outputs)


class _SinhJetFunction(torch.autograd.Function):
    """Jet rule for sinh, the entire analytic activation used in §5 PINN experiments.

    Coupled recurrence (probabilist convention y_k = (1/k!) d^k y / dt^k):
        y = sinh(x),  z = cosh(x);  y' = z*x',  z' = y*x'.
        y_0 = sinh(x_0),  z_0 = cosh(x_0)
        y_k = (1/k) sum_{j=0}^{k-1} (k-j) * z_j * x_{k-j}
        z_k = (1/k) sum_{j=0}^{k-1} (k-j) * y_j * x_{k-j}      (no sign flip, contrast with sin)

    VJP uses derivative q = cosh = z, identical pattern to sin/tanh.
    """
    @staticmethod
    def forward(ctx, *terms: Tensor):
        p = len(terms) - 1
        x = list(terms)
        y: List[Tensor] = [torch.sinh(x[0])]
        z: List[Tensor] = [torch.cosh(x[0])]
        for k in range(1, p + 1):
            acc_y = k * z[0] * x[k]
            acc_z = k * y[0] * x[k]
            for j in range(1, k):
                acc_y = acc_y + (k - j) * z[j] * x[k - j]
                acc_z = acc_z + (k - j) * y[j] * x[k - j]
            y.append(acc_y / float(k))
            z.append(acc_z / float(k))
        ctx.save_for_backward(*z)
        return tuple(y)

    @staticmethod
    def backward(ctx, *grad_outputs):
        return _activation_vjp(ctx.saved_tensors, grad_outputs)


def jet_tanh(jet: TaylorJet) -> TaylorJet:
    """Pointwise tanh on a jet using a custom VJP to reduce autograd graph size."""
    return TaylorJet(list(_TanhJetFunction.apply(*jet.terms)))


def jet_sin(jet: TaylorJet) -> TaylorJet:
    """Pointwise sin on a jet using coupled sin/cos recurrences."""
    return TaylorJet(list(_SinJetFunction.apply(*jet.terms)))


def jet_sinh(jet: TaylorJet) -> TaylorJet:
    """Pointwise sinh on a jet using coupled sinh/cosh recurrences."""
    return TaylorJet(list(_SinhJetFunction.apply(*jet.terms)))


def jet_sigmoid(jet: TaylorJet) -> TaylorJet:
    """Pointwise sigmoid on a jet using a custom VJP."""
    return TaylorJet(list(_SigmoidJetFunction.apply(*jet.terms)))

# ============================================================================
# MLP-level driver
# ============================================================================

def _is_supported_module(m: nn.Module) -> bool:
    return isinstance(m, (nn.Linear, nn.Tanh, nn.Sigmoid)) or _is_sin_module(m) or _is_sinh_module(m)


# Tensor-only inner driver: takes a list of tensors (the input jet terms)
# and returns the output jet terms.  This signature is friendly to
# torch.compile (no custom containers, no Python-level branching beyond a
# fixed-length for-loop over Sequential layers / a static integer ``p``).
def _jet_forward_tensors(
    layers: List[nn.Module], terms: List[Tensor],
) -> List[Tensor]:
    """Run jet ``terms`` (list of length p+1) through ``layers`` (a flat
    list of nn.Linear / nn.Tanh modules in order)."""
    out = list(terms)
    p = len(out) - 1
    for layer in layers:
        if isinstance(layer, nn.Linear):
            W = layer.weight
            b = layer.bias
            w, bb = _linear_params_for_term(W, b, out[0])
            n = out[0].shape[0]
            flat = torch.cat(out, dim=0)
            yflat = flat @ w.T
            new_out = list(yflat.split(n, dim=0))
            if bb is not None:
                new_out[0] = new_out[0] + bb
            out = new_out
        elif isinstance(layer, nn.Tanh):
            out = jet_tanh(TaylorJet(out)).terms
        elif isinstance(layer, nn.Sigmoid):
            out = jet_sigmoid(TaylorJet(out)).terms
        elif _is_sin_module(layer):
            omega0 = float(getattr(layer, "omega0", 1.0))
            if omega0 != 1.0:
                out = [term * omega0 for term in out]
            out = jet_sin(TaylorJet(out)).terms
        elif _is_sinh_module(layer):
            out = jet_sinh(TaylorJet(out)).terms
        else:
            raise NotImplementedError(
                f"taylor_jet does not support layer type {type(layer).__name__}"
            )
    return out


def jet_forward_sequential(net: nn.Sequential, jet: TaylorJet) -> TaylorJet:
    """Run ``jet`` through the layers of ``nn.Sequential`` net.  Only
    supports Linear + Tanh/Sigmoid/Sin stacks (the architecture used by KdV / CH6 /
    HardBC models in this project).  Raises if any other layer is found.

    When ``TAYLOR_JET_COMPILE=1`` is set in the environment (or
    ``set_compile_mode(True)`` was called), the per-step compute is wrapped
    with ``torch.compile(mode="reduce-overhead")``.  The compiled callable
    is cached per (net id, jet order, dtype).
    """
    layers = list(net)
    if _COMPILE_ENABLED:
        cache_key = (id(net), jet.order, jet.terms[0].dtype)
        compiled = _COMPILE_CACHE.get(cache_key)
        if compiled is None:
            # Build a closure that fixes the layers list (so the compiled
            # graph specialises to this net's parameter tensors).
            def _runner(terms_list):
                return _jet_forward_tensors(layers, terms_list)
            compiled = torch.compile(_runner, mode="reduce-overhead",
                                     dynamic=False, fullgraph=False)
            _COMPILE_CACHE[cache_key] = compiled
        out_terms = compiled(jet.terms)
    else:
        out_terms = _jet_forward_tensors(layers, jet.terms)
    return TaylorJet(out_terms)


def _resolve_sequential_net(model: nn.Module) -> nn.Sequential:
    """Find the underlying nn.Sequential.  Project models expose this as
    ``model.net``; for plain nn.Sequential we accept it directly."""
    if isinstance(model, nn.Sequential):
        return model
    if hasattr(model, "net") and isinstance(model.net, nn.Sequential):
        return model.net
    raise NotImplementedError(
        "taylor_jet requires the model to be (or wrap) an nn.Sequential of "
        "Linear/Tanh layers; got " + type(model).__name__
    )


def _jet_forward_model(model: nn.Module, jet: TaylorJet) -> TaylorJet:
    """Run a jet through a sequential model or an explicit composite hook.

    Composite experiment architectures (for example shared-trunk Fourier
    branches and MscaleDNN subnets) expose ``jet_forward(TaylorJet)``.  Keeping
    the hook at the model boundary lets them reuse the same primitive jet rules
    without pretending that a branched graph is a flat ``nn.Sequential``.
    """
    hook = getattr(model, "jet_forward", None)
    if callable(hook):
        out = hook(jet)
        if not isinstance(out, TaylorJet):
            raise TypeError(
                f"{type(model).__name__}.jet_forward must return TaylorJet"
            )
        return out
    return jet_forward_sequential(_resolve_sequential_net(model), jet)


def tp_directional_via_jet(
    model: nn.Module, xyt_input: Tensor, Z: Tensor, p: int,
) -> Tensor:
    """Compute T_p(Z) = g^{(p)}(0) / p!  via Taylor jet propagation.

    Same semantics as ``kdv_hd.estimators._tp_via_reverse``: shape
    ``(B, K, 1)``.

    The MLP is evaluated *once* on a flat ``(B*K, d)`` batch, with each
    layer replaced by its jet rule.  Memory: ``(p+1) * L * B * K * H``
    activation tensors; no autograd graph chaining.

    Note on convention: by construction, ``out_jet.terms[k]`` already
    equals ``(1/k!) * d^k g / dtau^k |_{tau=0}`` (probabilist convention),
    so the value of T_p is read off directly from ``terms[p]`` without
    any further division by ``p!``.

    Caveat: this routine ASSUMES ``model`` (or ``model.net``) is a single
    ``nn.Sequential`` of ``nn.Linear`` and smooth activation layers (Tanh/Sigmoid/Sin).  Networks
    wrapped in HardBC factors (e.g. ``CH6HardBCModel``) need to be unwrapped
    by the caller first; see
    ``ch6_ball.estimators._SpatialNWrapper`` etc. for the existing pattern.
    """
    if p < 1:
        raise ValueError(f"p must be >= 1; got {p}")
    B, K, d = Z.shape
    xyt_exp = xyt_input.unsqueeze(1).expand(B, K, d).reshape(B * K, d)
    Z_flat = Z.reshape(B * K, d)

    in_jet = TaylorJet.from_input(xyt_exp, Z_flat, p)
    out_jet = _jet_forward_model(model, in_jet)

    # out_jet.terms[p] is already T_p = g^{(p)}(0) / p!  (probabilist convention)
    if out_jet.terms[p].numel() != B * K:
        raise ValueError(
            "Taylor-jet partials require scalar model output with one value per "
            f"input; got output shape {tuple(out_jet.terms[p].shape)}"
        )
    return out_jet.terms[p].reshape(B, K, 1)


def tp_directional_all_via_jet(
    model: nn.Module, xyt_input: Tensor, Z: Tensor, p_max: int,
) -> List[Tensor]:
    """Compute T_1, T_2, ..., T_{p_max} via a SINGLE jet pass of order
    ``p_max``.  Returns list of ``(B, K, 1)`` tensors.

    This is strictly cheaper than calling ``tp_directional_via_jet`` p_max
    times because the same forward jet pass already contains every order.
    """
    if p_max < 1:
        raise ValueError(f"p_max must be >= 1; got {p_max}")
    B, K, d = Z.shape
    xyt_exp = xyt_input.unsqueeze(1).expand(B, K, d).reshape(B * K, d)
    Z_flat = Z.reshape(B * K, d)

    in_jet = TaylorJet.from_input(xyt_exp, Z_flat, p_max)
    out_jet = _jet_forward_model(model, in_jet)
    if out_jet.terms[0].numel() != B * K:
        raise ValueError(
            "Taylor-jet partials require scalar model output with one value per "
            f"input; got output shape {tuple(out_jet.terms[0].shape)}"
        )

    out_list: List[Tensor] = []
    for k in range(1, p_max + 1):
        # terms[k] is already T_k under the probabilist convention.
        out_list.append(out_jet.terms[k].reshape(B, K, 1))
    return out_list


__all__ = [
    "TaylorJet",
    "jet_linear",
    "jet_tanh",
    "jet_sin",
    "jet_sinh",
    "jet_sigmoid",
    "jet_forward_sequential",
    "tp_directional_via_jet",
    "tp_directional_all_via_jet",
    "set_compile_mode",
    "is_compile_enabled",
]
