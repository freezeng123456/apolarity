# apolarity

`apolarity` provides a deterministic, exact backend for one fixed
high-order mixed partial derivative of a neural-network surrogate, based
on identifying the directional schedule problem with the Waring
decomposition of a monomial.

Scope:

- one fixed multi-index at a time (no Laplacian powers, no trace
  contractions, no operator sums);
- no stochastic estimation;
- value and parameter-gradient computation through Taylor-mode
  automatic differentiation.

## Method in one sentence

For a fixed multi-index of order `p`, the Carlini--Catalisano--Geramita
(2012) rank theorem and its roots-of-unity construction give an
explicit complex directional schedule of length

```
R_C(z^alpha) = prod_{j>=1} (a_j + 1)
```

(where `a_0 <= ... <= a_n` are the active exponents). The directional
Taylor coefficients are evaluated by a forward-mode jet pass through a
`sinh`-activated MLP with complex parameters; because `sinh` is entire
on the complex plane, the jet rules are well-defined globally.

## Repository layout

```text
src/apolarity/
  waring.py          # complex monomial Waring directions
  polarization.py    # antipodally merged real polarization directions
  taylor_jet.py      # Taylor-mode AD for Linear / sinh / tanh MLPs
  operators.py       # single_monomial_partial entry point
  jax_backend.py     # rank-optimal directions via jax.experimental.jet
  benchmark_multiindex.py   # expanded-index metadata and Waring schedules
  benchmark_derivatives.py  # nested_ad / rank_optimal benchmark API
  benchmark_residuals.py    # KdV, g-KdV, and polyharmonic residuals
experiments/
  common/            # shared harness (osc_common.py)
  tools/             # historical jsc_v2 figure and LaTeX-table builders
  torch_benchmarks/  # Pro-generated PyTorch two-method benchmark runner
  jax_benchmarks/    # independent Pro-generated JAX two-method runner
  stde_comparison/   # isolated earlier STDE comparison harness and results
  polyharmonic/      # active Polyharmonic family
  chirp/             # active radial-chirp family
  maxwell/           # active Maxwell family
  results/jsc_v2/    # historical validated formal bundles
  archived/          # other families, auxiliary results, and historical runners
docs/
  beamer/  apolarity_report_zh.tex
  paper/   jsc_paper_main.tex, jsc_paper_main.bib, siamltex.cls, siamfull.bst
scripts/
  run_jsc_main3.sh                    # launch exactly one jsc_v3 setting
  validate_jsc_results.py             # validate one atomic result bundle
tests/
```

See `experiments/README.md` for the frozen experiment protocol.

## Mainline two-method benchmark

**First-group update (2026-09-08):** the fixed-partial experiment now uses the
standalone JAX value-only protocol in
[`experiments/jax_benchmarks/FIRST_GROUP.md`](experiments/jax_benchmarks/FIRST_GROUP.md).
It compares JIT-compiled nested coordinate JVPs with Waring directions evaluated
by official JAX Taylor jets. It does not compute parameter gradients or import
Torch. The earlier Torch and all-family results described below are retained
as historical evidence, not relabelled as results of this new protocol.

The benchmark implementation generated in the separate Pro review is now
available in the main tree. The canonical Torch entry point is
`experiments/torch_benchmarks/run.py`, with the shared derivative and residual
API in `src/apolarity/benchmark_*.py`; the standalone JAX implementation is in
`experiments/jax_benchmarks/`. Both runners expose only the direct
`nested_ad` control and the `rank_optimal` Waring/Taylor-jet method. The suite
covers exactly four families: fixed mixed partials (`u_112233`,
`u_111222333`, `u_123456`, and `u_11223344`), the two-dimensional nonlinear
KdV residual, the gradient-enhanced g-KdV loss, and two-dimensional
polyharmonic orders four and six. The supplied STDE source and the earlier
three-method comparison harness remain isolated under `reference/` and
`experiments/stde_comparison/`; neither is imported by the mainline runners.

The Pro-generated protocol, CPU smoke command, GPU commands, and result schema
are documented in the downloaded bundle and mirrored by `configs/main.yaml`,
`configs/cpu_smoke.yaml`, `scripts/run_cpu_smoke.py`, and the two benchmark
runner directories. The earlier modular draft under
`experiments/benchmarks/` is retained as a legacy two-method harness and is not
used by the Pro-generated T4 run. The artifact hash, review changes, test
evidence, and the first T4 measurements are recorded in
[`docs/web_pro_benchmark_review_20260904.md`](docs/web_pro_benchmark_review_20260904.md).
The original ZIP and the recovered T4 result bundle are also kept under
`output/web_pro_benchmark_review_20260904/`.
The corresponding runtime, speedup, and peak-allocation plots are in its
`plots/` subdirectory and are copied into `docs/paper/figures/`.

The STDE-derived comparison code and its earlier T4 records are documented in
[`experiments/stde_comparison/README.md`](experiments/stde_comparison/README.md)
and are intentionally excluded from the manuscript's numerical section.

## Current benchmark status

For the current paper, the active numerical scope is the four-family suite
listed above: fixed mixed partials, two-dimensional KdV, gradient-enhanced
g-KdV, and two-dimensional polyharmonic orders four and six. The older
Polyharmonic/Chirp/Maxwell training experiments and their validated bundles
remain under `experiments/results/` and `experiments/archived/` as historical
material; they are not part of the current benchmark tables.

## Historical training experiments (not current paper evidence)

The compact v3 training methods were:

- `complex_sinh` (Complex Sinh, the proposed method);
- `complex_sinh_autodiff` (the same network with direct nested coordinate autodiff).

The historical protocol is `jsc_v3`. Both lines use the same literal hidden
width \(H=128\), initialization, loss weights, 1000-second budget, and three
seeds; only the derivative backend changes. Trainable real degrees of freedom
are recorded for transparency and \(H=64\) is not used.

The historical preregistered settings were:

- Poly: \(d=2\), operator order \(2,4,6\);
- Chirp: \(a\in\{1,2,3\}\);
- Maxwell: \(a\in\{2,4,6\}\).

Launch exactly one setting through `scripts/run_jsc_main3.sh`:

```bash
bash scripts/run_jsc_main3.sh poly --dim 2 --order 6
bash scripts/run_jsc_main3.sh chirp --sweep 2
bash scripts/run_jsc_main3.sh maxwell --sweep 4
```

Each command above is a separate example; do not combine settings into one
launch. A formal output bundle is admissible only after
`validate_jsc_results.py` succeeds, for example:

```bash
python scripts/validate_jsc_results.py \
  experiments/results/jsc_v3/poly_d2_o6
```

Historical or archived runners, every family-local `run.sh`, and all material
under `experiments/archived/` are retained only for implementation diagnosis.
Their outputs are not part of the active paper evidence.

## API

### PyTorch

```python
from apolarity import single_monomial_partial

deriv = single_monomial_partial(model, x, alpha, backend="auto")
```

`alpha` is the expanded multi-index in zero-based indexing
(for instance `(0, 0, 1)` for the third-order partial that differentiates
twice in coordinate 0 and once in coordinate 1). For complex-parameter
networks, pass an `nn.Sequential` whose linear layers carry
`torch.complex128` weights; the jet rules dispatch on tensor dtype. Inputs must
have shape `(batch, d)` and models must return one scalar per input with shape
`(batch, 1)`; invalid coordinate indices and multi-output models are rejected.

### JAX

Install the optional JAX dependency and pass a scalar function of one point:

```bash
python -m pip install -e '.[jax]'
```

```python
import jax
import jax.numpy as jnp

from apolarity.jax_backend import jax_single_monomial_partial


def model(params, point):
    value = point
    for weight, bias in params[:-1]:
        value = jnp.tanh(weight @ value + bias)
    weight, bias = params[-1]
    return (weight @ value + bias)[0]


def derivative_loss(params, points):
    values = jax_single_monomial_partial(
        lambda point: model(params, point), points, (0, 0, 1)
    )
    return jnp.mean(jnp.real(values) ** 2)


parameter_gradients = jax.grad(derivative_loss)(params, points)
```

The JAX function accepts either one point of shape `(d,)` or a batch of shape
`(batch, d)`. The model must return a scalar for each point and admit the
complex input evaluations required by the Waring directions. GPU users should
install the JAX build matching their CUDA runtime.

## Documents

- Slide deck:

  ```bash
  cd docs/beamer && xelatex -interaction=nonstopmode apolarity_report_zh.tex
  ```

- Paper draft. The manuscript targets the Journal of Computational Physics and
  uses the SIAM `siamltex` class, which is vendored in `docs/paper/` together
  with `siamfull.bst`, a renamed derivative of `siam.bst` that spells out given
  names. The bibliography is BibTeX, so run the four standard passes:

  ```bash
  cd docs/paper
  pdflatex -interaction=nonstopmode jsc_paper_main.tex
  bibtex jsc_paper_main
  pdflatex -interaction=nonstopmode jsc_paper_main.tex
  pdflatex -interaction=nonstopmode jsc_paper_main.tex
  ```
