from __future__ import annotations

import torch

from apolarity.benchmark_multiindex import (
    parse_one_based_pattern,
    rank_optimal_schedule,
    theoretical_waring_rank,
)


def test_required_direction_counts_and_square_free_real_dtype():
    expected = {"112233": 9, "111222333": 16, "11223344": 27, "123456": 32}
    for pattern, rank in expected.items():
        alpha = parse_one_based_pattern(pattern)
        schedule = rank_optimal_schedule(alpha, 16, real_dtype=torch.float32)
        assert theoretical_waring_rank(alpha) == rank
        assert schedule.theoretical_rank == rank
        assert schedule.directions.shape == (rank, 16)
    square_free = rank_optimal_schedule(
        parse_one_based_pattern("123456"), 16, real_dtype=torch.float32
    )
    assert not square_free.requires_complex
    assert square_free.directions.dtype == torch.float32
    repeated = rank_optimal_schedule(
        parse_one_based_pattern("11223344"), 16, real_dtype=torch.float32
    )
    assert repeated.requires_complex
    assert repeated.directions.dtype == torch.complex64
