from __future__ import annotations

import math
import copy
import torch
import torch.nn as nn

from apolarity.benchmark_derivatives import monomial_partial, rank_optimal_partial_raw
from apolarity.benchmark_multiindex import parse_one_based_pattern


class Sinh(nn.Module):
    def forward(self, x):
        return torch.sinh(x)


def fixture(d=16):
    model = nn.Sequential(nn.Linear(d, 1), Sinh()).to(torch.float32)
    coeff = torch.linspace(0.2, 0.65, d)
    with torch.no_grad():
        model[0].weight.copy_(coeff[None, :])
        model[0].bias.fill_(0.11)
    return model, coeff


def exact(model, coeff, x, alpha):
    z = x @ coeff[:, None] + model[0].bias
    fac = math.prod(float(coeff[i]) for i in alpha)
    return fac * (torch.sinh(z) if len(alpha) % 2 == 0 else torch.cosh(z))


def flatten_grads(model):
    return torch.cat(
        [p.grad.reshape(-1) for p in model.parameters() if p.grad is not None]
    )


def test_required_fixed_derivatives_values_and_parameter_gradients():
    x = torch.tensor([[0.01 * (i + 1) for i in range(16)]], dtype=torch.float32)
    for pattern in ("112233", "111222333", "11223344", "123456"):
        alpha = parse_one_based_pattern(pattern)
        ref, coeff = fixture()
        cand = copy.deepcopy(ref)
        expected = exact(ref, coeff, x, alpha)
        nested, _ = monomial_partial(
            ref, x, alpha, method="nested_ad", create_graph=True
        )
        rank, _ = monomial_partial(
            cand, x, alpha, method="rank_optimal", create_graph=True
        )
        torch.testing.assert_close(nested, expected, rtol=5e-5, atol=2e-7)
        torch.testing.assert_close(rank, expected, rtol=2e-4, atol=5e-7)
        ref.zero_grad()
        cand.zero_grad()
        nested.square().mean().backward()
        rank.square().mean().backward()
        torch.testing.assert_close(
            flatten_grads(cand), flatten_grads(ref), rtol=5e-4, atol=1e-7
        )
        raw, meta = rank_optimal_partial_raw(cand, x, alpha)
        if raw.is_complex():
            assert float(raw.imag.detach().abs().max()) < 2e-5
        if pattern == "123456":
            assert meta.direction_dtype == "float32"
