"""Prepared benchmark contract: setup once, fresh values/parameter graphs per call."""
import pytest
import torch

import apolarity.benchmark_derivatives as derivatives
from apolarity.benchmark_models import make_tanh_mlp
from apolarity.benchmark_multiindex import parse_one_based_pattern


@pytest.mark.parametrize("pattern", ["111111", "111222", "112233", "123456", "11223344", "111222333"])
def test_prepared_values_parameter_gradients_and_execution(pattern):
    model = make_tanh_mlp(6, 3, 2, seed=19, dtype=torch.float64, device=torch.device("cpu"))
    x = torch.full((2, 6), 0.08, dtype=torch.float64)
    alpha = parse_one_based_pattern(pattern)
    reference = derivatives.prepare_monomial_partial(model, x, alpha, method="nested_ad")
    expected = reference(True)
    params = tuple(model.parameters())
    expected_grads = torch.autograd.grad(expected.square().mean(), params, allow_unused=True)
    for execution in ("batched", "serial"):
        evaluate = derivatives.prepare_monomial_partial(
            model, x, alpha, method="rank_optimal", direction_execution=execution
        )
        value = evaluate(True)
        torch.testing.assert_close(value, expected, rtol=1e-8, atol=1e-11)
        grads = torch.autograd.grad(value.square().mean(), params, allow_unused=True)
        for actual, target in zip(grads, expected_grads):
            if target is None:
                assert actual is None or torch.count_nonzero(actual) == 0
            else:
                torch.testing.assert_close(actual, target, rtol=1e-7, atol=1e-12)
        assert not evaluate(False).requires_grad
        # A second call must create a fresh graph, rather than reusing saved activations.
        evaluate(True).square().mean().backward()
        model.zero_grad(set_to_none=True)


def test_schedule_is_precomputed_but_parameters_remain_live(monkeypatch):
    model = make_tanh_mlp(2, 3, 2, seed=7, dtype=torch.float64, device=torch.device("cpu"))
    x = torch.full((2, 2), 0.1, dtype=torch.float64)
    original = derivatives.rank_optimal_schedule
    calls = []

    def counted(*args, **kwargs):
        calls.append(1)
        return original(*args, **kwargs)

    monkeypatch.setattr(derivatives, "rank_optimal_schedule", counted)
    evaluate = derivatives.prepare_monomial_partial(model, x, (0, 0, 1), method="rank_optimal")
    before = evaluate(False)
    with torch.no_grad():
        model[-1].weight.mul_(2)
    after = evaluate(False)
    torch.testing.assert_close(after, 2 * before)
    assert len(calls) == 1


def test_compilation_requests_full_graph_without_fallback(monkeypatch):
    # Exercise Dynamo's full-graph capture, not hardware-specific code generation.
    original = torch.compile
    options = []

    def capture(fn, **kwargs):
        options.append(kwargs)
        return original(fn, backend="eager", **kwargs)

    monkeypatch.setattr(torch, "compile", capture)
    model = make_tanh_mlp(2, 3, 2, seed=7, dtype=torch.float64, device=torch.device("cpu"))
    x = torch.full((1, 2), 0.1, dtype=torch.float64)
    eager = derivatives.prepare_monomial_partial(model, x, (0, 1), method="rank_optimal")
    compiled = derivatives.prepare_monomial_partial(model, x, (0, 1), method="rank_optimal", compile_jets=True)
    torch.testing.assert_close(compiled(False), eager(False))
    compiled(True).square().mean().backward()
    assert options == [{"fullgraph": True, "dynamic": False}]
