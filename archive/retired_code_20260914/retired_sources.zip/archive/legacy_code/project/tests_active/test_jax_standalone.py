from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np
import pytest

jax = pytest.importorskip("jax")
import jax.numpy as jnp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments/jax_benchmarks/src"))

from jax_apolarity_bench.derivatives import monomial_partial
from jax_apolarity_bench.directions import (
    parse_one_based_pattern,
    rank_optimal_schedule,
)
from jax_apolarity_bench.residuals import (
    kdv2d_residual,
    gkdv1d_gradient_enhanced_loss,
    polyharmonic_2d_operator,
)


def rel(a, b):
    aa = np.asarray(a)
    bb = np.asarray(b)
    return np.linalg.norm((aa - bb).ravel()) / max(np.linalg.norm(bb.ravel()), 1e-30)


def test_jax_required_fixed_values_and_parameter_gradients():
    x = jnp.asarray([[0.01 * (i + 1) for i in range(16)]], dtype=jnp.float32)
    a0 = jnp.linspace(0.2, 0.65, 16, dtype=jnp.float32)
    for pattern in ("112233", "111222333", "11223344", "123456"):
        alpha = parse_one_based_pattern(pattern)

        def values(method, a):
            f = lambda z: jnp.sinh(
                jnp.dot(a.astype(z.dtype), z) + jnp.asarray(0.11, dtype=z.dtype)
            )
            return monomial_partial(f, x, alpha, method=method)[0]

        n = values("nested_ad", a0)
        r = values("rank_optimal", a0)
        assert rel(r, n) < 5e-4
        gn = jax.grad(lambda a: jnp.mean(values("nested_ad", a) ** 2))(a0)
        gr = jax.grad(lambda a: jnp.mean(values("rank_optimal", a) ** 2))(a0)
        assert rel(gr, gn) < 1e-3
    s = rank_optimal_schedule(
        parse_one_based_pattern("123456"), 16, real_dtype=jnp.float32
    )
    assert not s.requires_complex and s.directions.dtype == jnp.float32


def test_jax_pde_residuals_and_parameter_gradients_on_analytic_fixture():
    cases = [
        ("kdv2d", 3, jnp.asarray([[0.1, -0.2, 0.3]], dtype=jnp.float32)),
        ("gkdv1d", 2, jnp.asarray([[0.1, 0.3]], dtype=jnp.float32)),
        ("poly4", 2, jnp.asarray([[0.1, -0.2]], dtype=jnp.float32)),
        ("poly6", 2, jnp.asarray([[0.1, -0.2]], dtype=jnp.float32)),
    ]
    for kind, d, x in cases:
        a0 = jnp.linspace(0.35, 0.42, d, dtype=jnp.float32)

        def eval_case(method, a):
            activation = jnp.sin if kind.startswith("poly") else jnp.sinh
            f = lambda z: activation(
                jnp.dot(a.astype(z.dtype), z) + jnp.asarray(0.13, dtype=z.dtype)
            )
            if kind == "kdv2d":
                return kdv2d_residual(f, x, method=method).value
            if kind == "gkdv1d":
                return jnp.atleast_1d(
                    gkdv1d_gradient_enhanced_loss(f, x, method=method).value
                )
            order = 4 if kind == "poly4" else 6
            return polyharmonic_2d_operator(f, x, order=order, method=method).value

        n = eval_case("nested_ad", a0)
        r = eval_case("rank_optimal", a0)
        assert rel(r, n) < 2e-3
        gn = jax.grad(lambda a: jnp.mean(jnp.real(eval_case("nested_ad", a)) ** 2))(a0)
        gr = jax.grad(lambda a: jnp.mean(jnp.real(eval_case("rank_optimal", a)) ** 2))(
            a0
        )
        assert rel(gr, gn) < 5e-3
