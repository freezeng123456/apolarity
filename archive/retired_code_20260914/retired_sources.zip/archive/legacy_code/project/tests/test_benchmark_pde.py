from __future__ import annotations

import numpy as np

from apolarity.benchmarks.pde import gkdv_loss, kdv2d_residual, polyharmonic_residual


def test_kdv_residual_uses_the_declared_terms():
    values = {
        (0,): np.array([1.0, 2.0]),
        (1,): np.array([3.0, 4.0]),
        (0, 0): np.array([5.0, 6.0]),
        (0, 1): np.array([7.0, 8.0]),
        (1, 1): np.array([9.0, 10.0]),
        (2, 1): np.array([11.0, 12.0]),
        (0, 0, 0, 1): np.array([13.0, 14.0]),
    }
    actual = kdv2d_residual(values.__getitem__, lambda: np.zeros(2))
    expected = values[(2, 1)] + values[(0, 0, 0, 1)] + 3 * (
        values[(0, 1)] * values[(0,)] + values[(1,)] * values[(0, 0)]
    ) - values[(0, 0)] + 2 * values[(1, 1)]
    np.testing.assert_allclose(actual, expected)


def test_gkdv_loss_is_real_and_includes_gradient_terms():
    values = {
        (0,): np.array([1.0, 2.0]),
        (1,): np.array([3.0, 4.0]),
        (0, 0): np.array([5.0, 6.0]),
        (1, 0): np.array([7.0, 8.0]),
        (1, 1): np.array([9.0, 10.0]),
        (0, 0, 0): np.array([11.0, 12.0]),
        (0, 0, 0, 0): np.array([13.0, 14.0]),
        (1, 0, 0, 0): np.array([15.0, 16.0]),
    }
    value = lambda: np.array([0.5, 0.75])
    f = values[(1,)] + value() * values[(0,)] + 0.0025 * values[(0, 0, 0)]
    fx = values[(1, 0)] + values[(0,)] ** 2 + value() * values[(0, 0)] + 0.0025 * values[(0, 0, 0, 0)]
    ft = values[(1, 1)] + values[(1,)] * values[(0,)] + value() * values[(1, 0)] + 0.0025 * values[(1, 0, 0, 0)]
    expected = np.mean(f**2) + 1e-3 * (np.mean(fx**2) + np.mean(ft**2))
    np.testing.assert_allclose(gkdv_loss(values.__getitem__, value), expected)


def test_polyharmonic_callback_accepts_numpy_values():
    values = {(1, 1, 1, 1): np.array([1.0]), (0, 0, 1, 1): np.array([2.0]), (0, 0, 0, 0): np.array([3.0])}
    actual = polyharmonic_residual(values.__getitem__, dimension=2, order=4)
    np.testing.assert_allclose(actual, np.array([8.0]))
