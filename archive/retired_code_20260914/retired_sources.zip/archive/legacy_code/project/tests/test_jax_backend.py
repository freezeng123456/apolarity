from __future__ import annotations

import itertools
import math
from collections import Counter

import numpy as np
import pytest


jax = pytest.importorskip("jax")
jax.config.update("jax_enable_x64", True)
import jax.numpy as jnp

from apolarity.jax_backend import (
    jax_monomial_waring_directions,
    jax_single_monomial_partial,
)


def _basis(d: int, order: int):
    return itertools.combinations_with_replacement(range(d), order)


def _factorial(expanded):
    return math.prod(math.factorial(count) for count in Counter(expanded).values())


def test_jax_waring_coefficient_filter_fp64():
    alpha = (0, 0, 1, 2)
    directions, weights, info = jax_monomial_waring_directions(alpha, 5)
    assert info.rank == 6
    for beta in _basis(5, len(alpha)):
        powers = jnp.prod(
            jnp.stack(
                [directions[:, index] ** power for index, power in Counter(beta).items()]
            ),
            axis=0,
        )
        actual = jnp.sum(weights * powers) / _factorial(beta)
        expected = 1.0 if beta == tuple(sorted(alpha)) else 0.0
        np.testing.assert_allclose(actual, expected, rtol=0.0, atol=1e-12)


@pytest.mark.parametrize("alpha", [(0, 1), (0, 0, 1), (0, 0, 0, 0)])
def test_jax_partial_and_parameter_gradient_match_nested_ad(alpha):
    params = (
        (
            jnp.asarray(
                [[0.2, -0.3], [0.5, 0.1], [-0.4, 0.25]], dtype=jnp.float64
            ),
            jnp.asarray([0.01, -0.02, 0.03], dtype=jnp.float64),
        ),
        (
            jnp.asarray([[0.4, -0.2, 0.3]], dtype=jnp.float64),
            jnp.asarray([0.05], dtype=jnp.float64),
        ),
    )
    points = jnp.asarray(
        [[-0.25, 0.1], [0.2, -0.4], [0.15, 0.3]], dtype=jnp.float64
    )

    def model(model_params, point):
        (weight0, bias0), (weight1, bias1) = model_params
        hidden = jnp.tanh(weight0 @ point + bias0)
        return (weight1 @ hidden + bias1)[0]

    def nested_one(model_params, point):
        derivative = lambda z: model(model_params, z)
        for coordinate in alpha:
            previous = derivative
            derivative = lambda z, previous=previous, coordinate=coordinate: jax.grad(
                previous
            )(z)[coordinate]
        return derivative(point)

    nested_batch = jax.vmap(nested_one, in_axes=(None, 0))

    def rank_optimal_values(model_params):
        return jax_single_monomial_partial(
            lambda point: model(model_params, point), points, alpha
        )

    expected_values = nested_batch(params, points)
    actual_values = rank_optimal_values(params)
    np.testing.assert_allclose(actual_values.real, expected_values, rtol=2e-10, atol=2e-11)
    np.testing.assert_allclose(actual_values.imag, 0.0, rtol=0.0, atol=2e-11)

    def expected_loss(model_params):
        values = nested_batch(model_params, points)
        return jnp.mean(values**2)

    def actual_loss(model_params):
        values = rank_optimal_values(model_params)
        return jnp.mean(jnp.real(values) ** 2)

    expected_gradient = jax.grad(expected_loss)(params)
    actual_gradient = jax.grad(actual_loss)(params)
    for expected, actual in zip(
        jax.tree_util.tree_leaves(expected_gradient),
        jax.tree_util.tree_leaves(actual_gradient),
    ):
        np.testing.assert_allclose(actual, expected, rtol=2e-9, atol=2e-11)


def test_jax_request_validation():
    scalar = lambda point: jnp.sum(point * point)
    point = jnp.ones((2,), dtype=jnp.float64)

    with pytest.raises(ValueError, match="positive order"):
        jax_single_monomial_partial(scalar, point, ())
    with pytest.raises(ValueError, match="out of range"):
        jax_single_monomial_partial(scalar, point, (2,))
    with pytest.raises(ValueError, match="shape"):
        jax_single_monomial_partial(scalar, jnp.ones((1, 2, 3)), (0,))
