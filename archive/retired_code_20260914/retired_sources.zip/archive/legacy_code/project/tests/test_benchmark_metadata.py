from __future__ import annotations

from apolarity.benchmarks import laplacian_power_terms
from apolarity.benchmarks.common import (
    MIXED_TARGETS,
    expanded_multi_index,
    monomial_rank,
    rank_directions_are_real,
)


def test_requested_mixed_targets_have_expected_orders_and_ranks():
    targets = {target.name: target for target in MIXED_TARGETS}
    assert targets["u_112233"].order == 6
    assert targets["u_112233"].rank == 9
    assert targets["u_111222333"].order == 9
    assert targets["u_111222333"].rank == 16
    assert targets["u_123456"].order == 6
    assert targets["u_123456"].rank == 32
    assert targets["u_11223344"].order == 8
    assert targets["u_11223344"].rank == 27


def test_multi_index_parser_and_real_schedule_criterion():
    assert expanded_multi_index("112233") == (0, 0, 1, 1, 2, 2)
    assert expanded_multi_index("10,10,11") == (9, 9, 10)
    assert rank_directions_are_real((0, 1, 2, 3, 4, 5))
    assert not rank_directions_are_real((0, 0, 1, 1))
    assert monomial_rank((0,) * 8) == 1


def test_two_dimensional_laplacian_power_expansion():
    assert laplacian_power_terms(2, 2) == [
        (1.0, (1, 1, 1, 1)),
        (2.0, (0, 0, 1, 1)),
        (1.0, (0, 0, 0, 0)),
    ]
    terms = laplacian_power_terms(2, 3)
    assert len(terms) == 4
    assert sum(coefficient for coefficient, _ in terms) == 8.0
