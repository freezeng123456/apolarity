Compile main.tex with PDFLaTeX or XeLaTeX and BibTeX.
The source bundle includes the current KP-II five-seed mean figure and table.
Updated 2026-10-21.
