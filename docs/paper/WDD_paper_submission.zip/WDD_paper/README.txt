Compile main.tex with pdfLaTeX, BibTeX, pdfLaTeX, pdfLaTeX.
Current source: Section 4.1 uses B=1000 V100 measurements against STDE++ Section 6.1.
The PDE figures retain the completed WDD/Nested equal-update experiments.
This source bundle omits the earlier PDF export; compile main.tex for the current paper.
