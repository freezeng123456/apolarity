Compile main.tex with PDFLaTeX or XeLaTeX and BibTeX.
All current PDE figures and tables compare WDD with STDE++.
Updated 2026-10-21.
