Compile main.tex with pdfLaTeX, BibTeX, pdfLaTeX, pdfLaTeX. Current equal-update experiments; tables show RE and training time.
